# Hellenic Network panel 3.8.0 (includes everything from 3.7.0)

This release turns the panel into a branded, more self-service game-server manager. Everything below was added **alongside** the existing code: server definitions, users, sessions, backups, templates, hooks and `data/state.json` keep working unchanged. Internal URLs, permissions, cookie/localStorage keys and file names are unchanged by renaming the panel.

## Upgrading

1. Stop the panel and back up `config.json` and `data/` (setup also does this for `config.json`).
2. Replace the files, run `npm install` (no new dependencies) and `npm run setup -- --check`.
3. Start the panel. The default name becomes **Hellenic Network** until an administrator changes it.

Configuration changes you may notice:

| Change | Detail |
|---|---|
| Removed personal defaults | `192.168.168.163`, `/media/george/BIG` no longer appear in defaults. `backupMount` now defaults to empty (= no external-disk check). **Existing `config.json` values are untouched**, so existing installs behave as before. New installs default the backup folder to `../MinecraftBackups`. |
| New `data/state.json` keys | `branding`, `customSoftware`, `extensions`, `extensionRegistries`, `pluginRecords`, `softwareOverrides`. Safe to ignore on downgrade. |
| New folders | `data/branding/` (logo, icon), `data/extensions/`, `data/software/` (uploaded server JARs), `bundled-extensions/`. |
| New per-server field | `config.servers[id].software = { id, version, build, sha256, verified, trust, … }`, written when a server is created from the catalog. |
| Service worker | Now network-first, so updates and branding changes show up without clearing caches. |

## Setup

`npm run setup` now detects the OS, Node, Java (and other installed JDKs), Git, `tar`, memory, free disk, folder permissions, port availability and the existing configuration; explains failures with a fix; **previews every change and asks before writing**; backs up `config.json` first (last 5 kept); and never overwrites credentials without asking.

| Command | Purpose |
|---|---|
| `npm run setup` | Guided setup |
| `npm run setup -- --check` (or `npm run doctor`) | Read-only report; works without a terminal; exit code 1 on failures |
| `npm run setup -- --dry-run` | Answer the questions, see the planned changes, write nothing |
| `npm run setup -- --rollback` | Restore the newest `config.json` backup (the replaced file is kept too) |
| `npm run setup -- --reset-admin` | New admin password (asks to confirm; hidden input) |

The same report is available in the panel under **Management → System check**.

## Branding (Management → Branding)

Administrators can change the panel name, short name, logo, icon, six colours, nearly every navigation label, support links (sidebar/footer/login) and footer text. Notes:

* Stored in `data/state.json`; images in `data/branding/`. Images are validated by content (PNG/JPEG/WebP/GIF/ICO). **SVG is refused** because it can carry scripts.
* The server rejects colour sets with unreadable contrast (text 4.5:1, accent 3:1).
* The name appears in the page title, installed-app manifest, login page, sidebar, e-mails, webhook messages and in-game messages. Colours restyle the default dark theme; users who choose the personal Blue/White theme keep that palette.
* Labels are display-only and keyed by stable IDs.

## Create a Minecraft server without a template (Servers → Create server)

Choose software, version (and build), ID, port and memory. **Check & preview** lists exactly what will happen and what is verified. **Create** runs as a job with live steps and removes everything it created if any step fails.

| Software | Source resolved at request time | Verification |
|---|---|---|
| Vanilla | Mojang version manifest | SHA-1 from Mojang |
| Paper, Folia | PaperMC downloads API (`fill.papermc.io`) | SHA-256 from PaperMC |
| Velocity | PaperMC downloads API | SHA-256 from PaperMC |
| Purpur | `api.purpurmc.org` | MD5 only (weak; the UI says so) |
| Fabric | `meta.fabricmc.net` | **None published** – the file is only checked to be a runnable JAR, and the UI says so |
| Spigot | Compiled locally with the official BuildTools (needs Git + Java; 5–15 min) | Built on this machine; no publisher checksum |

* The target version is **1.21.11**. It is pre-selected when a vendor publishes it; otherwise the UI says so and shows the newest available. Nothing is hard-coded or invented – an unpublished version or build is an error.
* Required Java is taken from Mojang's metadata for that version (falls back to a table for 1.x versions only) and checked before anything is downloaded.
* `eula.txt` is written **only if the administrator ticks the EULA box**.
* Velocity gets a `velocity.toml` routed to your existing servers and a private `forwarding.secret`.
* Admins can add **custom software** (URL + optional SHA-256, or an uploaded JAR) on **Server software**. Uploaded/unchecksummed software shows "unverified" warnings and needs an explicit acknowledgement at creation.

## Plugin manager (server page → Plugins)

* Shown only for software that supports plugins (Paper, Spigot, Purpur, Folia, Velocity, BungeeCord/Waterfall, and custom software that declares loaders). For Vanilla/Fabric the API answers 409 and the button is hidden. Servers whose software cannot be identified ask an admin to choose it once.
* Installed plugins show descriptor data (name, version, API version, authors), enable/disable, config files, data folder, and a compatibility verdict (e.g. API newer than the server, Folia support missing, Velocity vs Bukkit, Fabric mods).
* **Find plugins**: Modrinth search filtered by the server's loaders and Minecraft version. Installs fetch the version **by ID from Modrinth's API** (the browser never supplies a URL), download only from `cdn.modrinth.com`, and verify SHA-512. Pre-releases and possible incompatibilities require confirmation; required dependencies are listed.
* **Updates**: installed JARs are identified by exact SHA-1 on Modrinth. JARs not published there (or modified) are reported as "not found", never guessed.
* **Upload JAR**: validated as a ZIP, descriptor read, compatibility checked, never silently overwrites; clearly labelled unverified.
* **Remove/replace** moves files to `plugins/.blockpanel-trash/` (Recovery tab) instead of deleting.
* Spigot's own resource site (SpigotMC) and Hangar are **not** integrated: SpigotMC resources have no reliable hashes or direct downloads, and Hangar was not implemented. Use manual upload for those.

## Extensions and Pterodactyl compatibility (Management → Extensions)

What was investigated and what is true:

* **Pterodactyl has no official extension system.** The ecosystem is (a) *eggs* – JSON describing a Docker-based server, (b) the Application/Client REST APIs, and (c) third-party framework packages such as **Blueprint** (`.blueprint`, with `conf.yml`), which are PHP/Laravel code that patches Pterodactyl's panel, routes, views and database.
* **Eggs (PTDL_v1/v2) – partly supported.** The panel imports the Java startup command (converted to direct arguments), variables and stop command as custom software. **Installation scripts are never executed** (they are bash for Docker); Docker images, config-file rewrites and non-Java startups are reported as unsupported. You then add a JAR source to the imported software.
* **Blueprint packages – not supported, and detected as such.** The Extensions page recognises them, explains why, and lists any eggs bundled inside so those can be imported.
* **No Pterodactyl API emulation exists.** Extensions that depend on Pterodactyl's Application/Client API are unsupported. There is no egg *export* either.

Native extensions (`.bpext`/zip, ≤5 MB) contain `extension.json` plus `.json/.md/.txt/.png` files only – **no code can be shipped or run**. They may contribute: server software definitions, colour themes, and links, each gated by a declared permission that an administrator must approve before enabling. Updates are staged atomically, keep the previous version, reset approval if permissions grow, and can be rolled back. Registries are optional HTTPS JSON lists you add yourself (none is shipped); registry installs require a SHA-256.

"Valid" in the UI means *passed this panel's schema and validation*. Nothing is marked as "verified to work" beyond that.

Manifest example:

```json
{ "schemaVersion": 1, "id": "my-links", "name": "My links", "version": "1.0.0",
  "panel": { "min": "3.7.0" }, "permissions": ["navigation.links"],
  "provides": { "links": [{ "label": "Rules", "url": "https://example.com/rules", "placement": "footer" }] },
  "settings": [{ "key": "note", "label": "Note", "type": "string", "default": "" }] }
```

A bundled **Hellenic Themes** extension (two dark presets) can be installed without network access.

## Server properties editor (server page → Properties)

A typed editor for `server.properties`: grouped, searchable settings with toggles, dropdowns, number limits, help text, defaults, "reset to default" and a changed-count/Save bar.

* **Lossless:** only the lines you change are rewritten; comments, order, line endings and unknown keys (mods/plugins/newer versions, shown under "Other settings") are kept byte-for-byte. Values are encoded like Java does (`§` becomes `\u00a7`).
* **Safe:** the server validates every value; a backup goes to `.blockpanel-backups/` (last 5); writes are atomic; a stale-edit check (ETag) refuses to overwrite a file that changed on disk; the RCON password is never sent to the browser (blank = keep); the audit log records key names only.
* **Aware:** changing `server-port` is checked against other servers and keeps the panel's port record in sync; turning off `online-mode` asks for confirmation; running servers are told a restart is needed. Needs `files_view` to read and `files_edit` to save, plus the server's normal access rules. Proxies (no `server.properties`) are excluded.
* Defaults shown are Mojang's vanilla defaults for recent versions; some keys do not exist in every version.
* This is built into the panel rather than shipped as an extension, because extensions in this panel are code-free and cannot add pages.

## Extension platform (3.8.0)

Full author guide: [EXTENSIONS.md](EXTENSIONS.md). Summary of what was added:

* **Extension API v2** (`.hnx`): declarative pages, sandboxed frame pages with a permission-checked `hn.call()` bridge, 18 capabilities (servers, players, properties, storage, HTTP, notify, audit), scheduled jobs, event reactions, settings with encrypted secrets, translations. v1 packages keep working unchanged.
* **Core additions the platform needed:** an event hook in `notify()`/console output, a server-control helper, `lib/ext-host.js` (runtime), `lib/ext-manifest.js` (validator), `lib/i18n.js` + `i18n/en.json` (translation system, language picker in the top bar, RTL), safe mode (`--no-extensions`, `HN_NO_EXTENSIONS=1` or the toggle on the Extensions page).
* **Reference extensions** in `extensions-examples/`: Quick Actions, Scheduled Restarts, Punishments, Dashboard Widget (frame), AI Assistant (frame + secrets + HTTP), Translations Pack (11 languages).
* **Tooling:** `npm run ext:create | ext:validate | ext:pack | ext:dev | ext:build-examples`.
* New data: `data/ext-data/<id>.json` (extension storage), `data/.ext-key` (secret encryption key, mode 600; **back it up with `data/state.json` or stored secrets become unreadable**), `state.extJobs`, `state.extSecrets`, `state.extensionsSafeMode`.

### What was verified, and how
* `npm test` (74 tests): manifest validation, templating and secret-injection protection, permission and server-access enforcement, storage quotas, HTTP host allow-list, secret encryption and tamper detection, scheduler windows/overlap/failures, crash-loop auto-disable, event reactions, i18n merge/fallback/report, safe mode, malicious packages (traversal, executables, bombs, forged paths, undeclared bridge capabilities), and every reference extension installed from its built `.hnx` and driven end to end.
* `npm run test:ui` and `node tests/ui-ext-smoke.js` (Playwright/Chromium, fake backend router): declarative pages, form/HTML-injection handling, the sandboxed frame bridge, **sandbox-escape attempts (parent access, localStorage, cookies, `fetch`, undeclared capability) all blocked**, AI chat against a stubbed provider, language switch (German, Arabic/RTL), desktop and mobile.
* `server.js` was boot-loaded with stubbed third-party modules (151 routes register, with and without `--no-extensions`).

### Not verified / not done
* **Not run on a real Express install or against live services** (this build environment had no network): the AI assistant's Anthropic/OpenAI/Discord calls follow the providers' public docs as known to the author and were only exercised against stubs. Test with a real key.
* **No server-side extension code tier.** Not offered because Node cannot sandbox it safely.
* The translation system covers navigation/group names/common labels/login subtitle only; the rest of the UI text is still English. The 11 translations are AI-drafted and unreviewed.
* Language is stored per browser, not per account.
* Part E (whole-panel review) was done only for the areas touched in 3.7.0/3.8.0; no first-run in-panel wizard, "what's new" view or extension-failures health card were added (failures are shown on the Extensions page and as notifications).
* `ext:dev` re-packs on change but does not hot-load into a running panel.
* The Punishments, Chat Assistant, Translations and properties-editor products you pointed at were not copied; two of their pages could not be read, so those two were designed from their titles.

## Accessibility and responsive work

Skip link, landmarks, visible focus, `aria-current` on navigation, live regions for toasts/jobs/status, native `<dialog>` confirmations, labelled form fields, tables in focusable scroll regions, reduced-motion support, 44 px touch targets on phones, loading/empty/error states with retry on every new page, and a fix for duplicate mobile menu buttons.

## Bugs fixed in existing code

* Plugin install by URL threw `TypeError: Assignment to constant variable` as soon as the download redirected (a `const` was reassigned in the redirect loop).
* Hard-coded personal paths/addresses as defaults (see above).
* Stale service-worker cache served old scripts after upgrades.
* Duplicate mobile navigation buttons; the old plugin routes ignored server software type (they are now gated).

## Running the checks

```bash
npm run check      # syntax-checks every server, library and browser script
npm test           # 74 unit/integration tests (Node's built-in runner; no extra dependencies)
npm run test:ui    # optional browser smoke test; needs Playwright + Chromium
npm run doctor     # environment report
```

## Known limits (please read)

* **Live vendor APIs were not reachable from the environment this release was built in.** Catalog providers and Modrinth calls follow the vendors' documented response shapes and are tested against fixtures of those shapes, local HTTP servers and a fake router – **not against the live services**. If a vendor changed its API, the panel reports "unexpected response" and refuses to guess, but you should create one server of each software type and install one plugin after upgrading to confirm.
* The full Express application could not be started in that environment (no network to install dependencies). `server.js` was load-tested with stubbed modules (all routes register); route logic was tested through the same handlers behind a fake router; the UI was exercised in headless Chromium against that router. Run `npm test` and click through Create server and Plugins once on your own install.
* Spigot compilation and the Fabric/Purpur/Velocity downloads have never been executed against the real services by this release's tests.
* Setup's interactive prompts were not driven through a TTY in automated tests; the check, backup, rollback and preview logic are tested.
* Existing plugin routes (`/api/plugins/:id/install|update|toggle|…`) still exist and are now blocked for software that cannot use plugins, but they were not otherwise changed.
* Velocity "modern forwarding" still needs the same secret configured manually on each Paper backend (unchanged behaviour).
