# Writing extensions for Hellenic Network (API v2)

An extension is a `.hnx` file (a ZIP) you upload under **Management → Extensions**. It can add pages, buttons, forms, tables, scheduled jobs, event reactions, stored data, translations and web integrations **without changing the panel's code**. Install, enable, update, roll back and remove all happen at runtime.

> **What extensions are not.** Pterodactyl and Blueprint add-ons (PHP/Laravel) cannot run here, and no Pterodactyl API is emulated. Extensions never run code inside the panel process. There is **no server-side extension code tier** in this release (see "Not done").

## Quick start

```bash
npm run ext:create my-extension        # scaffolds extensions-src/my-extension
npm run ext:validate extensions-src/my-extension
npm run ext:pack extensions-src/my-extension   # writes dist/my-extension-0.1.0.hnx (+ .sha256)
npm run ext:dev extensions-src/my-extension    # re-validates and re-packs on every change
npm run ext:build-examples                     # rebuilds extensions-examples/*.hnx
```
Upload the `.hnx`, review the permissions, approve, done. `ext:dev` re-packs automatically but you still upload the result; the panel does not hot-load unpacked folders.

## Two ways to build a page

| | Declarative page | Frame page |
|---|---|---|
| You write | JSON | HTML + JS + CSS |
| Rendered by | the panel (matches its design, responsive, accessible) | an `<iframe sandbox="allow-scripts allow-forms">` with an **opaque origin** |
| Can do | forms, buttons, tables, tabs, alerts, server picker; actions from the capability list | anything a web page can, but only talks to the panel through `hn.call()` |
| Network | none | none (`connect-src 'none'`); use the `http.request` capability |
| Trust needed | low | the frame runs *your* JavaScript in the visitor's browser, isolated from the panel page, cookies and storage |

Browsers never receive action steps: the panel sends only labels and layout, and resolves clicks on the server from the manifest.

## Manifest (`extension.json`, `schemaVersion: 2`)

```json
{
  "schemaVersion": 2, "id": "my-extension", "name": "My extension", "version": "1.0.0",
  "description": "…", "author": "…", "license": "MIT", "homepage": "https://…",
  "panel": { "min": "3.7.0", "max": "9.0.0" },
  "permissions": ["ui.pages", "servers.read", "servers.command"],
  "http": { "hosts": ["api.example.com"] },
  "settings": [{ "key": "apiKey", "label": "API key", "type": "secret" }],
  "pages": [ … ], "events": [ … ], "jobs": [ … ],
  "translations": { "es": "i18n/es.json" },
  "provides": { "software": [], "themes": [], "links": [] }
}
```
`id`: 2–32 chars `a-z0-9-`. `version`: semver `x.y.z`. Setting types: `string`, `boolean`, `number`, `select` (needs `options`), `secret` (stored AES-256-GCM encrypted, never returned to any browser, usable only as `{{secret.key}}` inside `http.request`). JSON Schema for editor completion: `docs/schemas/extension.v2.schema.json` (the validator in `lib/ext-manifest.js` is authoritative).

### Permissions
Every capability needs its permission declared **and approved** by an administrator. Updates that ask for more permissions or hosts stay disabled until re-approved.

| Permission | Allows |
|---|---|
| `ui.pages` | pages (nav or per-server) |
| `servers.read` | `servers.list`, `servers.status` |
| `servers.control` ⚠ | `servers.control` (start/stop/restart) |
| `servers.command` ⚠ | `servers.command` (any console command) |
| `players.read` | `players.list` |
| `players.moderate` ⚠ | `players.moderate` (kick, ban, pardon, whitelist, op, deop, tell) |
| `properties.read` | `properties.read` (server.properties, secrets removed) |
| `storage` | the `storage.*` capabilities (own data only, 5 MB) |
| `http` ⚠ | `http.request`, only to hosts in `http.hosts` (each host is shown separately at approval) |
| `notify`, `audit` | `notify.create`, `audit.write` |
| `events` ⚠, `jobs` ⚠ | event reactions / scheduled jobs |
| `i18n` | translation bundles |
| `software.provide`, `branding.themes`, `navigation.links` | v1 contributions (still supported in v2) |

⚠ = shown as *sensitive* in the approval dialog.

### Pages
```json
{ "id": "main", "title": "My page", "icon": "★", "placement": "nav",        // or "server" (button on the server page)
  "permission": "console_command",   // optional panel permission, or "admin"; omit = any signed-in user
  "serverType": "plugins",           // optional: only on servers whose software supports plugins
  "type": "declarative", "content": { … } }
```
Declarative elements: `stack` (`direction: row|column`), `heading`, `text`, `alert` (`info|warn|error|ok`), `divider`, `tabs`, `serverPicker`, `button`, `form`, `table`.

* **button** `{label, style, confirm, successMessage, needsServer, action:[steps]}`
* **form** `{fields:[{name,type:text|number|select|bool|textarea,label,required,default,min,max,options,maxLength}], submit:{label, confirm, successMessage, action:[steps]}, needsServer, resetOnSubmit}`. Values are validated and coerced on the server against the declared fields; undeclared fields are ignored.
* **table** `{title, source:{capability,args}, columns:[{key,label,format:text|datetime|bool}], rowActions:[{label,style,confirm,when:{key,equals},action:[steps]}], needsServer, refreshSeconds, empty}`. The source must be read-only (`servers.list`, `servers.status`, `players.list`, `properties.read`, `storage.get|list|find`).

Frame page: `{"type":"frame","entry":"index.html","bridge":["servers.list"],"height":600}`. The entry must be a top-level `.html` file in the package; `bridge` lists the only capabilities the page may call. In the page:
```html
<script src="hn-sdk.js"></script>   <!-- served by the panel -->
<script>
  (async () => { const ctx = await hn.ready;          // {lang, dir, serverId, user, isAdmin, settings (non-secret), tokens, messages}
    const servers = await hn.call('servers.list');     // permission-checked on the server for the signed-in user
    hn.resize(500); })();
</script>
```
Frame files are served with `Content-Security-Policy: sandbox allow-scripts allow-forms; default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-ancestors 'self'`. So: no inline `<script>`, no `fetch`, no cookies/localStorage, no access to the parent page.

### Action steps and templating
A step is `{ "capability": "…", "args": {…}, "as": "name" }` or a loop `{ "forEach": { "as": "rec", "source": {read-only step}, "limit": 100, "do": [steps] } }`. Up to 20 steps per action; loops may nest twice.

Templating (`{{…}}`) works in string args: `{{form.field}}`, `{{row.key}}` (clicked table row), `{{server}}` (chosen server ID), `{{user}}` (acting username, or `extension:<id>` for jobs/events), `{{setting.key}}`, `{{event.type|message|server|player|user}}`, `{{vars.name}}` (from `as`), loop variables (`{{rec.player}}`), `{{now}}` (ISO time), `{{minutesFromNow:form.minutes}}`. Rules: a lone placeholder keeps its type (numbers stay numbers); `__proto__`/`constructor` are blocked; text from users is data and is never re-evaluated as a template. `{{secret.name}}` is resolved **only** inside `http.request`, after the host check.

### Capabilities
| Capability | Arguments | Notes |
|---|---|---|
| `servers.list` | – | only servers the acting user may see |
| `servers.status` | `serverId` | `{label, port, running, online, playersOnline, maxPlayers}` |
| `servers.control` | `serverId, action: start\|stop\|restart` | user also needs the panel's start/stop/restart permission |
| `servers.command` | `serverId, command` (≤500 chars, one line) | user needs `console_command` |
| `players.list` | `serverId` | from the latest `list` output in the console history |
| `players.moderate` | `serverId, action, player, reason?` | names `[.A-Za-z0-9_]{1,32}`; user needs `players_actions` |
| `properties.read` | `serverId` | user needs `files_view` |
| `storage.get/set/delete/list` | `key, value?, scope?, prefix?` | `scope:"user"` namespaces by username; keys `[A-Za-z0-9_.:@-]{1,100}`, values ≤64 KB |
| `storage.insert/find/update/remove` | `collection, doc?, where?, sort?, order?, limit?, id?, patch?` | collection `^[a-z][a-z0-9_]{0,31}$`; `where` values or `{eq,ne,lt,lte,gt,gte,contains}`; ≤10,000 docs per collection |
| `http.request` | `url, method?, headers?, body?, timeoutMs?` | https only; host must be in `http.hosts`; no redirects; ≤256 KB response; headers Host/Cookie/Content-Length dropped |
| `notify.create` | `message, serverId?` | |
| `audit.write` | `message` | attributed to the extension and acting user |

Calls by people are limited by **both** the extension's approved permissions **and** the person's own panel permissions and server access. Jobs and event reactions run as the extension and are limited to its approved permissions. Each extension is limited to 600 capability calls per minute.

### Events
`{"on": "player_join", "server": "survival", "contains": "text", "do": [steps]}`. Event names: `server_online`, `server_offline`, `server_crash`, `backup_completed`, `backup_failed`, `player_action`, `player_join`, `player_leave`, `console_line`, `file_change`, `scheduled_task`, `login_failed`, `high_ram`, `low_tps`, `low_disk`, `server_discovered`, or `*`. `player_join/leave` are parsed from console lines of the form `… <name> joined the game` / `left the game` (vanilla and Paper wording; modified servers may differ). Limits: 60 reactions per extension per minute, 5 in flight.

### Jobs
`{"id":"nightly","title":"…","everySeconds":3600 | "dailyAt":"04:00" | "dailyAtSetting":"restartTime","do":[steps]}`. `everySeconds` 60–604800; first run happens one interval after the panel (or the extension) starts. `dailyAt` uses the panel host's local time, runs once per day, and **only within 5 minutes after the scheduled minute** (missed runs are not replayed). Overlapping runs are skipped; a run is marked failed after 60 s; failures notify admins. History (last 20) is on the Extensions page, with a Run now button.

### Crash-loop protection
Five consecutive failed background runs (jobs or event reactions) disable the extension automatically, with the reason shown on the Extensions page and a one-click re-enable.

### Translations
`"translations": {"es": "i18n/es.json"}` with `"i18n"` permission. Each file is a flat JSON object of short strings (≤500 chars, ≤100 KB). Core keys are in `i18n/en.json`; extensions may add their own keys. English is the fallback. Today the panel translates **navigation, group names, a few common labels and the login subtitle**; most other UI text is still English.

### Package limits and safety
ZIP ≤5 MB, ≤4 MB unpacked, ≤100 files. Allowed: `.json .md .txt .png .jpg .webp .html .css .js .woff2`. Rejected: executables, `.php`, `.sh`, `.jar`, `.svg`, symlinks, encrypted entries, `..`/absolute names. `extension.json` itself is never served. v1 packages (`schemaVersion: 1`) stay code-free exactly as before.

### Lifecycle
Install (staged atomically, validated) → approve permissions → enable. Update keeps the previous version (roll back from the page); settings carry over; new permissions/hosts require approval. Remove can keep or delete the extension's stored data and secrets. **Safe mode** (Extensions page toggle, or start with `--no-extensions` / `HN_NO_EXTENSIONS=1`) pauses every extension's pages, jobs, events and translations without removing anything.

## Security model in one page
* Extensions never execute code in the panel process; declarative actions run only manifest-defined steps; frames run in an opaque-origin sandbox with `connect-src 'none'`.
* Every request is authorised on the server: extension permission, person's panel permission, server access, per-extension rate limit.
* Secrets are encrypted at rest (key in `data/.ext-key`, mode 600), never returned, never logged, never put in audit messages.
* Outbound web access is limited to approved hosts with the panel's safe network layer (https only, destination addresses validated at connect time).
* Audit log: installs, permission grants, settings changes, enable/disable/rollback/remove, UI actions, job runs, safe mode.
* **Residual risks:** an approved `servers.command` or `players.moderate` extension can do anything those commands allow. An approved translation bundle can change visible labels. A frame page can show misleading content inside its own box. Approve only extensions you trust; the permission list is the contract. Translation bundles and table row values are treated as untrusted text and always inserted with `textContent`.

## Reference extensions (`extensions-examples/`, sources in `extensions-src/`)
| Package | Shows |
|---|---|
| `quick-actions` | declarative buttons and a broadcast form |
| `scheduled-restarts` | jobs driven by settings (warn, then restart) |
| `punishments` | tabs, forms, table, storage, `forEach`, expiry job |
| `dashboard-widget` | sandboxed frame with the bridge |
| `ai-assistant` | frame + secrets + approved HTTP hosts + per-user storage + admin transcripts |
| `translations-pack` | 11 languages (AI-drafted; needs native review) |

## Not done / known limits
* **No server-side extension code (tier 3).** Node cannot isolate third-party code safely enough to offer it honestly, so extensions that need long-running logic must use jobs/events/HTTP.
* The AI assistant's provider calls follow the providers' public documentation but were **not run against the live services**. The assistant cannot suggest or run panel actions.
* Punishments: no "mute" (vanilla has no such command); temp-ban expiry needs the target server running at that moment.
* `ext:dev` does not hot-load into a running panel.
* Registries for extensions exist but none is provided, and signatures are not implemented (only a SHA-256 for registry downloads).
* Language choice is per browser (localStorage), not saved to the user profile.
