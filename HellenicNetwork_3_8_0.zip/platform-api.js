'use strict';
// Platform layer: branding, system check, software catalog, server creation without templates, extensions,
// egg import and the plugin manager. Registered like operations-api.js, with the same context object.
// Early routes (public branding, index.html, manifest) must be installed before express.static; the rest at the end.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { spawn } = require('child_process');

const branding = require('./lib/branding');
const netLib = require('./lib/net');
const { createCatalog, SOFTWARE, TARGET_VERSION, compareVersions } = require('./lib/catalog');
const { validateSoftwareDef, inspectServerJar } = require('./lib/custom-software');
const { parseEgg, expandStartup } = require('./lib/eggs');
const { createExtensionManager, ExtensionError } = require('./lib/extensions');
const { inspectEnvironment, detectJava, nextFreePort, isPortFree, freeDisk, suggestMemoryGB } = require('./lib/environment');
const { createJobs } = require('./lib/jobs');
const { detectSoftware } = require('./lib/detect');
const { describeJar, evaluateCompat, sha256File } = require('./lib/jarinfo');
const plugins = require('./lib/plugins');
const props = require('./lib/properties');
const { createExtHost } = require('./lib/ext-host');
const { createI18n } = require('./lib/i18n');

const FAMILY_ORDER = ['folia', 'purpur', 'paper', 'spigot', 'bukkit', 'velocity', 'waterfall', 'bungeecord'];
const SERVER_ID = /^[A-Za-z0-9_-]{2,24}$/;

module.exports = function createPlatform(c) {
  const { app, state, config, saveState, writeConfig, audit, notify, requireAdmin, requirePermission, isAdmin, getUsers, safeId, serverIdExists, serverRoot, safePath, inside, networkRoot, processes, ROOT, DATA, configureVelocityToml, getCreationLock, setCreationLock, normalizeRel, assertSafeClonePath, panelVersion, requireAuth, serverInfo, control, writeCommand, history, setHooks } = c;
  const deps = c.deps || {};
  const net = deps.net || netLib;
  const catalog = deps.catalog || createCatalog({ net });
  const modrinth = deps.modrinth || plugins.createModrinth({ net });
  const localPlugins = plugins.createLocal();
  const jobs = createJobs();
  const runProcess = deps.runProcess || defaultRunProcess;
  const extensions = createExtensionManager({ dataDir: DATA, bundledDir: path.join(ROOT, 'bundled-extensions'), state, saveState, panelVersion });
  const brandDir = path.join(DATA, 'branding');
  const canAccessServer = (session, id) => serverAllowed({ panelSession: session }, id);
  async function readProperties(id) {
    const p = await safePath(id, 'server.properties', true), st = await fs.promises.lstat(p.target).catch(() => null);
    if (!st || !st.isFile() || st.size > 1048576) return {};
    const out = {}; for (const [k, v] of Object.entries(props.parse(await fs.promises.readFile(p.target, 'utf8')).values)) if (props.BY_KEY.get(k)?.type !== 'secret') out[k] = v;
    return out;
  }
  const safeMode = () => process.argv.includes('--no-extensions') || process.env.HN_NO_EXTENSIONS === '1' || state.extensionsSafeMode === true;
  const host = deps.host || createExtHost({ state, config, extensions, DATA, saveState, safeId, serverInfo, control, writeCommand, history, readProperties, notify, audit, isAdmin, canAccessServer, net, netOptions: deps.netOptions, jobTimeoutMs: deps.jobTimeoutMs, safeMode });
  const i18n = createI18n({ dir: path.join(ROOT, 'i18n'), extBundles: async () => {
    const out = [];
    for (const e of (await host.active()).values()) {
      if (!e.record.grantedPermissions.includes('i18n')) continue;
      for (const [lang, file] of Object.entries(e.manifest.translations)) { try { out.push({ lang, ext: e.id, messages: JSON.parse(await fs.promises.readFile(path.join(e.dir, file), 'utf8')) }); } catch { /* skip unreadable bundle */ } }
    }
    return out;
  } });
  setHooks?.({ event: (type, message, server, user) => host.emit(type, { message: String(message || '').slice(0, 500), server: server || '', user: user || '' }).catch(() => {}), console: (id, line) => host.emitConsole(id, line) });
  state.customSoftware ||= [];
  state.pluginRecords ||= {};
  state.metrics ||= {};
  state.softwareOverrides ||= {};
  const recOf = id => state.softwareOverrides[id] || config.servers[id]?.software;
  state.extensionRegistries ||= [];

  // ---------- helpers ----------
  const send = (res, e) => {
    const status = e?.status || (e instanceof ExtensionError ? e.status : null) || (e instanceof plugins.PluginError ? e.status : null) || (e?.code && String(e.code).startsWith('NET_') ? 502 : 500);
    if (!e?.status && !(e instanceof ExtensionError) && !(e instanceof plugins.PluginError) && !String(e?.code || '').startsWith('NET_') && !String(e?.code || '').startsWith('CATALOG_')) console.error('[platform]', e);
    const known = e?.status || e instanceof ExtensionError || e instanceof plugins.PluginError || String(e?.code || '').startsWith('NET_') || String(e?.code || '').startsWith('CATALOG_');
    const denied = e?.code === 'EACCES' || e?.code === 'EPERM';
    const message = denied ? 'The panel cannot write to that folder with its operating-system account. Grant write access to the user running the panel, then retry.' : e?.code === 'ENOSPC' ? 'The drive is out of free space.' : known ? e.message : 'Something went wrong on the server. Details were written to the panel log.';
    res.status(denied ? 403 : e?.code === 'ENOSPC' ? 507 : status).json({ error: message, ...(e?.details?.length ? { details: e.details } : {}) });
  };
  const h = fn => async (req, res) => { try { await fn(req, res); } catch (e) { send(res, e); } };
  const bad = (message, status = 400) => Object.assign(new Error(message), { status });
  const brand = () => state.branding || branding.DEFAULTS;
  const serverAllowed = (req, id) => {
    if (!safeId(id)) return false;
    if (isAdmin(req.panelSession)) return true;
    const u = getUsers().find(x => x.username === req.panelSession.username);
    return !Array.isArray(u?.servers) || u.servers.includes('*') || u.servers.includes(id);
  };
  const pickFamily = loaders => FAMILY_ORDER.find(f => (loaders || []).includes(f)) || null;

  // ---------- software registry (built-in + admin + extensions) ----------
  async function allSoftware() {
    const out = [];
    for (const s of Object.values(SOFTWARE)) out.push({ id: s.id, name: s.name, kind: s.kind, description: s.description, supportsPlugins: s.supportsPlugins, pluginLoaders: s.pluginLoaders, trust: s.trust, source: s.source, origin: 'builtin', family: pickFamily(s.pluginLoaders) });
    for (const s of state.customSoftware) out.push({ ...s, id: s.id, origin: s.origin || 'admin', trust: 'unverified', source: s.origin === 'egg' ? 'Imported Pterodactyl egg' : 'Added by an administrator', family: pickFamily(s.pluginLoaders) });
    const contrib = await extensions.contributions();
    for (const s of contrib.software) out.push({ ...s, trust: 'extension', source: `Extension: ${s.extensionName}`, family: pickFamily(s.pluginLoaders) });
    return out;
  }
  const findSoftware = async id => (await allSoftware()).find(s => s.id === id) || null;

  // Software currently associated with a server: recorded at creation (or set by an admin) > detected.
  const detectCache = new Map();
  async function refreshDetection(id) {
    const s = config.servers[id]; if (!s) return null;
    try {
      const dir = serverRoot(id), jarArg = (s.args || [])[(s.args || []).findIndex(a => String(a).toLowerCase() === '-jar') + 1];
      const d = await detectSoftware({ dir, jarName: jarArg && !String(jarArg).startsWith('-') ? path.basename(String(jarArg)) : null });
      detectCache.set(id, { at: Date.now(), value: d });
      return d;
    } catch { detectCache.set(id, { at: Date.now(), value: null }); return null; }
  }
  async function softwareFor(id, { refresh = false } = {}) {
    const s = config.servers[id]; if (!s) return null;
    const rec = recOf(id);
    if (rec?.id) {
      const def = await findSoftware(rec.id);
      const loaders = def?.pluginLoaders || [];
      return { id: rec.id, name: def?.name || rec.id, version: rec.version || null, build: rec.build || null, kind: def?.kind || (s.type === 'velocity' ? 'proxy' : 'server'), supportsPlugins: !!def?.supportsPlugins, pluginLoaders: loaders, family: pickFamily(loaders), via: 'recorded', confidence: 'high', evidence: [rec.manual ? 'Set by an administrator' : 'Installed by the panel'] };
    }
    let hit = detectCache.get(id);
    if (!hit || refresh || Date.now() - hit.at > 5 * 60 * 1000) { await refreshDetection(id); hit = detectCache.get(id); }
    const d = hit?.value;
    if (!d) return { id: null, name: 'Unknown', version: null, supportsPlugins: null, pluginLoaders: [], family: null, via: 'unknown', confidence: 'none', evidence: [] };
    const def = SOFTWARE[d.id] || (['bungeecord', 'waterfall'].includes(d.id) ? { name: d.id === 'waterfall' ? 'Waterfall' : 'BungeeCord', kind: 'proxy', supportsPlugins: true, pluginLoaders: [d.id] } : null);
    return { id: d.id, name: def?.name || d.id, version: d.version, kind: def?.kind || 'server', supportsPlugins: !!def?.supportsPlugins, pluginLoaders: def?.pluginLoaders || [], family: pickFamily(def?.pluginLoaders || []), via: 'detected', confidence: d.confidence, evidence: d.evidence };
  }
  // Synchronous view for server lists (uses the last detection result; never blocks).
  function pluginSupportSync(id) {
    const s = config.servers[id]; if (!s) return null;
    const rec = recOf(id);
    if (rec?.id) { const b = SOFTWARE[rec.id]; if (b) return b.supportsPlugins; const cs = state.customSoftware.find(x => x.id === rec.id); return cs ? !!cs.supportsPlugins : null; }
    const d = detectCache.get(id)?.value; if (!d) return null;
    return d.id === 'bungeecord' || d.id === 'waterfall' ? true : SOFTWARE[d.id] ? SOFTWARE[d.id].supportsPlugins : null;
  }
  const softwareLabelSync = id => { const s = config.servers[id]; if (!s) return null; const rec = recOf(id); if (rec?.id) return { id: rec.id, version: rec.version || null }; const d = detectCache.get(id)?.value; return d ? { id: d.id, version: d.version, detected: true } : null; };
  setTimeout(() => { for (const id of Object.keys(config.servers)) refreshDetection(id); }, 500).unref?.();
  setInterval(() => { for (const id of Object.keys(config.servers)) refreshDetection(id); }, 5 * 60 * 1000).unref?.();

  // ---------- upload middleware ----------
  const memUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1 } }).single('package');
  const withMem = (req, res, next) => memUpload(req, res, err => err ? send(res, err instanceof multer.MulterError ? bad(err.code === 'LIMIT_FILE_SIZE' ? 'Files must be 5 MB or smaller.' : `Upload failed: ${err.message}`) : err) : next());
  function diskUpload({ field, maxBytes, prepare, label }) {
    return async (req, res, next) => {
      let dir;
      try { dir = await prepare(req); } catch (e) { return send(res, e); }
      req.stagingDir = dir;
      const mw = multer({ storage: multer.diskStorage({ destination: (_r, _f, cb) => cb(null, dir), filename: (_r, _f, cb) => cb(null, `${crypto.randomUUID()}.upload`) }), limits: { fileSize: maxBytes, files: 1 } }).single(field);
      mw(req, res, async err => {
        if (!err) return next();
        await fs.promises.rm(dir, { recursive: true, force: true }).catch(() => {});
        send(res, err instanceof multer.MulterError ? bad(err.code === 'LIMIT_FILE_SIZE' ? `${label} must be ${Math.round(maxBytes / 1048576)} MB or smaller.` : `Upload failed: ${err.message}`) : err);
      });
    };
  }
  const cleanStaging = req => req.stagingDir ? fs.promises.rm(req.stagingDir, { recursive: true, force: true }).catch(() => {}) : Promise.resolve();

  async function defaultRunProcess(cmd, args, { cwd, timeoutMs, onLine }) {
    return new Promise((resolve, reject) => {
      const child = spawn(cmd, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
      let tail = '', done = false;
      const timer = setTimeout(() => { if (!done) { child.kill('SIGKILL'); reject(bad('The build timed out and was stopped.', 504)); } }, timeoutMs);
      const feed = chunk => { tail += chunk.toString(); let i; while ((i = tail.indexOf('\n')) >= 0) { onLine(tail.slice(0, i).replace(/\r$/, '')); tail = tail.slice(i + 1); } };
      child.stdout.on('data', feed); child.stderr.on('data', feed);
      child.on('error', e => { done = true; clearTimeout(timer); reject(e.code === 'ENOENT' ? bad(`Could not run “${cmd}”. Is it installed?`) : e); });
      child.on('close', code => { done = true; clearTimeout(timer); if (tail) onLine(tail); code === 0 ? resolve() : reject(bad(`The build process exited with code ${code}. See the job log for details.`)); });
    });
  }

  // =====================================================================
  // EARLY routes: must be registered before express.static
  // =====================================================================
  function installEarly() {
    state.branding = { ...branding.DEFAULTS, ...(state.branding || {}) };
    const indexFile = path.join(ROOT, 'public', 'index.html');
    app.get(['/', '/index.html'], (req, res, next) => {
      fs.promises.readFile(indexFile, 'utf8').then(html => { res.set({ 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' }).send(branding.renderIndex(html, brand())); }, next);
    });
    app.get('/manifest.webmanifest', (req, res) => res.set({ 'Content-Type': 'application/manifest+json', 'Cache-Control': 'no-cache' }).send(JSON.stringify(branding.manifestFor(brand()))));
    app.get('/branding.css', async (req, res) => {
      const contrib = await extensions.contributions().catch(() => ({ links: [] }));
      res.set({ 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'no-cache' }).send(branding.cssFor(brand()) + (contrib.links.length ? '' : ''));
    });
    for (const kind of ['logo', 'icon']) {
      app.get(`/branding/${kind}`, async (req, res) => {
        const file = await branding.findAsset(brandDir, kind);
        if (!file) return res.status(404).end();
        const types = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', ico: 'image/x-icon' };
        res.set({ 'Content-Type': types[path.extname(file).slice(1)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'public, max-age=3600', 'Content-Security-Policy': "default-src 'none'; sandbox" }).sendFile(file);
      });
    }
    app.get('/api/branding', h(async (req, res) => {
      const contrib = await extensions.contributions().catch(() => ({ links: [], themes: [] }));
      const view = branding.publicView(brand());
      res.set('Cache-Control', 'no-cache').json({ ...view, links: [...view.links, ...contrib.links.map(l => ({ ...l, fromExtension: true }))], panelVersion });
    }));

    // Gate every plugin route for servers whose software cannot use plugins (new and legacy routes alike).
    app.use('/api/plugins/:id', async (req, res, next) => {
      try {
        const id = req.params.id;
        if (!safeId(id)) return next();
        const exempt = (req.method === 'GET' && req.path === '/manager') || (req.method === 'PUT' && req.path === '/software');
        if (exempt) return next();
        const sw = await softwareFor(id);
        if (sw && sw.supportsPlugins === false) return res.status(409).json({ error: `${config.servers[id].label || id} runs ${sw.name}, which does not support plugins.` });
        next();
      } catch (e) { send(res, e); }
    });
  }

  // =====================================================================
  // LATE routes: installed after the existing API (per-server access middleware already applied)
  // =====================================================================
  function installLate() {
    // ----- branding admin -----
    const saveBranding = (patch, req, what) => {
      const r = branding.validate(patch, brand());
      if (r.errors.length) throw bad(r.errors[0], 400);
      state.branding = { ...r.value, assetVersion: (brand().assetVersion || 0) + 1 };
      saveState(); audit(req, 'branding_update', { message: what }); return state.branding;
    };
    app.put('/api/branding', requireAdmin, h(async (req, res) => {
      const b = req.body || {};
      const patch = {}; for (const k of ['name', 'shortName', 'colors', 'labels', 'links', 'footer']) if (b[k] !== undefined) patch[k] = b[k];
      if (!Object.keys(patch).length) throw bad('Nothing to change.');
      const r = branding.validate(patch, brand());
      if (r.errors.length) return res.status(400).json({ error: r.errors[0], details: r.errors });
      saveBranding(patch, req, `Updated: ${Object.keys(patch).join(', ')}`);
      res.json({ ok: true, branding: branding.publicView(brand()) });
    }));
    app.put('/api/branding/asset/:kind', requireAdmin, h(async (req, res) => {
      const kind = req.params.kind; if (!['logo', 'icon'].includes(kind)) throw bad('Unknown image type.', 404);
      const img = branding.parseImageUpload(kind, req.body?.data); if (img.error) throw bad(img.error);
      await branding.saveAsset(brandDir, kind, img);
      state.branding = { ...brand(), [kind === 'logo' ? 'hasLogo' : 'hasIcon']: true, assetVersion: (brand().assetVersion || 0) + 1 }; saveState();
      audit(req, 'branding_asset', { message: `Replaced ${kind}` });
      res.json({ ok: true, branding: branding.publicView(brand()) });
    }));
    app.delete('/api/branding/asset/:kind', requireAdmin, h(async (req, res) => {
      const kind = req.params.kind; if (!['logo', 'icon'].includes(kind)) throw bad('Unknown image type.', 404);
      const f = await branding.findAsset(brandDir, kind); if (f) await fs.promises.rm(f, { force: true });
      state.branding = { ...brand(), [kind === 'logo' ? 'hasLogo' : 'hasIcon']: false, assetVersion: (brand().assetVersion || 0) + 1 }; saveState();
      audit(req, 'branding_asset', { message: `Removed ${kind}` });
      res.json({ ok: true, branding: branding.publicView(brand()) });
    }));
    app.post('/api/branding/reset', requireAdmin, h(async (req, res) => {
      for (const kind of ['logo', 'icon']) { const f = await branding.findAsset(brandDir, kind); if (f) await fs.promises.rm(f, { force: true }); }
      state.branding = { ...branding.DEFAULTS, assetVersion: (brand().assetVersion || 0) + 1 }; saveState();
      audit(req, 'branding_reset', { message: 'Branding reset to defaults' });
      res.json({ ok: true, branding: branding.publicView(brand()) });
    }));
    app.get('/api/branding/themes', requireAdmin, h(async (req, res) => { res.json({ themes: (await extensions.contributions()).themes }); }));

    // ----- system check -----
    app.get('/api/platform/environment', requireAdmin, h(async (req, res) => {
      res.json(await inspectEnvironment({ root: ROOT, config, panelPort: Number(config.panel.port) || null }));
    }));

    // ----- catalog -----
    app.get('/api/catalog', requireAdmin, h(async (req, res) => { res.json({ target: TARGET_VERSION, software: await allSoftware() }); }));
    app.get('/api/catalog/:id/versions', requireAdmin, h(async (req, res) => {
      const sw = await findSoftware(req.params.id); if (!sw) throw bad('Unknown software.', 404);
      if (sw.origin === 'builtin') return res.json(await catalog.listVersions(sw.id));
      const versions = (sw.versions || []).map(v => ({ version: v.version, stable: true, verified: !!v.sha256 })).sort((a, b) => compareVersions(b.version, a.version));
      res.json({ software: sw.id, versions, target: TARGET_VERSION, targetAvailable: versions.some(v => v.version === TARGET_VERSION), source: sw.source });
    }));
    app.get('/api/catalog/:id/builds', requireAdmin, h(async (req, res) => {
      const sw = await findSoftware(req.params.id); if (!sw) throw bad('Unknown software.', 404);
      res.json({ builds: sw.origin === 'builtin' ? await catalog.builds(sw.id, String(req.query.version || '')) : [] });
    }));

    // ----- custom software (administrator-defined) -----
    app.get('/api/custom-software', requireAdmin, (req, res) => res.json({ software: state.customSoftware }));
    app.put('/api/custom-software', requireAdmin, h(async (req, res) => {
      const r = validateSoftwareDef(req.body?.software, { origin: req.body?.software?.origin === 'egg' ? 'egg' : 'admin' });
      if (!r.value) return res.status(400).json({ error: r.errors[0], details: r.errors });
      if (SOFTWARE[r.value.id]) throw bad('That ID belongs to built-in software. Choose another.', 409);
      const prev = state.customSoftware.find(x => x.id === r.value.id);
      const merged = { ...prev, ...r.value, origin: prev?.origin || 'admin', startupTemplate: prev?.startupTemplate, egg: prev?.egg, versions: r.value.versions.map(v => ({ ...(prev?.versions || []).find(p => p.version === v.version), ...v })) };
      state.customSoftware = [...state.customSoftware.filter(x => x.id !== merged.id), merged]; saveState();
      audit(req, 'custom_software_saved', { message: merged.id });
      res.json({ ok: true, software: merged });
    }));
    app.delete('/api/custom-software/:id', requireAdmin, h(async (req, res) => {
      const idx = state.customSoftware.findIndex(x => x.id === req.params.id); if (idx < 0) throw bad('Not found.', 404);
      const inUse = Object.entries(config.servers).filter(([, s]) => s.software?.id === req.params.id).map(([k]) => k);
      state.customSoftware.splice(idx, 1); saveState();
      await fs.promises.rm(path.join(DATA, 'software', req.params.id), { recursive: true, force: true });
      audit(req, 'custom_software_removed', { message: req.params.id });
      res.json({ ok: true, serversUsingIt: inUse });
    }));
    const swUpload = diskUpload({ field: 'jar', maxBytes: 300 * 1024 * 1024, label: 'Server JAR', prepare: async req => { const d = path.join(DATA, 'software', '.staging-' + crypto.randomUUID()); await fs.promises.mkdir(d, { recursive: true, mode: 0o700 }); return d; } });
    app.post('/api/custom-software/:id/upload', requireAdmin, swUpload, async (req, res) => {
      try {
        const def = state.customSoftware.find(x => x.id === req.params.id); if (!def) throw bad('Add the software definition first.', 404);
        const version = String(req.query.version || ''); if (!/^[A-Za-z0-9._+-]{1,40}$/.test(version)) throw bad('Enter a valid version.');
        if (!req.file) throw bad('Choose a JAR file to upload.');
        const info = await inspectServerJar(req.file.path);
        const dir = path.join(DATA, 'software', def.id); await fs.promises.mkdir(dir, { recursive: true, mode: 0o700 });
        const name = `${version}.jar`; await fs.promises.copyFile(req.file.path, path.join(dir, name));
        def.versions = [...(def.versions || []).filter(v => v.version !== version), { version, upload: name, sha256: info.sha256, size: req.file.size, addedBy: req.panelSession.username, addedAt: new Date().toISOString() }]; saveState();
        audit(req, 'custom_software_upload', { message: `${def.id} ${version} sha256 ${info.sha256}` });
        res.json({ ok: true, version, sha256: info.sha256, warnings: [...info.warnings, 'Uploaded files are not verified against any publisher. Only use JARs from sources you trust.'] });
      } catch (e) { send(res, e); } finally { await cleanStaging(req); }
    });

    // ----- eggs -----
    app.post('/api/eggs/preview', requireAdmin, h(async (req, res) => {
      const r = parseEgg(req.body?.egg); if (!r.ok) return res.status(400).json({ error: r.error, report: r.report });
      res.json({ importable: r.importable, verdict: r.verdict, profile: r.profile, report: r.report, installScriptPreview: r.installScriptPreview });
    }));
    app.post('/api/eggs/import', requireAdmin, h(async (req, res) => {
      const r = parseEgg(req.body?.egg); if (!r.ok) throw bad(r.error);
      if (!r.importable) throw bad('This egg cannot be imported: ' + (r.report.unsupported[0] || 'unsupported startup command.'));
      if (req.body?.confirm !== true) throw bad('Review the compatibility report and confirm the import.');
      let id = r.profile.id, n = 2; while (SOFTWARE[id] || state.customSoftware.some(x => x.id === id)) id = `${r.profile.id.slice(0, 28)}-${n++}`;
      state.customSoftware.push({ ...r.profile, id }); saveState();
      audit(req, 'egg_imported', { message: `${r.profile.egg.name} as ${id}` });
      res.json({ ok: true, id, nextStep: 'Add a server JAR version to this software (URL or upload), then create a server from it.' });
    }));

    // ----- extensions -----
    app.get('/api/extensions', requireAdmin, h(async (req, res) => {
      const installed = await extensions.list(), bundled = (await extensions.listBundled()).map(b => ({ ...b, installed: installed.find(i => i.id === b.id)?.version || null }));
      for (const x of installed) if (x.manifest?.schemaVersion === 2) { x.secretsSet = Object.fromEntries(x.manifest.settings.filter(t => t.type === 'secret').map(t => [t.key, host.secrets.has(x.id, t.key)])); x.jobs = await host.jobStatus(x.id); }
      res.json({ installed, bundled, registries: state.extensionRegistries, permissions: extensions.PERMISSIONS, sensitive: [...require('./lib/ext-manifest').SENSITIVE], panelVersion, formats: ['native v1/v2 package (.hnx/.bpext zip)', 'Pterodactyl egg (.json)'] });
    }));
    app.post('/api/extensions/check', requireAdmin, withMem, h(async (req, res) => {
      if (!req.file) throw bad('Choose a file to check.');
      const r = await extensions.inspect(req.file.buffer); const { files, egg, ...safe } = r;
      res.json({ ...safe, egg: egg ? { name: egg.name } : undefined, fileCount: files?.length });
    }));
    app.post('/api/extensions/install', requireAdmin, withMem, h(async (req, res) => {
      if (!req.file) throw bad('Choose a package to install.');
      const r = await extensions.installPackage(req.file.buffer, { type: 'upload', name: path.basename(String(req.file.originalname || '')).slice(0, 80) });
      audit(req, 'extension_installed', { message: `${r.manifest.id} ${r.manifest.version}` }); host.invalidate();
      res.json({ ok: true, extension: await extensions.view(r.manifest.id), addedPermissions: r.addedPermissions, message: r.record.lastResult.message + (r.record.enabled ? '' : ' It is disabled until you review and approve its permissions.') });
    }));
    app.post('/api/extensions/bundled/:id/install', requireAdmin, h(async (req, res) => {
      const r = await extensions.installBundled(req.params.id);
      audit(req, 'extension_installed', { message: `${r.manifest.id} ${r.manifest.version} (bundled)` });
      res.json({ ok: true, extension: await extensions.view(r.manifest.id), message: r.record.lastResult.message });
    }));
    app.post('/api/extensions/:id/enable', requireAdmin, h(async (req, res) => { const v = await extensions.enable(req.params.id, Array.isArray(req.body?.approve) ? req.body.approve : []); audit(req, 'extension_enabled', { message: req.params.id }); host.invalidate(); res.json({ ok: true, extension: v }); }));
    app.post('/api/extensions/:id/disable', requireAdmin, h(async (req, res) => { const v = await extensions.disable(req.params.id); audit(req, 'extension_disabled', { message: req.params.id }); host.invalidate(); res.json({ ok: true, extension: v }); }));
    app.post('/api/extensions/:id/rollback', requireAdmin, h(async (req, res) => { const v = await extensions.rollback(req.params.id); audit(req, 'extension_rollback', { message: req.params.id }); host.invalidate(); res.json({ ok: true, extension: v }); }));
    app.put('/api/extensions/:id/settings', requireAdmin, h(async (req, res) => {
      const id = req.params.id, values = { ...(req.body?.values || {}) }, m = await extensions.loadManifestOf(id);
      if (!m) throw bad('Extension not found.', 404);
      for (const sset of m.settings.filter(x => x.type === 'secret')) {
        if (!Object.hasOwn(values, sset.key)) continue; const v = values[sset.key]; delete values[sset.key];
        if (v === null) host.secrets.clear(id, sset.key); else if (typeof v === 'string' && v.length > 0 && v.length <= 2000 && !/[\r\n\0]/.test(v)) host.secrets.set(id, sset.key, v); else if (v !== '') throw bad(`${sset.label} must be a single line of up to 2000 characters.`);
      }
      const ext = await extensions.setSettings(id, values); host.invalidate();
      audit(req, 'extension_settings', { message: `${id}: ${Object.keys(req.body?.values || {}).join(', ')}` });
      res.json({ ok: true, extension: ext, secretsSet: Object.fromEntries(m.settings.filter(x => x.type === 'secret').map(x => [x.key, host.secrets.has(id, x.key)])) });
    }));
    app.delete('/api/extensions/:id', requireAdmin, h(async (req, res) => { await extensions.remove(req.params.id); if (req.query.keepData !== '1') host.removeData(req.params.id); host.invalidate(); audit(req, 'extension_removed', { message: `${req.params.id}${req.query.keepData === '1' ? ' (data kept)' : ''}` }); res.json({ ok: true }); }));
    app.put('/api/extension-registries', requireAdmin, h(async (req, res) => {
      const urls = Array.isArray(req.body?.urls) ? req.body.urls.map(String) : null; if (!urls || urls.length > 5) throw bad('Provide up to 5 registry URLs.');
      for (const u of urls) { try { const p = new URL(u); if (p.protocol !== 'https:' || p.username || p.password) throw 0; } catch { throw bad(`“${u.slice(0, 80)}” is not a plain https URL.`); } }
      state.extensionRegistries = [...new Set(urls)]; saveState(); res.json({ ok: true, registries: state.extensionRegistries });
    }));
    app.get('/api/extensions-discover', requireAdmin, h(async (req, res) => {
      const out = [], errors = [];
      for (const url of state.extensionRegistries) {
        try {
          const d = await net.getJson(url, { maxBytes: 2 * 1024 * 1024, timeoutMs: 15000 });
          for (const e of (Array.isArray(d?.extensions) ? d.extensions : []).slice(0, 200)) {
            if (!/^[a-z0-9][a-z0-9-]{1,39}$/.test(String(e?.id || '')) || !/^\d+\.\d+\.\d+/.test(String(e?.version || ''))) continue;
            out.push({ registry: url, id: e.id, name: String(e.name || e.id).slice(0, 60), version: e.version, description: String(e.description || '').slice(0, 300), author: String(e.author || '').slice(0, 80), permissions: Array.isArray(e.permissions) ? e.permissions.filter(p => typeof p === 'string').slice(0, 10) : [], hasChecksum: /^[a-f0-9]{64}$/i.test(String(e.sha256 || '')) });
          }
        } catch (e) { errors.push({ registry: url, error: e.message }); }
      }
      res.json({ extensions: out, errors, note: state.extensionRegistries.length ? null : 'No extension registries are configured. This panel does not ship a default registry; add one you trust, or install a package file.' });
    }));
    app.post('/api/extensions-registry-install', requireAdmin, h(async (req, res) => {
      const { registry, id } = req.body || {};
      if (!state.extensionRegistries.includes(registry)) throw bad('Unknown registry.', 404);
      const d = await net.getJson(registry, { maxBytes: 2 * 1024 * 1024, timeoutMs: 15000 });
      const entry = (d?.extensions || []).find(e => e?.id === id); if (!entry) throw bad('That extension is no longer listed.', 404);
      if (!/^[a-f0-9]{64}$/i.test(String(entry.sha256 || ''))) throw bad('This listing has no SHA-256 checksum, so it cannot be installed from the registry.');
      const tmp = path.join(DATA, `.ext-download-${crypto.randomUUID()}`);
      try {
        await net.downloadToFile(String(entry.downloadUrl), tmp, { maxBytes: 5 * 1024 * 1024, expected: { algorithm: 'sha256', value: entry.sha256 } });
        const r = await extensions.installPackage(await fs.promises.readFile(tmp), { type: 'registry', registry });
        audit(req, 'extension_installed', { message: `${r.manifest.id} ${r.manifest.version} (registry, checksum verified)` });
        res.json({ ok: true, extension: await extensions.view(r.manifest.id), message: r.record.lastResult.message });
      } finally { await fs.promises.rm(tmp, { force: true }).catch(() => {}); }
    }));

    // ----- server creation -----
    installCreate();
    // ----- plugin manager -----
    installPluginManager();
    installProperties();
    installExtHost();
    if (!deps.noScheduler) host.startScheduler();
  }

  // ---------------------------------------------------------------------
  // Create-server (no template needed)
  // ---------------------------------------------------------------------
  function normalizeCreate(body) {
    const b = body || {}, errors = [];
    const serverId = String(b.serverId || '');
    if (!SERVER_ID.test(serverId)) errors.push('Server ID must be 2–24 letters, numbers, _ or -.');
    else if (serverIdExists(serverId)) errors.push('That server ID is already in use.');
    const label = String(b.label || serverId).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 64) || serverId;
    const port = Number(b.port);
    if (!Number.isInteger(port) || port < 1024 || port > 65535) errors.push('Choose a port between 1024 and 65535.');
    else if (Object.values(config.servers).some(s => Number(s.port) === port)) errors.push(`Port ${port} is already used by another server in the panel.`);
    const ramGB = Number(b.ramGB ?? 2);
    if (!Number.isInteger(ramGB) || ramGB < 1 || ramGB > 32) errors.push('Memory must be a whole number of GB from 1 to 32.');
    const host = String(b.host || '127.0.0.1').trim();
    if (!/^[A-Za-z0-9:._-]{1,253}$/.test(host)) errors.push('Enter a valid host name or IP address.');
    const javaCommand = String(b.javaCommand || 'java').trim();
    if (!javaCommand || javaCommand.length > 300 || /[\r\n\0]/.test(javaCommand)) errors.push('Enter a valid Java command or path.');
    const version = String(b.version || ''), build = String(b.build || 'latest');
    if (!/^[A-Za-z0-9._+-]{1,40}$/.test(version)) errors.push('Choose a version.');
    return { errors, v: { serverId, label, port, ramGB, host, javaCommand, software: String(b.software || ''), version, build, folder: String(b.folder || serverId), acceptEula: b.acceptEula === true, acknowledgeUnverified: b.acknowledgeUnverified === true, vars: b.vars && typeof b.vars === 'object' ? b.vars : {} } };
  }

  // Resolve a software+version to a concrete, verifiable source (built-in, admin-defined, extension, egg).
  async function resolveSource(sw, version, build) {
    if (sw.origin === 'builtin') return catalog.resolve(sw.id, version, build);
    const entry = (sw.versions || []).find(v => v.version === version);
    if (!entry) throw bad(`${sw.name} has no version “${version}”. Add one first.`, 404);
    const warnings = [];
    let method = 'download', url = null, uploadPath = null;
    if (entry.upload) {
      if (sw.origin === 'extension') throw bad('Extensions cannot ship server JARs.', 400);
      uploadPath = path.join(DATA, 'software', sw.id, path.basename(entry.upload)); method = 'copy';
      warnings.push('This JAR was uploaded by an administrator and has not been checked against any publisher.');
    } else { url = entry.url; if (!url) throw bad(`${sw.name} ${version} has no download source. Add a URL or upload a JAR.`); }
    const expected = entry.sha256 ? { algorithm: 'sha256', value: entry.sha256 } : null;
    if (!expected) warnings.push('No checksum is recorded for this download, so its integrity cannot be verified.');
    return { software: sw.id, version, build: null, kind: sw.kind, trust: 'unverified', hosts: null, warnings, jar: sw.jar, url, uploadPath, fileName: path.basename(entry.upload || url || 'server.jar'), expected, javaMajor: entry.javaMajor || null, method, custom: true, needsAcknowledgement: !expected || sw.origin !== 'extension' };
  }

  async function planCreate(body) {
    const { errors, v } = normalizeCreate(body);
    const plan = { checks: [], warnings: [], willDo: [], resolved: null, requires: {} };
    const sw = await findSoftware(v.software);
    if (!sw) errors.push('Choose server software.');
    let resolved = null;
    if (sw && /^[A-Za-z0-9._+-]{1,40}$/.test(v.version)) {
      try { resolved = await resolveSource(sw, v.version, v.build); } catch (e) { errors.push(e.message); }
    }
    let java = null;
    if (resolved) {
      java = await detectJava(v.javaCommand);
      const need = resolved.javaMajor;
      if (!java.found) errors.push(`${java.error} Install Java${need ? ` ${need}` : ''} or set the Java command.`);
      else if (need && java.major < need) errors.push(`${sw.name} ${v.version} needs Java ${need} or newer, but ${v.javaCommand} is Java ${java.major}.`);
      else plan.checks.push({ label: 'Java', status: 'ok', detail: `Java ${java.major}${need ? ` (needs ${need}+)` : ''}` });
      if (resolved.method === 'buildtools') { const { execFile } = require('child_process'); const git = await new Promise(r => execFile('git', ['--version'], { timeout: 5000 }, e => r(!e))); if (!git) errors.push('Spigot is compiled with BuildTools, which needs Git. Install Git first.'); else plan.checks.push({ label: 'Git', status: 'ok', detail: 'Found' }); }
      plan.warnings.push(...(resolved.warnings || []));
      if (resolved.needsAcknowledgement && !v.acknowledgeUnverified) plan.requires.acknowledgeUnverified = true;
      if (resolved.kind === 'server' && !v.acceptEula) plan.requires.acceptEula = true;
    }
    if (!(await isPortFree(v.port, '0.0.0.0')) && !errors.some(e => /port/i.test(e))) plan.warnings.push(`Port ${v.port} is currently in use on this machine. The server will not start until it is free.`);
    let network = null, dest = null;
    try {
      network = await fs.promises.realpath(path.resolve(ROOT, config.networkRoot));
      const clean = normalizeRel(v.folder || v.serverId); dest = path.resolve(network, clean);
      assertSafeClonePath(network, dest);
      if (dest === network || fs.existsSync(dest)) errors.push('That folder already exists. Choose another folder name.');
      else {
        const disk = await freeDisk(network);
        if (disk && disk.freeBytes < 1024 ** 3) errors.push(`Only ${(disk.freeBytes / 1024 ** 3).toFixed(2)} GB free where servers are stored; at least 1 GB is needed.`);
        v.folder = clean;
      }
    } catch (e) { errors.push(e.message || 'The destination folder is not valid.'); }
    if (resolved) {
      plan.resolved = { software: sw.name, version: v.version, build: resolved.build, channel: resolved.channel || null, source: sw.source, trust: resolved.trust, verification: resolved.expected ? `${resolved.expected.algorithm.toUpperCase()} checksum from the publisher` : 'none available', method: resolved.method, javaMajor: resolved.javaMajor || null };
      plan.willDo = [`Create folder ${dest ? path.relative(ROOT, dest) : v.folder}`, resolved.method === 'buildtools' ? 'Download BuildTools and compile Spigot on this machine (several minutes)' : resolved.method === 'copy' ? 'Copy the uploaded JAR after re-checking its SHA-256' : `Download ${resolved.fileName}${resolved.expected ? ' and verify its checksum' : ''}`,
        resolved.kind === 'proxy' ? 'Write velocity.toml (routes to your existing servers) and a private forwarding.secret' : `Write server.properties (port ${v.port})${v.acceptEula ? ' and eula.txt (you accepted the Minecraft EULA)' : ' — eula.txt is NOT written; accept the EULA to start'}`,
        `Add “${v.label}” (${v.host}:${v.port}, ${v.ramGB} GB) to the panel configuration`];
    }
    return { errors, v, sw, resolved, java, network, dest, plan };
  }

  function installCreate() {
    app.post('/api/create-server/preflight', requireAdmin, h(async (req, res) => {
      const p = await planCreate(req.body);
      const env = await inspectEnvironment({ root: ROOT, config, requiredJava: p.resolved?.javaMajor || null });
      const sug = { port: await nextFreePort(25565, new Set(Object.values(config.servers).map(s => Number(s.port)))), ramGB: env.facts.suggestedMemoryGB };
      res.json({ ok: p.errors.length === 0, errors: p.errors, warnings: p.plan.warnings, checks: p.plan.checks, resolved: p.plan.resolved, willDo: p.plan.willDo, requires: p.plan.requires, suggestions: sug });
    }));
    app.get('/api/create-server/defaults', requireAdmin, h(async (req, res) => {
      const taken = new Set(Object.values(config.servers).map(s => Number(s.port)));
      res.json({ port: await nextFreePort(25565, taken), ramGB: suggestMemoryGB(require('os').totalmem(), Object.keys(config.servers).length), target: TARGET_VERSION });
    }));
    app.get('/api/jobs/:id', requireAdmin, (req, res) => { const j = jobs.get(req.params.id); if (!j) return res.status(404).json({ error: 'That job is no longer available.' }); res.json(jobs.view(j)); });
    app.post('/api/create-server', requireAdmin, h(async (req, res) => {
      if (getCreationLock()) throw bad('Another server is being created. Wait for it to finish, then try again.', 409);
      const p = await planCreate(req.body);
      if (p.errors.length) return res.status(400).json({ error: p.errors[0], details: p.errors });
      if (p.plan.requires.acceptEula) throw bad('Accept the Minecraft EULA (https://aka.ms/MinecraftEULA) to create a server that can start.');
      if (p.plan.requires.acknowledgeUnverified) throw bad('Confirm that you trust this unverified download.');
      setCreationLock(true);
      const t = jobs.create({ title: `Create ${p.v.label}`, owner: req.panelSession.username, steps: [{ key: 'prepare', label: 'Prepare folder' }, { key: 'fetch', label: p.resolved.method === 'buildtools' ? 'Build server' : 'Get server file' }, { key: 'verify', label: 'Verify file' }, { key: 'configure', label: 'Write configuration' }, { key: 'register', label: 'Add to panel' }] });
      res.status(202).json({ jobId: t.job.id });
      runCreate(t, p, req).catch(e => t.fail(e.message || 'Creation failed.')).finally(() => setCreationLock(false));
    }));
  }

  async function runCreate(t, p, req) {
    const { v, sw, resolved, network, dest } = p;
    let temp = null, registered = false, secretCreated = false;
    const rollback = async () => { if (!registered) { delete config.servers[v.serverId]; delete state.metrics[v.serverId]; } for (const d of [temp, dest]) if (d && inside(network, d) && d !== network) await fs.promises.rm(d, { recursive: true, force: true }).catch(() => {}); };
    try {
      t.start('prepare');
      temp = path.join(path.dirname(dest), `.blockpanel-create-${crypto.randomUUID()}`); assertSafeClonePath(network, temp);
      await fs.promises.mkdir(path.dirname(dest), { recursive: true }); await fs.promises.mkdir(temp);
      t.done('prepare', path.relative(ROOT, dest));

      t.start('fetch', resolved.method === 'buildtools' ? 'Downloading BuildTools…' : 'Starting download…');
      const staged = path.join(temp, 'download.part');
      let result = { verified: null, sha256: null };
      if (resolved.method === 'download') {
        let lastPct = -1;
        result = await net.downloadToFile(resolved.url, staged, { allowHosts: resolved.hosts || null, expected: resolved.expected, maxBytes: 300 * 1024 * 1024, timeoutMs: 60000, onProgress: (b, total) => { const pct = total ? Math.floor(b / total * 100) : -1; if (pct !== lastPct) { lastPct = pct; t.progress('fetch', total ? `${pct}% of ${(total / 1048576).toFixed(1)} MB` : `${(b / 1048576).toFixed(1)} MB`); } } });
        t.done('fetch', `${(result.bytes / 1048576).toFixed(1)} MB downloaded`);
      } else if (resolved.method === 'copy') {
        const actual = await sha256File(resolved.uploadPath).catch(() => { throw bad('The uploaded JAR is missing from the panel data folder.', 404); });
        if (resolved.expected && actual !== resolved.expected.value) throw bad('The stored JAR no longer matches its recorded SHA-256. It may have been modified; it was not used.');
        await fs.promises.copyFile(resolved.uploadPath, staged, fs.constants.COPYFILE_EXCL);
        result = { verified: 'sha256', sha256: actual }; t.done('fetch', 'Copied uploaded JAR');
      } else {
        const buildDir = path.join(temp, 'build'); await fs.promises.mkdir(buildDir);
        const bt = path.join(buildDir, 'BuildTools.jar');
        await net.downloadToFile(resolved.url, bt, { allowHosts: resolved.hosts, maxBytes: 64 * 1024 * 1024, timeoutMs: 60000 });
        t.progress('fetch', 'Compiling Spigot with BuildTools (this takes a while)…');
        await runProcess(v.javaCommand, ['-jar', 'BuildTools.jar', '--rev', resolved.buildRevision], { cwd: buildDir, timeoutMs: 45 * 60 * 1000, onLine: l => t.note(l) });
        const built = (await fs.promises.readdir(buildDir)).find(f => /^spigot-\d[\w.-]*\.jar$/.test(f));
        if (!built) throw bad('BuildTools finished but did not produce a Spigot JAR. See the job log.');
        await fs.promises.rename(path.join(buildDir, built), staged);
        await fs.promises.rm(buildDir, { recursive: true, force: true });
        result = { verified: null, sha256: await sha256File(staged) }; t.done('fetch', `Built ${built}`);
      }

      t.start('verify');
      const info = await inspectServerJar(staged);
      const jarPath = path.join(temp, resolved.jar);
      await fs.promises.rename(staged, jarPath);
      t.done('verify', `${result.verified ? result.verified.toUpperCase() + ' checksum matched' : 'Valid runnable JAR (no publisher checksum)'}${info.warnings.length ? ' · ' + info.warnings[0] : ''}`);

      t.start('configure');
      const isProxy = resolved.kind === 'proxy';
      if (isProxy) {
        const tomlTemplate = await fs.promises.readFile(path.join(ROOT, 'templates', 'velocity.toml'), 'utf8');
        const backends = Object.entries(config.servers).filter(([id, s]) => s.type !== 'velocity' && !/velocity|bungee|waterfall/i.test(`${id} ${s.label || ''} ${s.type || ''}`)).map(([id, s]) => ({ id, host: s.host || '127.0.0.1', port: Number(s.port) }));
        await fs.promises.writeFile(path.join(temp, 'velocity.toml'), configureVelocityToml(tomlTemplate, v.port, backends), 'utf8');
        await fs.promises.writeFile(path.join(temp, 'forwarding.secret'), crypto.randomBytes(32).toString('hex') + '\n', { mode: 0o600, flag: 'wx' }); secretCreated = true;
      } else {
        const motd = v.label.replace(/[\r\n\\=:#!]/g, ' ').slice(0, 59);
        await fs.promises.writeFile(path.join(temp, 'server.properties'), `# Created by the panel\nserver-port=${v.port}\nquery.port=${v.port}\nmotd=${motd}\n`);
        if (v.acceptEula) await fs.promises.writeFile(path.join(temp, 'eula.txt'), `# Accepted via the panel by ${req.panelSession.username} on ${new Date().toISOString()} (https://aka.ms/MinecraftEULA)\neula=true\n`);
        if (sw.supportsPlugins && sw.kind === 'server') await fs.promises.mkdir(path.join(temp, 'plugins'));
      }
      t.done('configure');

      t.start('register');
      await fs.promises.rename(temp, dest); temp = null;
      let args;
      if (sw.startupTemplate) {
        const vars = Object.fromEntries((sw.variables || []).map(x => [x.env, v.vars[x.env] !== undefined ? String(v.vars[x.env]).replace(/[\u0000-\u001f]/g, ' ').slice(0, 200) : x.default]));
        args = expandStartup(sw.startupTemplate.args, { memoryMB: v.ramGB * 1024, jar: resolved.jar, vars });
      } else if (sw.startArgs) args = sw.startArgs.map(a => a.replace(/\$\{memoryMB\}/g, String(v.ramGB * 1024)).replace(/\$\{jar\}/g, resolved.jar));
      else args = isProxy ? ['-Xms512M', `-Xmx${v.ramGB}G`, '-jar', resolved.jar] : [`-Xms${Math.min(1, v.ramGB)}G`, `-Xmx${v.ramGB}G`, '-jar', resolved.jar, '--nogui'];
      state.metrics[v.serverId] = [];
      config.servers[v.serverId] = { type: isProxy ? 'velocity' : 'backend', label: v.label, host: v.host, port: v.port, command: v.javaCommand, cwd: path.relative(ROOT, dest), args, stopCommand: sw.startupTemplate?.stopCommand || sw.stopCommand || (isProxy ? 'end' : 'stop'),
        software: { id: sw.id, version: v.version, build: resolved.build || null, installedAt: new Date().toISOString(), sha256: result.sha256, verified: result.verified, trust: resolved.trust, createdBy: req.panelSession.username } };
      config.ignoredServerFolders = (config.ignoredServerFolders || []).filter(x => String(x).toLowerCase() !== path.basename(dest).toLowerCase());
      registered = true;
      writeConfig(); saveState();
      detectCache.delete(v.serverId);
      notify('file_change', `Created server ${v.label} (${sw.name} ${v.version}${resolved.build ? ' build ' + resolved.build : ''})`, v.serverId, req.panelSession.username);
      audit(req, 'server_created', { server: v.serverId, message: `${sw.name} ${v.version}${resolved.build ? ' #' + resolved.build : ''}; ${result.verified ? result.verified + ' verified' : 'unverified'}` });
      t.done('register');
      t.finish({ serverId: v.serverId, directory: path.relative(network, dest), port: v.port, software: sw.name, version: v.version, build: resolved.build || null, verified: result.verified, eulaAccepted: v.acceptEula && !isProxy, velocitySecretCreated: secretCreated, needsEula: !isProxy && !v.acceptEula });
    } catch (e) {
      registered = false; delete config.servers[v.serverId];
      await rollback();
      t.fail(e.code === 'EACCES' || e.code === 'EPERM' ? 'The panel cannot write to the servers folder with its operating-system account. Grant write access and retry. Nothing was changed.' : `${e.message || 'Creation failed.'} Everything created so far was removed.`, { rolledBack: true });
    }
  }

  // ---------------------------------------------------------------------
  // Plugin manager (routes live under /api/plugins/:id so per-server access control already applies)
  // ---------------------------------------------------------------------
  const sha1Cache = new Map();
  async function pluginsDirOf(id, create = false) {
    const p = await safePath(id, 'plugins', true);
    if (create) { await fs.promises.mkdir(p.target, { recursive: true }); return (await safePath(id, 'plugins')).target; }
    return p.target;
  }
  async function needPluginServer(req, { write = false } = {}) {
    const id = req.params.id;
    if (!safeId(id)) throw bad('Unknown server.', 404);
    if (!serverAllowed(req, id)) throw bad('You do not have access to this server.', 403);
    const sw = await softwareFor(id);
    if (!sw || sw.supportsPlugins === false) throw bad(`This server runs ${sw?.name || 'software'} that does not support plugins.`, 409);
    if (sw.supportsPlugins === null || !sw.family) throw bad('The server software could not be identified. An administrator can set it on the Plugins page.', 409);
    return { id, sw, mcVersion: sw.kind === 'proxy' ? null : (sw.version || null) };
  }
  const swForCompat = sw => ({ id: sw.family, name: sw.name, pluginLoaders: sw.pluginLoaders, kind: sw.kind });
  const jarFileName = f => { const n = path.basename(String(f || '')); if (!plugins.JAR_NAME.test(n.replace(/\.disabled$/i, ''))) throw bad('Invalid plugin file name.'); return n; };

  function installPluginManager() {
    app.get('/api/plugins/:id/manager', requirePermission('files_view'), h(async (req, res) => {
      const id = req.params.id; if (!safeId(id)) throw bad('Unknown server.', 404);
      const sw = await softwareFor(id, { refresh: req.query.refresh === '1' });
      const base = { software: { id: sw.id, name: sw.name, version: sw.version, via: sw.via, confidence: sw.confidence, evidence: sw.evidence, kind: sw.kind }, admin: isAdmin(req.panelSession) };
      if (sw.supportsPlugins === false) return res.json({ ...base, supported: false, reason: `${sw.name} does not support plugins${sw.id === 'fabric' ? ' (Fabric uses mods)' : ''}.` });
      if (sw.supportsPlugins === null || !sw.family) return res.json({ ...base, supported: null, reason: 'The server software could not be identified automatically.', choices: (await allSoftware()).filter(s => s.supportsPlugins).map(s => ({ id: s.id, name: s.name })) });
      const dir = await pluginsDirOf(id), mc = base.software.kind === 'proxy' ? null : sw.version;
      const records = state.pluginRecords[id] || {};
      const list = await localPlugins.list(dir, swForCompat(sw), mc, records);
      res.json({ ...base, supported: true, mcVersion: mc, loaders: plugins.loadersFor(sw.family), plugins: list, trash: await localPlugins.listTrash(dir), sources: [{ id: 'modrinth', name: 'Modrinth', verified: true }, { id: 'upload', name: 'Manual upload', verified: false }] });
    }));
    app.put('/api/plugins/:id/software', requireAdmin, h(async (req, res) => {
      const id = req.params.id; if (!safeId(id)) throw bad('Unknown server.', 404);
      const sw = await findSoftware(String(req.body?.software || '')); if (!sw) throw bad('Choose the software this server runs.');
      const version = req.body?.version ? String(req.body.version) : null; if (version && !/^[A-Za-z0-9._+-]{1,40}$/.test(version)) throw bad('Enter a valid version.');
      state.softwareOverrides[id] = { id: sw.id, version, manual: true, setAt: new Date().toISOString(), by: req.panelSession.username }; saveState();
      audit(req, 'server_software_set', { server: id, message: `${sw.id} ${version || ''}` });
      res.json({ ok: true, software: await softwareFor(id, { refresh: true }) });
    }));

    app.get('/api/plugins/:id/search', requireAdmin, h(async (req, res) => {
      const { id, sw, mcVersion } = await needPluginServer(req);
      const r = await modrinth.search({ query: String(req.query.q || ''), softwareId: sw.family, mcVersion, offset: Number(req.query.offset) || 0 });
      res.json({ ...r, filteredBy: { loaders: plugins.loadersFor(sw.family), minecraft: mcVersion }, source: 'Modrinth' });
    }));
    app.get('/api/plugins/:id/projects/:projectId/versions', requireAdmin, h(async (req, res) => {
      const { sw, mcVersion } = await needPluginServer(req);
      if (!/^[A-Za-z0-9_-]{2,40}$/.test(req.params.projectId)) throw bad('Invalid project.');
      res.json({ versions: await modrinth.versions({ projectId: req.params.projectId, softwareId: sw.family, mcVersion }), mcVersion });
    }));

    app.post('/api/plugins/:id/install-source', requireAdmin, h(async (req, res) => {
      const { id, sw, mcVersion } = await needPluginServer(req, { write: true });
      const versionId = String(req.body?.versionId || ''); if (!/^[A-Za-z0-9]{6,16}$/.test(versionId)) throw bad('Choose a plugin version.');
      const replace = req.body?.replace ? jarFileName(req.body.replace) : null;
      const ver = await modrinth.version(versionId);
      const loaders = plugins.loadersFor(sw.family), warnings = [];
      if (!(ver.loaders || []).some(l => loaders.includes(l))) throw bad(`That version is built for ${(ver.loaders || []).join(', ') || 'another platform'}, not ${sw.name}.`, 409);
      if (mcVersion && sw.kind !== 'proxy' && !(ver.game_versions || []).includes(mcVersion) && req.body?.allowIncompatible !== true) throw bad(`That version does not list Minecraft ${mcVersion} as supported. Choose another version, or confirm to install anyway.`, 409);
      if (ver.version_type !== 'release' && req.body?.acknowledgeUnstable !== true) throw bad(`This is a ${ver.version_type} build. Confirm that you want to install a pre-release version.`, 409);
      const file = modrinth.pickFile(ver); if (!file) throw bad('This version has no downloadable JAR file.', 404);
      if (!file.expected) warnings.push('Modrinth listed no checksum for this file; it could not be verified.');
      if (!plugins.JAR_NAME.test(file.filename)) throw bad('The plugin file has a name this panel will not write to disk.');
      const dir = await pluginsDirOf(id, true), stage = path.join(dir, `.blockpanel-download-${crypto.randomUUID()}`);
      await fs.promises.mkdir(stage, { mode: 0o700 });
      try {
        const staged = path.join(stage, 'plugin.jar');
        const dl = await net.downloadToFile(file.url, staged, { allowHosts: plugins.MODRINTH_HOSTS, expected: file.expected, maxBytes: plugins.MAX_PLUGIN_BYTES, timeoutMs: 60000 });
        const info = await describeJar(staged), compat = evaluateCompat(info, swForCompat(sw), mcVersion);
        if (compat.status === 'incompatible' && req.body?.allowIncompatible !== true) throw bad(`The downloaded plugin looks incompatible: ${compat.notes[0]}`, 409);
        if (compat.status !== 'compatible') warnings.push(...compat.notes);
        const placed = await localPlugins.place(dir, staged, file.filename, { replace });
        (state.pluginRecords[id] ||= {})[placed.file] = { type: 'modrinth', projectId: ver.project_id, versionId: ver.id, version: ver.version_number, sha256: dl.sha256, size: dl.bytes, verifiedWith: dl.verified, installedAt: new Date().toISOString(), by: req.panelSession.username };
        if (replace) delete state.pluginRecords[id][replace.replace(/\.disabled$/i, '')];
        saveState();
        const required = (ver.dependencies || []).filter(d => d.dependency_type === 'required' && d.project_id);
        let deps = []; try { deps = (await modrinth.projects(required.map(d => d.project_id))).map(p => ({ projectId: p.id, title: p.title })); } catch { deps = required.map(d => ({ projectId: d.project_id, title: null })); }
        notify('file_change', `${replace ? 'Updated' : 'Installed'} plugin ${placed.file} from Modrinth`, id, req.panelSession.username);
        res.json({ ok: true, file: placed.file, verifiedWith: dl.verified, sha256: dl.sha256, previousFile: placed.trashed, requiredDependencies: deps, warnings, restartRequired: true });
      } finally { await fs.promises.rm(stage, { recursive: true, force: true }).catch(() => {}); }
    }));

    const pluginUpload = diskUpload({ field: 'plugin', maxBytes: plugins.MAX_PLUGIN_BYTES, label: 'Plugin JAR', prepare: async req => {
      await needPluginServer(req); const dir = await pluginsDirOf(req.params.id, true);
      const d = path.join(dir, `.blockpanel-upload-${crypto.randomUUID()}`); await fs.promises.mkdir(d, { mode: 0o700 }); return d;
    } });
    app.post('/api/plugins/:id/upload', requireAdmin, (req, res, next) => needPluginServer(req).then(() => next(), e => send(res, e)), pluginUpload, async (req, res) => {
      try {
        const { id, sw, mcVersion } = await needPluginServer(req);
        if (!req.file) throw bad('Choose a plugin JAR to upload.');
        const name = path.posix.basename(String(req.file.originalname || '').replace(/\\/g, '/'));
        if (!plugins.JAR_NAME.test(name)) throw bad('The file must be a .jar with a simple name (letters, numbers, spaces and . _ - + ( ) only).');
        const info = await describeJar(req.file.path); if (!info.valid) throw bad(info.error);
        const compat = evaluateCompat(info, swForCompat(sw), mcVersion), warnings = ['Manual uploads are not verified against any publisher. Only install plugins from sources you trust.'];
        if (compat.status === 'incompatible' && req.query.allowIncompatible !== '1') throw bad(`This plugin looks incompatible: ${compat.notes[0]}`, 409);
        if (compat.status === 'unknown' && req.query.allowUnrecognized !== '1') throw bad('No plugin descriptor was found in this JAR, so it may not be a plugin. Confirm to install it anyway.', 409);
        warnings.push(...compat.notes);
        const replace = req.query.replace ? jarFileName(req.query.replace) : null;
        const dir = await pluginsDirOf(id), sha = await sha256File(req.file.path);
        const placed = await localPlugins.place(dir, req.file.path, name, { replace });
        (state.pluginRecords[id] ||= {})[placed.file] = { type: 'upload', sha256: sha, size: req.file.size, installedAt: new Date().toISOString(), by: req.panelSession.username };
        if (replace) delete state.pluginRecords[id][replace.replace(/\.disabled$/i, '')]; saveState();
        notify('file_change', `Uploaded plugin ${placed.file}`, id, req.panelSession.username);
        res.json({ ok: true, file: placed.file, sha256: sha, compat, previousFile: placed.trashed, warnings, restartRequired: true });
      } catch (e) { send(res, e); } finally { await cleanStaging(req); }
    });

    app.post('/api/plugins/:id/remove', requireAdmin, h(async (req, res) => {
      const { id } = await needPluginServer(req); const file = jarFileName(req.body?.file);
      const trashed = await localPlugins.trash(await pluginsDirOf(id), file);
      if (state.pluginRecords[id]) { delete state.pluginRecords[id][file.replace(/\.disabled$/i, '')]; saveState(); }
      notify('file_change', `Removed plugin ${file} (recoverable)`, id, req.panelSession.username);
      res.json({ ok: true, trashFile: trashed, recoverable: true, restartRequired: true });
    }));
    app.post('/api/plugins/:id/restore', requireAdmin, h(async (req, res) => {
      const { id } = await needPluginServer(req);
      const file = await localPlugins.restore(await pluginsDirOf(id), String(req.body?.trashFile || ''));
      notify('file_change', `Restored plugin ${file}`, id, req.panelSession.username); res.json({ ok: true, file, restartRequired: true });
    }));
    app.post('/api/plugins/:id/purge', requireAdmin, h(async (req, res) => {
      const { id } = await needPluginServer(req); await localPlugins.purge(await pluginsDirOf(id), String(req.body?.trashFile || '')); res.json({ ok: true });
    }));

    app.get('/api/plugins/:id/updates', requireAdmin, h(async (req, res) => {
      const { id, sw, mcVersion } = await needPluginServer(req);
      const dir = await pluginsDirOf(id), items = (await localPlugins.list(dir, swForCompat(sw), mcVersion, state.pluginRecords[id] || {}));
      const hashes = {};
      for (const p of items) { const full = path.join(dir, p.file), key = `${full}|${p.size}|${p.modified}`; let s1 = sha1Cache.get(key); if (!s1) { s1 = await plugins.sha1File(full); sha1Cache.set(key, s1); } hashes[p.file] = s1; }
      const all = Object.values(hashes);
      const [known, latest] = await Promise.all([modrinth.identify(all), modrinth.latestFor(all, sw.family, mcVersion)]);
      const titles = {}; try { for (const pr of await modrinth.projects([...new Set(Object.values(known).map(v => v.project_id))])) titles[pr.id] = pr.title; } catch { /* titles are optional */ }
      const rows = items.map(p => {
        const cur = known[hashes[p.file]], lat = latest[hashes[p.file]];
        if (!cur) return { file: p.file, name: p.name, identified: false };
        const newer = lat && lat.id !== cur.id && new Date(lat.date_published) > new Date(cur.date_published);
        return { file: p.file, name: p.name, identified: true, projectId: cur.project_id, title: titles[cur.project_id] || p.name, current: { versionId: cur.id, number: cur.version_number }, latest: lat ? { versionId: lat.id, number: lat.version_number, channel: lat.version_type } : null, updateAvailable: !!newer };
      });
      res.json({ checked: rows.length, updates: rows.filter(r => r.updateAvailable), upToDate: rows.filter(r => r.identified && !r.updateAvailable).length, unidentified: rows.filter(r => !r.identified).map(r => r.file), note: 'Plugins are identified by exact file hash on Modrinth. Files not published there (or modified) cannot be checked.' });
    }));
  }


  // ---------------------------------------------------------------------
  // server.properties editor
  // ---------------------------------------------------------------------
  function installProperties() {
    const publicSchema = props.SCHEMA.map(({ pattern, ...f }) => f);
    async function locate(req) {
      const id = req.params.id;
      if (!safeId(id)) throw bad('Unknown server.', 404);
      if (!serverAllowed(req, id)) throw bad('You do not have access to this server.', 403);
      const sw = await softwareFor(id);
      if (config.servers[id].type === 'velocity' || sw?.kind === 'proxy') throw bad('Proxies do not use server.properties. Edit velocity.toml in the file manager instead.', 409);
      const p = await safePath(id, 'server.properties', true);
      return { id, target: p.target };
    }
    async function readText(target) {
      const st = await fs.promises.lstat(target).catch(() => null);
      if (!st) return { exists: false, text: '', mode: 0o644 };
      if (!st.isFile()) throw bad('server.properties is not a regular file, so it was not opened.', 409);
      if (st.size > 1024 * 1024) throw bad('server.properties is unusually large (over 1 MB); edit it in the file manager.', 409);
      return { exists: true, text: await fs.promises.readFile(target, 'utf8'), mode: st.mode & 0o777 };
    }
    app.get('/api/properties/:id', requirePermission('files_view'), h(async (req, res) => {
      const { id, target } = await locate(req), f = await readText(target), doc = props.parse(f.text);
      const secrets = {}, values = {};
      for (const [k, v] of Object.entries(doc.values)) { if (props.BY_KEY.get(k)?.type === 'secret') secrets[k] = v !== ''; else values[k] = v; }
      res.json({ exists: f.exists, etag: props.etagOf(f.text), running: processes.has(id), schema: publicSchema, groups: props.GROUPS, values, secretsSet: secrets, canEdit: isAdmin(req.panelSession) || req.panelSession?.permissions?.files_edit === true, otherServerPorts: Object.entries(config.servers).filter(([k]) => k !== id).map(([k, s]) => ({ id: k, port: Number(s.port) })) });
    }));
    app.put('/api/properties/:id', requirePermission('files_edit'), h(async (req, res) => {
      const { id, target } = await locate(req), f = await readText(target);
      const body = req.body || {};
      if (f.exists && body.etag !== props.etagOf(f.text)) throw bad('server.properties changed on disk since you opened it. Reload to see the current values, then re-apply your edits.', 409);
      const raw = body.changes && typeof body.changes === 'object' && !Array.isArray(body.changes) ? body.changes : null;
      if (!raw || !Object.keys(raw).length) throw bad('Nothing to save.');
      if (Object.keys(raw).length > 200) throw bad('Too many changes at once.');
      const changes = {};
      for (const [k, v] of Object.entries(raw)) {
        const val = typeof v === 'boolean' || typeof v === 'number' ? String(v) : v;
        if (typeof val !== 'string') return res.status(400).json({ error: `“${k}” has an invalid value.`, errors: { [k]: 'Invalid value.' } });
        if (props.BY_KEY.get(k)?.type === 'secret' && val === '') continue; // blank = keep current secret
        changes[k] = val;
      }
      if (!Object.keys(changes).length) throw bad('Nothing to save.');
      const errors = {};
      if (changes['server-port'] !== undefined && /^\d+$/.test(changes['server-port'])) {
        const clash = Object.entries(config.servers).find(([k, s]) => k !== id && Number(s.port) === Number(changes['server-port']));
        if (clash) errors['server-port'] = `Port ${changes['server-port']} is already used by “${clash[1].label || clash[0]}”.`;
      }
      const out = props.apply(f.text, changes);
      Object.assign(errors, out.errors);
      if (Object.keys(errors).length) return res.status(400).json({ error: Object.values(errors)[0], errors, details: Object.entries(errors).map(([k, m]) => `${k}: ${m}`) });
      if (!out.changed.length) return res.json({ ok: true, changed: [], etag: props.etagOf(f.text), restartRequired: false, notes: ['No values were different, so nothing was written.'] });
      const dir = path.dirname(target), backupDir = path.join(dir, '.blockpanel-backups');
      if (f.exists) {
        await fs.promises.mkdir(backupDir, { recursive: true, mode: 0o700 });
        await fs.promises.writeFile(path.join(backupDir, `server.properties.${new Date().toISOString().replace(/[:.]/g, '-')}`), f.text, { flag: 'wx', mode: 0o600 });
        const old = (await fs.promises.readdir(backupDir)).filter(n => n.startsWith('server.properties.')).sort();
        for (const n of old.slice(0, Math.max(0, old.length - 5))) await fs.promises.rm(path.join(backupDir, n), { force: true });
      }
      const tmp = path.join(dir, `.server.properties.tmp-${crypto.randomUUID()}`);
      try { await fs.promises.writeFile(tmp, out.text, { flag: 'wx', mode: f.mode }); await fs.promises.rename(tmp, target); }
      catch (e) { await fs.promises.rm(tmp, { force: true }).catch(() => {}); throw e; }
      const notes = [];
      if (out.changed.includes('server-port') && /^\d+$/.test(changes['server-port'])) {
        config.servers[id].port = Number(changes['server-port']); writeConfig();
        notes.push('The panel’s record of this server’s port was updated. If a proxy routes to this server, update its address too.');
      }
      if (changes['online-mode'] === 'false') notes.push('Online mode is off: anyone can join with any name unless a trusted proxy handles authentication.');
      if (out.changed.includes('level-name')) notes.push('A different world folder will be used (and created if missing) at the next start.');
      const running = processes.has(id);
      audit(req, 'server_properties_edit', { server: id, message: `Changed: ${out.changed.map(k => props.BY_KEY.get(k)?.type === 'secret' ? k + ' (secret)' : k).join(', ')}` });
      res.json({ ok: true, changed: out.changed, etag: props.etagOf(out.text), restartRequired: running, notes, backup: f.exists });
    }));
  }

  // ---------------------------------------------------------------------
  // Extension host routes: navigation, declarative actions, sandboxed frames, i18n
  // ---------------------------------------------------------------------
  function installExtHost() {
    const FRAME_TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2' };
    app.get('/api/i18n/:lang', h(async (req, res) => {
      const lang = String(req.params.lang); if (!i18n.LANG.test(lang)) throw bad('Unknown language.', 404);
      res.set('Cache-Control', 'no-cache').json({ lang, dir: i18n.RTL.has(lang.split('-')[0]) ? 'rtl' : 'ltr', messages: await i18n.messages(lang), languages: await i18n.languages() });
    }));
    app.get('/api/extensions-safe-mode', requireAdmin, (req, res) => res.json({ safeMode: safeMode(), forcedByStartup: process.argv.includes('--no-extensions') || process.env.HN_NO_EXTENSIONS === '1' }));
    app.put('/api/extensions-safe-mode', requireAdmin, h(async (req, res) => {
      state.extensionsSafeMode = req.body?.enabled === true; saveState(); host.invalidate();
      audit(req, 'extensions_safe_mode', { message: state.extensionsSafeMode ? 'enabled' : 'disabled' });
      res.json({ ok: true, safeMode: safeMode() });
    }));
    app.get('/api/i18n-report', requireAdmin, h(async (req, res) => { res.json({ report: await i18n.report() }); }));
    app.get('/api/ext/ui', requireAuth, h(async (req, res) => { res.json({ pages: await host.uiList(req.panelSession) }); }));
    app.get('/api/ext/:id/pages/:pageId', requireAuth, h(async (req, res) => { res.json(await host.pageView(req.params.id, req.panelSession, req.params.pageId)); }));
    app.post('/api/ext/:id/action', requireAuth, h(async (req, res) => {
      const r = await host.uiAction(req.params.id, req.panelSession, req.body || {});
      audit(req, 'extension_ui_action', { server: req.body?.serverId && safeId(String(req.body.serverId)) || null, message: `${req.params.id}:${String(req.body?.page).slice(0, 32)}` }); res.json(r);
    }));
    app.post('/api/ext/:id/source', requireAuth, h(async (req, res) => { res.json(await host.uiSource(req.params.id, req.panelSession, req.body || {})); }));
    app.post('/api/ext/:id/bridge', requireAuth, h(async (req, res) => { res.json({ result: await host.bridge(req.params.id, req.panelSession, req.body || {}) ?? null }); }));
    app.post('/api/ext/:id/jobs/:job/run', requireAdmin, h(async (req, res) => {
      const e = await host.getActive(req.params.id), job = e.manifest.jobs.find(j => j.id === req.params.job); if (!job) throw bad('Job not found.', 404);
      await host.runSteps(e.id, job.do, {}, { type: 'ext', ext: e.id }); audit(req, 'extension_job_run', { message: `${e.id}:${job.id}` }); res.json({ ok: true });
    }));
    // Sandboxed extension pages: served with a CSP that forbids network access and an opaque origin (iframe sandbox without allow-same-origin).
    const frameHeaders = (res, type) => res.set({ 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cross-Origin-Resource-Policy': 'cross-origin', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "sandbox allow-scripts allow-forms; default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; form-action 'none'; frame-ancestors 'self'", 'Cache-Control': 'no-store' });
    app.get('/ext-frame/:id/:file', requireAuth, h(async (req, res) => {
      const id = req.params.id, file = path.basename(String(req.params.file)), ext = path.extname(file).toLowerCase();
      if (file === 'hn-sdk.js') { frameHeaders(res, FRAME_TYPES['.js']); return res.sendFile(path.join(ROOT, 'public', 'hn-sdk.js')); }
      const e = await host.getActive(id); if (!FRAME_TYPES[ext] || file !== req.params.file || file.startsWith('.') || file === 'extension.json') throw bad('Not found.', 404);
      const full = path.join(extensions.dirOf(id), file), st = await fs.promises.lstat(full).catch(() => null);
      if (!st || !st.isFile()) throw bad('Not found.', 404);
      if (ext === '.html') { const pg = e.manifest.pages.find(p => p.type === 'frame' && p.entry === file); if (!pg) throw bad('Not found.', 404); await host.pageView(id, req.panelSession, pg.id); }
      frameHeaders(res, FRAME_TYPES[ext]); res.sendFile(full, { dotfiles: 'deny' });
    }));
  }

  return { host, i18n, installEarly, installLate, pluginSupportSync, softwareLabelSync, extensions, catalog, jobs, softwareFor, refreshDetection };
};
