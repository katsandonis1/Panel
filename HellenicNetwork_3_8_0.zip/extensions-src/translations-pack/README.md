# Translations Pack

Covers only the strings that go through the panel's translation system in 3.7.0 (navigation, group names, a few common labels, login subtitle). Most page text is still English; moving more strings to `t()` is future work.

**These translations were drafted by an AI and have not been reviewed by native speakers.** To improve one: edit `i18n/<lang>.json`, keep the keys, bump `version`, run `npm run ext:pack extensions-src/translations-pack`, and upload. Check completeness under Management → Extensions or `GET /api/i18n-report`.
