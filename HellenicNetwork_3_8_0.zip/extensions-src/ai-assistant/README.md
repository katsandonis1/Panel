# AI Assistant

Original design. Frame page in the extension sandbox; the browser never sees the API key (the panel adds it server-side to requests to the approved hosts only).

**Not verified against the live services.** The request/response shapes follow the providers' public documentation as I know it and are exercised only against a stub in tests. Try it with a real key before relying on it.

Safeguards: only your typed messages, the history and the system prompt are sent; replies are rendered as plain text; admins can read transcripts; Discord logging is opt-in and mentions are disabled.

Not implemented: a tool layer that *suggests* panel actions (the assistant answers in text only).
