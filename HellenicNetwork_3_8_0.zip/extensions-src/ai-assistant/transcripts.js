(async function () {
  'use strict';
  const $ = id => document.getElementById(id); await hn.ready; let rows = [];
  try {
    const keys = (await hn.call('storage.list', { prefix: 'tx:' })).sort().reverse().slice(0, 100);
    rows = (await Promise.all(keys.map(k => hn.call('storage.get', { key: k }).catch(() => null)))).filter(Boolean);
    $('status').textContent = rows.length ? '' : 'No conversations yet.';
  } catch (e) { $('status').textContent = e.message; }
  function draw() {
    const f = $('f').value.toLowerCase(), box = $('list'); box.textContent = '';
    for (const r of rows.filter(r => !f || (r.user + ' ' + r.q + ' ' + r.a).toLowerCase().includes(f))) {
      const d = document.createElement('div'); d.className = 'tx';
      const h = document.createElement('small'); h.textContent = (r.user || 'unknown') + ' · ' + new Date(r.at).toLocaleString();
      const q = document.createElement('div'); q.textContent = 'Q: ' + r.q; const a = document.createElement('div'); a.textContent = 'A: ' + r.a; a.style.opacity = '.85';
      d.append(h, q, a); box.append(d);
    }
  }
  $('f').addEventListener('input', draw); draw();
})();
