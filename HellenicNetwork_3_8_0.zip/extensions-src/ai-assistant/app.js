(async function () {
  'use strict';
  const $ = id => document.getElementById(id), log = $('log');
  const ctx = await hn.ready, S = ctx.settings || {};
  const name = S.assistantName || 'Assistant', max = Math.max(2, Math.min(60, Number(S.maxHistory) || 20));
  const providerName = S.provider === 'openai' ? 'OpenAI (api.openai.com)' : 'Anthropic (api.anthropic.com)';
  $('notice').textContent = 'Everything you type here is sent to ' + providerName + (S.webhookEnabled ? ' and logged to the administrators’ Discord channel' : '') + ', and saved in this panel so admins can review it. Do not paste passwords, tokens or private data. ' + name + ' can only reply with text; it cannot run commands or change your servers.';
  let history = [];
  function add(role, text, isErr) {
    const d = document.createElement('div'); d.className = 'msg ' + (role === 'user' ? 'user' : 'bot') + (isErr ? ' err' : '');
    const w = document.createElement('span'); w.className = 'who'; w.textContent = role === 'user' ? 'You' : name; d.append(w, document.createTextNode(text)); log.append(d); log.scrollTop = log.scrollHeight;
  }
  try { history = (await hn.call('storage.get', { key: 'history', scope: 'user' })) || []; } catch { history = []; }
  if (!Array.isArray(history)) history = [];
  history.forEach(m => add(m.role, m.content));
  if (!S.model) add('assistant', 'This assistant is not set up yet. An administrator needs to choose a provider, model name and API key under Management → Extensions → AI Assistant.', true);
  async function ask(messages) {
    const key = '{{secret.apiKey}}', sys = S.systemPrompt || '';
    if (S.provider === 'openai') {
      const r = await hn.call('http.request', { url: 'https://api.openai.com/v1/chat/completions', method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: { model: S.model, messages: [{ role: 'system', content: sys }, ...messages] }, timeoutMs: 15000 });
      if (!r.ok) throw new Error(providerError(r)); return r.json?.choices?.[0]?.message?.content || '(empty reply)';
    }
    const r = await hn.call('http.request', { url: 'https://api.anthropic.com/v1/messages', method: 'POST', headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, body: { model: S.model, max_tokens: 1024, system: sys, messages }, timeoutMs: 15000 });
    if (!r.ok) throw new Error(providerError(r)); return (r.json?.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n') || '(empty reply)';
  }
  const providerError = r => 'The provider answered HTTP ' + r.status + (r.json?.error?.message ? ': ' + String(r.json.error.message).slice(0, 200) : '');
  $('form').addEventListener('submit', async e => {
    e.preventDefault(); const q = $('q').value.trim(); if (!q || !S.model) return;
    $('send').disabled = true; $('q').value = ''; add('user', q);
    const messages = [...history.slice(-(max - 1)), { role: 'user', content: q }];
    try {
      const a = await ask(messages); add('assistant', a);
      history = [...messages, { role: 'assistant', content: a }].slice(-max);
      await hn.call('storage.set', { key: 'history', scope: 'user', value: history });
      await hn.call('storage.set', { key: 'tx:' + String(Date.now()).padStart(15, '0') + ':' + Math.random().toString(36).slice(2, 6), value: { user: ctx.user || 'unknown', q, a: a.slice(0, 8000), at: new Date().toISOString() } }).catch(() => {});
      if (S.webhookEnabled) hn.call('http.request', { url: '{{secret.webhookUrl}}', method: 'POST', body: { content: ('**' + (ctx.user || 'user') + '**: ' + q + '\n**' + name + '**: ' + a).slice(0, 1900), allowed_mentions: { parse: [] } } }).catch(() => {});
    } catch (err) { add('assistant', err.message, true); }
    $('send').disabled = false; $('q').focus();
  });
  $('q').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('form').requestSubmit(); } });
  $('clear').addEventListener('click', async () => { history = []; log.textContent = ''; await hn.call('storage.set', { key: 'history', scope: 'user', value: [] }).catch(() => {}); });
})();
