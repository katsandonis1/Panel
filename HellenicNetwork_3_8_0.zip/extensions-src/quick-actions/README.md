# Quick Actions

Buttons for save-all, time and weather plus a broadcast form. Needs the *servers.command* permission, so enabling it lets people with the panel's console-command permission send these commands.
