(async function () {
  const grid = document.getElementById('grid'), status = document.getElementById('status');
  await hn.ready;
  async function refresh() {
    try {
      const list = await hn.call('servers.list');
      const rows = await Promise.all(list.map(s => hn.call('servers.status', { serverId: s.id }).catch(() => null)));
      grid.textContent = '';
      rows.forEach((r, i) => {
        if (!r) return;
        const c = document.createElement('div'); c.className = 'card';
        const n = document.createElement('b'); n.textContent = r.label;
        const s = document.createElement('span'); s.className = r.online ? 'on' : 'off'; s.textContent = r.online ? 'Online' : 'Offline';
        const p = document.createElement('div'); p.className = 'muted'; p.textContent = 'Players: ' + r.playersOnline + (r.maxPlayers ? ' / ' + r.maxPlayers : '') + ' · port ' + r.port;
        c.append(n, s, p); grid.append(c);
      });
      status.textContent = list.length ? '' : 'No servers.';
    } catch (e) { status.textContent = e.message; }
  }
  refresh(); setInterval(refresh, 15000);
})();
