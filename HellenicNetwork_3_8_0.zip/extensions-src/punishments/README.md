# Punishments

Assumptions (the original product page could not be read): staff need the panel's *players_actions* permission; punishments run as console commands (`ban`, `kick`, `pardon`, `tell`), so the server must be running; records live in this extension's own storage. Temp-ban expiry runs every minute while the panel is up; if the target server is stopped at that moment the pardon command fails and the job reports it. Permanent bans have an empty expiry and are never lifted by the job.
