# Scheduled Restarts

Two daily jobs (warning, restart) driven by settings. If the panel is down at the scheduled minute the job is skipped, not replayed later (5-minute window). A failed run raises a panel notification; five consecutive failures disable the extension automatically.
