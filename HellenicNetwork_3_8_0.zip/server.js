const fs = require('fs');
const path = require('path');
const http = require('http');
const net = require('net');
const crypto = require('crypto');
const os = require('os');
const dns = require('dns').promises;
const { isIP } = require('net');
const { inflateRawSync } = require('zlib');
const { spawn, execFile } = require('child_process');
const { pipeline } = require('stream/promises');
const express = require('express');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const WebSocket = require('ws');
const multer = require('multer');

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, 'config.json');
const DATA = path.join(ROOT, 'data');
fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(CONFIG_PATH)) { console.error('config.json is missing. Run: npm run setup'); process.exit(1); }
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
config.panel = config.panel || { host: '0.0.0.0', port: 3000, sessionDays: 7 };
config.auth = config.auth || {};
config.servers = config.servers || {};
config.networkRoot = config.networkRoot || '../MinecraftNetwork';
config.backupDirectory = config.backupDirectory || path.join(path.dirname(path.resolve(ROOT, config.networkRoot)), 'MinecraftBackups');
config.backupMount = config.backupMount || ''; // empty = no external disk check
config.features = { ...(config.features || {}), autoDetect: true };

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ noServer: true });
const sessions = new Map();
const processes = new Map();
const startLocks = new Set();
let serverCreationInProgress = false;
const hnHooks = { event: null, console: null }; // set by the extension host; lets extensions react to panel events
const history = new Map();
const telemetry = new Map();
const statusCache = new Map();
const crashState = new Map();
const lastTpsPoll = new Map();
const upload=multer({storage:multer.diskStorage({destination:(req,file,cb)=>{const staging=req.uploadContext?.stagingDir;if(!staging)return cb(new Error('Upload destination was not prepared.'));cb(null,staging)},filename:(req,file,cb)=>cb(null,crypto.randomUUID())}),limits:{files:100,fields:0}});
const pluginUpload=multer({storage:multer.diskStorage({destination:(req,file,cb)=>{const staging=req.pluginUpdateContext?.stagingDir;if(!staging)return cb(new Error('Plugin update destination was not prepared.'));cb(null,staging)},filename:(req,file,cb)=>cb(null,crypto.randomUUID())}),limits:{files:1,fields:1,fieldSize:512,fileSize:100*1024*1024}});

const PERMISSIONS = ['dashboard','console','console_command','start','stop','restart','files_view','files_edit','files_delete','players_view','players_actions','backups','server_settings','hooks_view','notifications_view','users_manage'];
const HOOK_ACTIONS = ['login_failed','server_start','server_stop','server_restart','server_crash','server_offline','server_online','low_tps','high_ram','low_disk','backup_completed','scheduled_restart','scheduled_task','locked_access','file_change','player_action'];
const COLORS = { ok:'#34d399', warn:'#f59e0b', danger:'#fb7185', info:'#60a5fa' };

function readJson(file, fallback) { try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file,'utf8')) : fallback; } catch { return fallback; } }
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); }
const autoDetectedServerIds = new Set();
const legacyNetworkServers = new Map();
function writeConfig(){const persisted={...config,servers:Object.fromEntries(Object.entries(config.servers).filter(([id])=>!autoDetectedServerIds.has(id)))};writeJson(CONFIG_PATH,persisted);}
const stateFile = path.join(DATA,'state.json');
const state = readJson(stateFile, { notifications: [], audit: [], playerActivity: [], metrics: {}, templates: [], scheduledTasks: [], locks: {}, hooks: {}, profiles: {}, serverSettings: {}, backups: [] });
state.notifications ||= []; state.audit ||= []; state.playerActivity ||= []; state.metrics ||= {}; state.templates ||= []; state.scheduledTasks ||= []; state.backupConfig ||= { dailyEnabled:false,dailyTime:'04:00',weeklyEnabled:false,weeklyTime:'05:00',keepDaily:7,keepWeekly:4 }; state.backupRestoreStatus ||= null; state.locks ||= {}; state.hooks ||= {}; state.profiles ||= {}; state.serverSettings ||= {}; state.backups ||= []; state.emailConfig ||= {enabled:false,host:'',port:587,secure:false,username:'',password:'',from:'',to:'',events:[],localUrl:'',tailscaleUrl:''};
const secretFile = path.join(DATA,'secret.key');
let secret;
if (fs.existsSync(secretFile)) secret = fs.readFileSync(secretFile); else { secret = crypto.randomBytes(32); fs.writeFileSync(secretFile, secret, {mode:0o600}); }

async function extControl(id,a){if(a==='start')return await confirmStart(id,await safeStartProcess(id,{}));if(a==='stop')return await stopProcess(id);if(a==='restart')return await restartProcess(id);return {error:'Unknown action.'}}
function brandName(){return String(state.branding?.name||'Hellenic Network')}
function saveState(){ writeJson(stateFile,state); }
function audit(req,action,details={}){const item={id:crypto.randomUUID(),time:new Date().toISOString(),user:req?.panelSession?.username||details.user||req?.body?.username||'system',action,server:details.server||null,details:details.message||'',ip:req?.ip||null};state.audit.unshift(item);state.audit=state.audit.slice(0,2000);saveState();}
function token(){ return crypto.randomBytes(32).toString('hex'); }
function sessionFromReq(req){ const raw=req.headers.cookie||''; const item=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith('panel_session=')); if(!item)return null; const t=decodeURIComponent(item.slice(14)); const s=sessions.get(t); if(!s||s.expiresAt<Date.now()){sessions.delete(t);return null;}const user=getUsers().find(x=>x.username===s.username);if(!user){sessions.delete(t);return null;}s.role=normalizedRole(user.role);s.permissions=normalizedPermissions(user);s.lastSeen=Date.now();return s; }
function sessionTokenFromReq(req){const item=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('panel_session='));return item?decodeURIComponent(item.slice(14)):null;}
function requireAuth(req,res,next){const s=sessionFromReq(req);if(!s)return res.status(401).json({error:'Unauthorized'});req.panelSession=s;next();}
function requirePermission(p){return (req,res,next)=>{const s=sessionFromReq(req);if(!s)return res.status(401).json({error:'Unauthorized'});if(!isAdmin(s)&&!s.permissions?.[p])return res.status(403).json({error:'You do not have permission for this action.'});req.panelSession=s;next();};}
function requireAdmin(req,res,next){const s=sessionFromReq(req);if(!s)return res.status(401).json({error:'Unauthorized'});if(!isAdmin(s))return res.status(403).json({error:'Admin only.'});req.panelSession=s;next();}
function normalizedRole(role='viewer'){const value=String(role||'viewer').trim().toLowerCase();return ['admin','operator','viewer'].includes(value)?value:'viewer';}
function rolePermissions(role='viewer'){ role=normalizedRole(role);if(role==='admin') return Object.fromEntries(PERMISSIONS.map(k=>[k,true])); if(role==='operator') return Object.fromEntries(PERMISSIONS.map(k=>[k,!['users_manage','hooks_view','backups'].includes(k)])); return {dashboard:true,console:false,console_command:false,start:false,stop:false,restart:false,files_view:false,files_edit:false,files_delete:false,players_view:false,players_actions:false,backups:false,server_settings:false,hooks_view:false,notifications_view:true,users_manage:false}; }
function normalizedPermissions(u){ const role=normalizedRole(u.role);if(role==='admin')return rolePermissions('admin');const permissions={...rolePermissions(role),...(u.permissions||{})};delete permissions.files_upload;return permissions; }
function getUsers(){ if(Array.isArray(config.auth.users)&&config.auth.users.length)return config.auth.users; if(config.auth.username&&config.auth.passwordHash)return [{username:config.auth.username,passwordHash:config.auth.passwordHash,role:'admin',permissions:rolePermissions('admin')}]; return []; }
function publicUsers(){return getUsers().map(u=>({username:u.username,role:normalizedRole(u.role),permissions:normalizedPermissions(u),servers:Array.isArray(u.servers)?u.servers:['*'],profile:state.profiles[u.username]||{}}));}
function setSession(res,u,req){const t=token(),days=Number(config.panel.sessionDays||7),now=Date.now();sessions.set(t,{id:crypto.randomUUID(),username:u.username,role:normalizedRole(u.role),permissions:normalizedPermissions(u),createdAt:now,lastSeen:now,ip:req?.ip||null,userAgent:String(req?.headers?.['user-agent']||'').slice(0,180),expiresAt:now+days*86400000});res.setHeader('Set-Cookie',`panel_session=${encodeURIComponent(t)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${days*86400}`);}
function syncUserSessions(user){const role=normalizedRole(user.role),permissions=normalizedPermissions(user);for(const s of sessions.values())if(s.username===user.username){s.role=role;s.permissions={...permissions};}for(const ws of wss.clients){const s=ws.panelSession;if(s?.username!==user.username)continue;s.role=role;s.permissions={...permissions};if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'permissions_updated',username:user.username,role,permissions:s.permissions}));}}
function serverIdExists(id){const needle=String(id||'').toLowerCase();return Object.keys(config.servers).some(key=>key.toLowerCase()===needle);}
function safeId(id){return Object.hasOwn(config.servers,id)?id:null;}
function serverRoot(id){return path.resolve(ROOT,config.servers[id].cwd);}
function normalizeRel(rel=''){const v=String(rel||'').replace(/\\/g,'/');const n=path.posix.normalize('/'+v).replace(/^\/+/, '');if(!n||n==='.')return '';if(n==='..'||n.startsWith('../'))throw Error('Invalid path.');return n;}
function inside(root,target){const r=path.resolve(root),t=path.resolve(target);return t===r||t.startsWith(r+path.sep);}
async function safePath(id,rel='',allowMissing=false){const root=serverRoot(id);if(!fs.existsSync(root))throw Error(`Server directory does not exist: ${root}`);const clean=normalizeRel(rel),target=path.resolve(root,clean),realRoot=await fs.promises.realpath(root);if(!inside(root,target))throw Error('Invalid path.');if(fs.existsSync(target)){const rt=await fs.promises.realpath(target);if(!inside(realRoot,rt))throw Error('Path escapes server directory.');return {root:realRoot,target:rt,rel:clean};}if(!allowMissing)throw Error('File or directory not found.');const parent=await fs.promises.realpath(path.dirname(target));if(!inside(realRoot,parent))throw Error('Path escapes server directory.');return {root:realRoot,target,rel:clean};}
function isAdmin(s){return normalizedRole(s?.role)==='admin';}
function lockFor(id,rel){const clean=normalizeRel(rel);const map=state.locks[id]||{};let best=null;for(const [p,v] of Object.entries(map)){if(clean===p||clean.startsWith(p+'/')){if(!best||p.length>best.path.length)best={path:p,...v};}}return best;}
function canAccessLocked(req,id,rel,action='view'){const lock=lockFor(id,rel);if(!lock)return true;if(isAdmin(req.panelSession))return true;const trusted=(lock.users||[]).includes(req.panelSession.username);if(!trusted){notify('locked_access',`Locked path access blocked: ${id}/${rel}`,id,req.panelSession.username);return false;}return true;}
function checkLocked(req,id,rel,action){if(canAccessLocked(req,id,rel,action))return true;throw Object.assign(new Error('This file or folder is locked for your account.'),{status:403});}
function notify(type,message,serverId=null,user=null){const n={id:crypto.randomUUID(),time:new Date().toISOString(),type,message,server:serverId,user,read:false};state.notifications.unshift(n);state.notifications=state.notifications.slice(0,500);saveState();broadcast(null,{type:'notification',notification:n});try{hnHooks.event?.(type,message,serverId,user)}catch{}sendHook(type,{message,server:serverId,user}).catch(()=>{});sendEmailAlert(type,message,serverId,user).catch(()=>{});}
function encrypt(text){const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',secret,iv);const enc=Buffer.concat([c.update(text,'utf8'),c.final()]);return [iv,c.getAuthTag(),enc].map(b=>b.toString('base64')).join('.');}
function decrypt(payload){try{const [iv,tag,enc]=String(payload).split('.').map(x=>Buffer.from(x,'base64'));const d=crypto.createDecipheriv('aes-256-gcm',secret,iv);d.setAuthTag(tag);return Buffer.concat([d.update(enc),d.final()]).toString('utf8');}catch{return null;}}
function safeEmailConfig(){const c=state.emailConfig||{};return {enabled:!!c.enabled,host:c.host||'',port:Number(c.port)||587,secure:!!c.secure,username:c.username||'',hasPassword:!!c.password,from:c.from||'',to:c.to||'',events:Array.isArray(c.events)?c.events:[],localUrl:c.localUrl||'',tailscaleUrl:c.tailscaleUrl||''}}
function emailTransport(){const c=state.emailConfig||{},password=c.password?decrypt(c.password):null;if(!c.host||!c.from||!c.to||!password)throw Error('Complete SMTP host, sender, recipient, and password in Settings first.');const nodemailer=require('nodemailer');return nodemailer.createTransport({host:c.host,port:Number(c.port)||587,secure:!!c.secure,auth:{user:c.username||c.from,pass:password},connectionTimeout:10000,greetingTimeout:10000,socketTimeout:20000})}
function panelLink(base,id){if(!base)return '';try{const u=new URL(base);if(id)u.searchParams.set('server',id);return u.toString()}catch{return ''}}
function htmlEscape(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function sendEmailAlert(type,message,serverId,user){const c=state.emailConfig||{};if(!c.enabled||!Array.isArray(c.events)||!c.events.includes(type))return;try{const serverLabel=serverId?(config.servers[serverId]?.label||serverId):'All servers',local=panelLink(c.localUrl,serverId),tail=panelLink(c.tailscaleUrl,serverId),links=[local?`Local console: ${local}`:'',tail?`Tailscale console: ${tail}`:''].filter(Boolean);const transport=emailTransport(),subject=`[${brandName()}] ${String(type).replaceAll('_',' ')}${serverId?` · ${serverLabel}`:''}`;const body=[`Event: ${type}`,`Time: ${new Date().toISOString()}`,`Server: ${serverLabel}`,user?`User: ${user}`:'',`What happened: ${message}`,'',...links].filter(Boolean).join('\n');await transport.sendMail({from:c.from,to:c.to,subject,text:body,html:`<h2>${htmlEscape(subject)}</h2><p><b>Event:</b> ${htmlEscape(type)}<br><b>Time:</b> ${htmlEscape(new Date().toISOString())}<br><b>Server:</b> ${htmlEscape(serverLabel)}${user?`<br><b>User:</b> ${htmlEscape(user)}`:''}</p><p>${htmlEscape(message)}</p>${links.map(x=>`<p><a href="${htmlEscape(x.slice(x.indexOf(': ')+2))}">${htmlEscape(x.slice(0,x.indexOf(': ')))}</a></p>`).join('')}`});}catch(e){console.error(`[email alert] ${e.message}`)}}
// Upgrade the legacy action-keyed hook map to named records once, keeping URLs encrypted.
if(!Array.isArray(state.hooks)){const old=state.hooks||{},next=[];for(const [server,items] of Object.entries(old))for(const [action,url] of Object.entries(items||{}))if(HOOK_ACTIONS.includes(action)&&url)next.push({id:crypto.randomUUID(),name:`${action.replaceAll('_',' ')} · ${server==='*'?'All servers':server}`,server,action,url});state.hooks=next;saveState();}
function getHook(serverId,type){const hooks=Array.isArray(state.hooks)?state.hooks:[];const h=hooks.find(x=>x.action===type&&x.server===serverId)||hooks.find(x=>x.action===type&&x.server==='*');return h?decrypt(h.url):null;}
async function sendHook(type,payload,serverId=null){const hooks=(state.hooks||[]).filter(h=>h.action===type&&(h.server==='*'||h.server===serverId));await Promise.all(hooks.map(async h=>{const url=decrypt(h.url);if(!url)return;try{await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:brandName(),embeds:[{title:`${brandName()} · ${h.name}`,description:payload.message||'',color:0x60a5fa,fields:[{name:'Event',value:type,inline:true},...(serverId?[{name:'Server',value:String(serverId),inline:true}]:[]),...(payload.user?[{name:'User',value:String(payload.user),inline:true}]:[])],timestamp:new Date().toISOString()}]})})}catch{}}))}
function addHistory(id,line,type='stdout'){const arr=history.get(id)||[];arr.push({time:new Date().toISOString(),type,line:String(line)});while(arr.length>1200)arr.shift();history.set(id,arr);broadcast(id,{type:'log',entry:arr[arr.length-1]});parseTelemetryLine(id,String(line));try{hnHooks.console?.(id,String(line))}catch{}recordPlayerActivity(id,String(line));}
function broadcast(id,payload){const data=JSON.stringify({server:id,...payload});for(const c of wss.clients)if(c.readyState===WebSocket.OPEN&&(id===null||c.serverId===id))c.send(data);}
function parseTpsFromText(text){let m=text.match(/TPS\s*[:=]\s*([0-9.]+)/i)||text.match(/([0-9.]+)\s*TPS/i);return m?Number(m[1]):null;}
function parseMspt(text){let m=text.match(/(?:MSPT|mspt)[^0-9]*([0-9.]+)/);return m?Number(m[1]):null;}
function parseTelemetryLine(id,text){const tps=parseTpsFromText(String(text));const mspt=parseMspt(String(text));if(tps!=null)telemetryFor(id).lastTpsSecond=tps;if(tps!=null||mspt!=null)recordTelemetry(id,{...(tps!=null?{tps}:{}) ,...(mspt!=null?{mspt}:{})});}
function telemetryFor(id){if(!telemetry.has(id))telemetry.set(id,{points:(state.metrics[id]||[]).slice(-1440),tps:20,mspt:null,cpu:0,ram:0,players:0,uptime:0,lastPoll:Date.now(),lastTpsSecond:20});return telemetry.get(id);}
function recordTelemetry(id,patch){const t=telemetryFor(id);Object.assign(t,patch);const now=Date.now();t.points.push({time:now,tps:Number(t.tps)||0,mspt:t.mspt,cpu:t.cpu,ram:t.ram,players:t.players,disk:t.disk||null});const cutoff=now-3600000;t.points=t.points.filter(x=>x.time>=cutoff);if(!t.lastPersisted||now-t.lastPersisted>=60000){state.metrics[id]||=[];state.metrics[id].push(t.points[t.points.length-1]);state.metrics[id]=state.metrics[id].filter(x=>x.time>=now-86400000).slice(-1440);t.lastPersisted=now;saveState()}broadcast(id,{type:'telemetry',telemetry:t});const limit=Number(state.serverSettings[id]?.tpsWarn??15);if(t.tps<limit&&!t.lowAlert){t.lowAlert=true;notify('low_tps',`TPS dropped below ${limit} (${t.tps.toFixed(1)})`,id);}if(t.tps>=limit)t.lowAlert=false;}
const healthFlags=new Map(),activitySeen=new Map();
async function evaluateHealth(){for(const [id,s] of Object.entries(config.servers)){const st=statusCache.get(id);if(!st)continue;const prev=healthFlags.get(id)||{};if(prev.online===true&&!st.online)notify('server_offline',`${s.label} is offline`,id);if(prev.online===false&&st.online)notify('server_online',`${s.label} is back online`,id);const t=telemetryFor(id),settings=state.serverSettings[id]||{},flags={...prev,online:st.online};const ramLimit=Number(settings.ramWarnMB||0);if(ramLimit>0&&t.ram>=ramLimit&&!flags.ram){notify('high_ram',`${s.label} memory reached ${Math.round(t.ram)} MB`,id);flags.ram=true}if(ramLimit>0&&t.ram<ramLimit*0.9)flags.ram=false;if(Date.now()-(flags.diskCheck||0)>60000){flags.diskCheck=Date.now();try{const fsstat=await fs.promises.statfs(serverRoot(id)),total=Number(fsstat.blocks)*Number(fsstat.bsize),free=Number(fsstat.bavail)*Number(fsstat.bsize),used=total?100*(total-free)/total:0;t.disk=used;const lim=Number(settings.diskWarnPercent||90);if(used>=lim&&!flags.disk){notify('low_disk',`${s.label} disk usage is ${used.toFixed(1)}%`,id);flags.disk=true}if(used<lim-3)flags.disk=false}catch{}}healthFlags.set(id,flags)}}
function recordPlayerActivity(id,line){const m=String(line).match(/\b([A-Za-z0-9_]{1,16}) (joined|left) the game\.?/i);if(!m)return;const key=`${id}:${m[1]}:${m[2]}:${Math.floor(Date.now()/5000)}`;if(activitySeen.get(key))return;activitySeen.set(key,true);state.playerActivity.unshift({time:new Date().toISOString(),server:id,player:m[1],event:m[2].toLowerCase()});state.playerActivity=state.playerActivity.slice(0,2000);saveState()}
function parseProcCpu(pid,prev){try{const stat=fs.readFileSync(`/proc/${pid}/stat`,'utf8');const parts=stat.slice(stat.lastIndexOf(')')+2).split(' ');const ut=Number(parts[11]),st=Number(parts[12]),now=Date.now();if(!prev)return {cpu:0,total:ut+st,time:now};const dt=(now-prev.time)/1000;const dc=(ut+st)-prev.total;const cpus=os.cpus().length;return {cpu:Math.max(0,Math.min(100,(dc/Math.max(1,dt))/100/Math.max(1,cpus)*100)),total:ut+st,time:now};}catch{return prev||{cpu:0,total:0,time:Date.now()};}
}
const cpuPrev=new Map();
function processMetrics(id){const child=processes.get(id),t=telemetryFor(id);if(!child?.pid){recordTelemetry(id,{cpu:0,ram:0,uptime:0});return;}let cpu=cpuPrev.get(id);cpu=parseProcCpu(child.pid,cpu);cpuPrev.set(id,cpu);let ram=0;try{const statm=fs.readFileSync(`/proc/${child.pid}/statm`,'utf8').split(' ');ram=Number(statm[1])*os.pageSize/1048576;}catch{}const start=processes.get(id)?.startedAt||Date.now();recordTelemetry(id,{cpu:cpu.cpu,ram,uptime:Date.now()-start});}
function writeCommand(id,command,meta=true){const child=processes.get(id);if(!child)return {ok:false,error:'Server is not running.'};if(typeof command!=='string'||!command.trim()||command.length>2000)return {ok:false,error:'Invalid command.'};if(child._stdinUnavailable||!child.stdin?.writable||child.stdin.destroyed||child.stdin.writableEnded)return {ok:false,error:'The server is still running, but its console input has closed. Restart that server to restore console commands.'};try{const c=command.replace(/[\r\n]+/g,' ');child.stdin.write(c+'\n');if(meta)addHistory(id,`> ${c}`,'command');return {ok:true};}catch(e){if(e.code==='EPIPE'||e.code==='ERR_STREAM_DESTROYED'){child._stdinUnavailable=true;return {ok:false,error:'The server is still running, but its console input has closed. Restart that server to restore console commands.'};}return {ok:false,error:e.message};}}
function stopProcess(id,forceAfter=10000){
  const child=processes.get(id); if(!child)return stopUnmanagedServer(id);
  const s=config.servers[id]; child._panelStopping=true;
  return new Promise(resolve=>{
    let done=false;
    const finish=(r)=>{if(!done){done=true;clearTimeout(timer);clearTimeout(killTimer);resolve(r)}};
    const alive=()=>child.exitCode===null&&child.signalCode===null;
    const killTimer=setTimeout(()=>{try{if(alive())child.kill('SIGTERM')}catch{}},Math.max(0,forceAfter));
    const timer=setTimeout(()=>{try{if(alive())child.kill('SIGKILL')}catch{};finish({forced:true})},Math.max(1000,forceAfter+2500));
    child.once('exit',()=>finish({stopped:true}));
    try{if(!child._stdinUnavailable&&child.stdin?.writable&&!child.stdin.destroyed&&!child.stdin.writableEnded)child.stdin.write((s.stopCommand||'stop')+'\n');else throw Error('stdin is not writable');}
    catch{try{if(!child.killed)child.kill('SIGTERM')}catch{}}
  });
}
function buildStartArgs(s,ramGB,quick){const base=[...(s.args||[])];if(quick||ramGB==null)return base;const gb=Math.max(1,Math.min(8,Number(ramGB)||1));let found=false;const out=[];for(const a of base){if(/^-Xmx/i.test(a)){found=true;out.push(`-Xmx${gb}G`)}else if(/^-Xms/i.test(a)){const m=String(a).match(/^-Xms([0-9]+)([MG])$/i);if(m&&Number(m[1])*(m[2].toUpperCase()==='M'?1/1024:1)>gb)out.push(`-Xms${gb}G`);else out.push(a)}else out.push(a)}if(!found){const j=out.findIndex(x=>String(x).toLowerCase()==='-jar');if(j>=0)out.splice(j,0,`-Xmx${gb}G`);else out.unshift(`-Xmx${gb}G`)}return out;}
const scheduledRuns=new Map();
const autoRestartTimers=new Map();
function shouldAutoRestart(id){const st=state.serverSettings[id]||{};return st.autoRestart===true;}
function scheduleAutoRestart(id){
  if(autoRestartTimers.has(id)) return;
  const cs=crashState.get(id)||{}, set=state.serverSettings[id]||{}, max=Number(set.maxRestarts??3);
  if((cs.autoRestarts||0)>=max) return;
  const delay=Math.max(0,Number(set.restartDelay??10))*1000;
  cs.autoRestarts=(cs.autoRestarts||0)+1; crashState.set(id,cs);
  const timer=setTimeout(()=>{autoRestartTimers.delete(id);if(!processes.get(id))safeStartProcess(id,{quick:true}).then(r=>{if(!r.ok)addHistory(id,`Automatic restart skipped: ${r.error}`,'stderr')}).catch(e=>addHistory(id,`Automatic restart failed: ${e.message}`,'stderr'));},delay);
  autoRestartTimers.set(id,timer);
}

function startProcess(id,options={}){
  if(processes.get(id)) return {ok:false,error:'Server is already running.'};
  const s=config.servers[id],cwd=serverRoot(id);
  if(!fs.existsSync(cwd)) return {ok:false,error:`Working directory does not exist: ${cwd}`};
  const args=buildStartArgs(s,options.ramGB,options.quick);
  let child;
  try{child=spawn(s.command||'java',args,{cwd,shell:false,env:process.env,stdio:['pipe','pipe','pipe']});}
  catch(e){return{ok:false,error:e.message}};
  child.startedAt=Date.now(); child.startArgs=args; child._panelStopping=false;
  processes.set(id,child); crashState.set(id,{...(crashState.get(id)||{}),lastStart:Date.now()});
  addHistory(id,`> ${s.command||'java'} ${args.join(' ')}${options.quick?' (Quick Launch)':''}`,'system');
  let spawnError=null;
  child.stdin.on('error',e=>{child._stdinUnavailable=true;if(!child._stdinErrorLogged){child._stdinErrorLogged=true;addHistory(id,`Console input closed${e.code?` (${e.code})`:''}: ${e.message}. The Minecraft process remains running.`,'stderr');}});
  child.once('spawn',()=>{sendHook('server_start',{message:`Server started with ${options.quick?'Quick Launch':`RAM ${options.ramGB} GB`}`},id).catch(()=>{});if(state.serverSettings[id]?.maintenance)setTimeout(()=>{writeCommand(id,'whitelist on');writeCommand(id,`say [${brandName()}] Maintenance mode enabled: ${state.serverSettings[id].maintenanceMessage||'Scheduled maintenance'}`)},1500)});
  const failStart=(e)=>{spawnError=e;child._spawnError=e;addHistory(id,`Process error: ${e.message}`,'stderr');if(processes.get(id)===child)processes.delete(id);cpuPrev.delete(id);broadcast(id,{type:'process',running:false,error:e.message});};
  child.stdout.on('data',d=>String(d).split(/\r?\n/).filter(Boolean).forEach(x=>addHistory(id,x,'stdout')));
  child.stderr.on('data',d=>String(d).split(/\r?\n/).filter(Boolean).forEach(x=>addHistory(id,x,'stderr')));
  child.on('error',failStart);
  child.on('exit',(code,signal)=>{
    const wasStop=child._panelStopping;
    if(processes.get(id)===child) processes.delete(id); cpuPrev.delete(id);
    addHistory(id,`Process exited (code=${code}, signal=${signal||'none'})`,'system'); broadcast(id,{type:'process',running:false});
    if(!wasStop&&!spawnError&&code!==0){
      const cs=crashState.get(id)||{}; cs.count=(cs.count||0)+1; cs.lastCrash=Date.now();
      if(child.startedAt&&Date.now()-child.startedAt>10*60*1000) cs.autoRestarts=0; crashState.set(id,cs);
      notify('server_crash',`Server crashed (exit ${code ?? 'unknown'}). Crash count: ${cs.count}`,id);
      if(shouldAutoRestart(id)) scheduleAutoRestart(id);
    } else if(wasStop){ sendHook('server_stop',{message:'Server stopped'},id).catch(()=>{}); }
  });
  broadcast(id,{type:'process',running:true});
  return {ok:true,pid:child.pid};
}
async function findUnmanagedLinuxJava(id,port){
  if(process.platform!=='linux')return null;
  let root;try{root=await fs.promises.realpath(serverRoot(id))}catch{return null}
  const hex=Number(port).toString(16).toUpperCase().padStart(4,'0'),inodes=new Set();
  for(const table of ['/proc/net/tcp','/proc/net/tcp6'])try{const rows=(await fs.promises.readFile(table,'utf8')).split(/\r?\n/).slice(1);for(const row of rows){const c=row.trim().split(/\s+/);if(c.length>9&&c[3]==='0A'&&c[1].split(':').pop().toUpperCase()===hex)inodes.add(c[9])}}catch{}
  if(!inodes.size)return null;
  let pids=[];try{pids=await fs.promises.readdir('/proc')}catch{return null}
  for(const pid of pids){if(!/^\d+$/.test(pid))continue;const base='/proc/'+pid;try{const exe=path.basename(await fs.promises.readlink(path.join(base,'exe')));if(!/^java(w)?$/i.test(exe))continue;const cwd=await fs.promises.realpath(path.join(base,'cwd'));if(cwd!==root)continue;const fds=await fs.promises.readdir(path.join(base,'fd'));for(const fd of fds){try{const target=await fs.promises.readlink(path.join(base,'fd',fd)),m=target.match(/^socket:\[(\d+)\]$/);if(m&&inodes.has(m[1]))return{pid:Number(pid)}}catch{}}}catch{}}
  return null;
}
async function stopUnmanagedServer(id){
  const s=config.servers[id];if(!s)return{alreadyStopped:true};const status=await mcStatus(s.host,s.port,900);if(!status.online)return{alreadyStopped:true};
  if(process.platform!=='linux')return{ok:false,error:(s.label||id)+' is responding on its Minecraft port but is not managed by this panel. Automatic host stop is available only on Linux; stop it from its terminal or service manager.'};
  const match=await findUnmanagedLinuxJava(id,s.port);
  if(!match)return{ok:false,error:(s.label||id)+' is responding, but the panel could not verify a Java process that owns this port and server folder. Nothing was stopped; stop it from its host terminal or service manager.'};
  const verified=await findUnmanagedLinuxJava(id,s.port);if(!verified||verified.pid!==match.pid)return{ok:false,error:'The process changed during verification. Nothing was stopped; try again or stop it from the host terminal.'};
  try{process.kill(match.pid,'SIGINT');return{ok:true,stopping:true,message:'Graceful stop signal sent to the verified Minecraft process (PID '+match.pid+'). Give it a few seconds to save and exit.'}}catch(e){return{ok:false,error:'Could not send a graceful stop signal to PID '+match.pid+' ('+(e.code||e.message)+'). Nothing else was terminated.'}}
}
async function startupChecks(id,ramGB,checkPort=true){
  const s=config.servers[id],checks=[],add=(name,level,detail)=>checks.push({name,level,detail});
  if(!s)return{server:id,ok:false,checks:[{name:'Server',level:'error',detail:'Unknown server.'}]};
  const cwd=serverRoot(id);let cwdOk=false;
  try{const st=await fs.promises.stat(cwd);if(!st.isDirectory())throw Object.assign(Error('Configured server path is not a folder.'),{code:'ENOTDIR'});await fs.promises.access(cwd,fs.constants.R_OK|fs.constants.W_OK);cwdOk=true;add('Server folder','ok','Folder exists and the panel can read and write it.')}catch(e){add('Server folder','error','The panel cannot use the configured folder with its operating-system account ('+(e.code||e.message)+').')}
  const args=buildStartArgs(s,ramGB,ramGB==null),jarAt=args.findIndex(x=>String(x).toLowerCase()==='-jar');
  if(jarAt>=0&&args[jarAt+1]){const jar=path.resolve(cwd,String(args[jarAt+1]));try{const st=await fs.promises.stat(jar);if(!st.isFile())throw Error('Configured JAR path is not a file.');await fs.promises.access(jar,fs.constants.R_OK);add('Server JAR','ok','Configured JAR exists and can be read.')}catch(e){add('Server JAR','error','Configured JAR is missing or cannot be read ('+(e.code||e.message)+').')}}else add('Server JAR','warning','No -jar argument found; confirm this server uses a custom launcher.');
  const javaError=await new Promise(resolve=>execFile(s.command||'java',['-version'],{timeout:5000,windowsHide:true},err=>resolve(err||null)));
  if(javaError)add('Java','error',javaError.code==='ENOENT'?'Java was not found. Install Java or set the correct Java executable in server configuration.':'Java check failed ('+(javaError.code||javaError.message)+').');else add('Java','ok','Java executable responds to a version check.');
  if(cwdOk){try{const eula=await fs.promises.readFile(path.join(cwd,'eula.txt'),'utf8');if(/^\s*eula\s*=\s*true\s*$/mi.test(eula))add('EULA','ok','eula.txt contains eula=true.');else add('EULA','warning','eula.txt does not contain eula=true. Review the Minecraft EULA and set it yourself only if you agree.')}catch{add('EULA','warning','eula.txt was not found. Start once or review the Minecraft EULA file.')}
    try{const st=await fs.promises.statfs(cwd),free=Number(st.bavail)*Number(st.bsize);if(free<1024*1024*1024)add('Disk space','warning','Less than 1 GB is free on the server folder drive.');else add('Disk space','ok',(free/1024/1024/1024).toFixed(1)+' GB is free on the server folder drive.')}catch{add('Disk space','warning','Free disk space could not be checked on this operating system.')}}
  const heapArg=args.find(x=>/^-Xmx(\d+)([MG])$/i.test(String(x))),heapMatch=heapArg&&String(heapArg).match(/^-Xmx(\d+)([MG])$/i),heapGB=ramGB?Number(ramGB):heapMatch?Number(heapMatch[1])*(heapMatch[2].toUpperCase()==='M'?1/1024:1):null;
  if(heapGB&&os.freemem()<heapGB*1024*1024*1024)add('Memory','warning','Requested heap exceeds currently free memory; the OS may use swap or refuse launch.');else if(heapGB)add('Memory','ok','Requested Java heap is within currently free system memory.');
  const port=Number(s.port);if(!checkPort)add('Minecraft port','ok','Port check skipped for this crash report.');else if(!Number.isInteger(port)||port<1||port>65535)add('Minecraft port','error','Configured port is outside the valid range 1–65535.');else{const st=await mcStatus(s.host,port,700);if(st.online)add('Minecraft port','error','A Minecraft server is already responding at '+s.host+':'+port+'.');else add('Minecraft port','ok','No Minecraft server is responding at '+s.host+':'+port+'.')}
  return{server:id,ok:!checks.some(x=>x.level==='error'),checks};
}
async function safeStartProcess(id,options={}){
  if(processes.has(id))return{ok:false,error:'Server is already running.'};if(startLocks.has(id))return{ok:false,error:'A start request for this server is already in progress.'};startLocks.add(id);
  try{const s=config.servers[id];if(!s)return{ok:false,error:'Unknown server.'};const report=await startupChecks(id,options.ramGB),errors=report.checks.filter(x=>x.level==='error');if(errors.length)return{ok:false,error:'Startup checks failed: '+errors.map(x=>x.name+': '+x.detail).join(' ')};const status=await mcStatus(s.host,s.port,900);if(status.online)return{ok:false,error:(s.label||id)+' is already responding on '+s.host+':'+s.port+'. It may have been left running while the panel was offline; no duplicate process was started.'};return startProcess(id,options)}finally{startLocks.delete(id)}
}
async function restartProcess(id,reason='manual'){
  if(!safeId(id)) return {ok:false,error:'Unknown server.'};
  if(processes.get(id)) await stopProcess(id,10000);
  if(processes.get(id)) return {ok:false,error:'Server did not stop cleanly.'};
  await new Promise(r=>setTimeout(r,500));
  const r=await safeStartProcess(id,{quick:true});
  if(r.ok){notify(reason==='scheduled'?'scheduled_restart':'server_restart',`Server restarted${reason==='scheduled'?' by schedule':''}`,id);sendHook('server_restart',{message:`Server restarted (${reason})`},id).catch(()=>{});}
  return r;
}

// Discover one-level Minecraft server folders. The panel only adopts folders
// with server.properties and a runnable server JAR, and never follows links.
function dedupeConfiguredServers(){
  const seenIds=new Set(),seenFolders=new Set();let changed=false;
  for(const [id,s] of Object.entries(config.servers)){
    const folder=typeof s.cwd==='string'?path.resolve(ROOT,s.cwd).replace(/\\/g,'/').toLowerCase():'';
    if(seenIds.has(id.toLowerCase())||(folder&&seenFolders.has(folder))){delete config.servers[id];changed=true;continue}
    seenIds.add(id.toLowerCase());if(folder)seenFolders.add(folder);
  }
  if(changed)writeConfig();
}
function primaryServerRole(id,server){
  const folder=typeof server?.cwd==='string'?path.basename(server.cwd):'';
  const identity=[id,server?.label,server?.type,server?.command,...(Array.isArray(server?.args)?server.args:[]),folder].join(' ');
  if(/\b(proxy|velocity|bungee(?:cord)?|waterfall)\b/i.test(identity))return 'proxy';
  if(/\b(hub|lobby)\b/i.test(identity))return 'hub';
  return null;
}
function retainPrimaryServerConfigs(){
  const network=path.resolve(ROOT,config.networkRoot),retained={},roles=new Set();
  for(const [id,server] of Object.entries(config.servers)){
    const role=primaryServerRole(id,server);
    if(role&&!roles.has(role)){retained[id]=server;roles.add(role);continue}
    if(typeof server?.cwd!=='string')continue;
    const folder=path.resolve(ROOT,server.cwd);
    if(path.dirname(folder).toLowerCase()===network.toLowerCase())legacyNetworkServers.set(folder.replace(/\\/g,'/').toLowerCase(),{id,server});
  }
  config.servers=retained;
}
function discoverServers(){
  if(!config.features.autoDetect)return [];
  const network=path.resolve(ROOT,config.networkRoot);let entries;
  try{entries=fs.readdirSync(network,{withFileTypes:true})}catch{return []}
  const added=[],changed=[],seenAuto=new Set();
  for(const ent of entries){
    if(!ent.isDirectory()||ent.name.startsWith('.'))continue;
    const dir=path.join(network,ent.name),folderKey=path.resolve(dir).replace(/\\/g,'/').toLowerCase(),folderId=ent.name.toLowerCase().replace(/[^a-z0-9_-]/g,'-').replace(/-+/g,'-').replace(/^[^a-z0-9]+|[^a-z0-9_-]+$/g,'').slice(0,24);
    const ignored=(config.ignoredServerFolders||[]).map(x=>String(x).toLowerCase());
    if(!/^[a-z0-9_-]{2,24}$/.test(folderId))continue;
    try{
      if(fs.lstatSync(dir).isSymbolicLink()||fs.existsSync(path.join(dir,'.blockpanel-template-incomplete')))continue;
      const files=fs.readdirSync(dir,{withFileTypes:true});
      if(!files.some(x=>x.isFile()&&x.name.toLowerCase()==='server.properties'))continue;
      const jar=files.filter(x=>x.isFile()&&/\.jar$/i.test(x.name)&&!/(sources|javadoc|installer|server-launcher)/i.test(x.name)).map(x=>x.name).sort((a,b)=>{const rank=n=>/^server\.jar$/i.test(n)?0:/(paper|purpur|spigot|folia|fabric|forge|neoforge)/i.test(n)?1:2;return rank(a)-rank(b)||a.localeCompare(b)})[0];
      if(!jar)continue;
      const props=fs.readFileSync(path.join(dir,'server.properties'),'utf8'),match=props.match(/^\s*server-port\s*=\s*(\d+)\s*$/m),parsedPort=match?Number(match[1]):25565,port=Number.isInteger(parsedPort)&&parsedPort>=1&&parsedPort<=65535?parsedPort:25565;
      const byFolder=Object.entries(config.servers).find(([,s])=>typeof s.cwd==='string'&&path.resolve(ROOT,s.cwd).replace(/\\/g,'/').toLowerCase()===folderKey);
      const byId=Object.entries(config.servers).find(([key,s])=>key.toLowerCase()===folderId&&!primaryServerRole(key,s));
      const configured=byFolder||byId;
      if(configured&&primaryServerRole(configured[0],configured[1])){
        const [primaryId,primary]=configured;
        if(primaryServerRole(primaryId,primary)==='hub'&&primary.port!==port){primary.port=port;changed.push(primaryId)}
        continue;
      }
      if(ignored.includes(ent.name.toLowerCase()))continue;
      const legacy=legacyNetworkServers.get(folderKey),prior=configured||(legacy&&[legacy.id,legacy.server]);
      let id=prior&&/^[a-z0-9_-]{2,24}$/i.test(prior[0])?prior[0]:folderId;
      if(!configured&&config.servers[id]){const base=id.slice(0,20);let suffix=2;while(config.servers[id])id=base+'-'+suffix++;}
      const label=prior?.[1]?.label||ent.name.replace(/[-_]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
      const next={...(prior?.[1]||{}),label,host:prior?.[1]?.host||'127.0.0.1',port,cwd:path.relative(ROOT,dir),command:prior?.[1]?.command||'java',args:Array.isArray(prior?.[1]?.args)&&prior[1].args.length?prior[1].args:['-Xms1G','-Xmx2G','-jar',jar,'--nogui'],stopCommand:prior?.[1]?.stopCommand||'stop'};
      if(!configured){config.servers[id]=next;added.push(id)}
      else if(configured[1].port!==port||configured[1].cwd!==next.cwd||configured[1].label!==label){Object.assign(configured[1],next);changed.push(id)}
      autoDetectedServerIds.add(id);seenAuto.add(id);
    }catch{}
  }
  for(const id of [...autoDetectedServerIds]){
    if(seenAuto.has(id)||processes.has(id))continue;
    if(config.servers[id]){delete config.servers[id];changed.push(id)}
    autoDetectedServerIds.delete(id);
  }
  if(added.length||changed.length)writeConfig();
  for(const id of added){const known=Object.hasOwn(state.metrics,id)||Object.hasOwn(state.serverSettings,id);state.metrics[id]||=[];if(!known)notify('server_discovered','Found new server folder: '+config.servers[id].label,id)}
  return added;
}
retainPrimaryServerConfigs();
dedupeConfiguredServers();
discoverServers();

function mcStatus(host,port,timeout=1000){return new Promise(resolve=>{const socket=new net.Socket();let done=false,buf=Buffer.alloc(0);const finish=r=>{if(done)return;done=true;socket.destroy();resolve(r)};const vi=n=>{const o=[];do{let b=n&127;n>>>=7;if(n)b|=128;o.push(b)}while(n);return Buffer.from(o)};const rv=(b,o=0)=>{let n=0,s=0,i=o;while(i<b.length){const x=b[i++];n|=(x&127)<<s;if(!(x&128))return{value:n>>>0,next:i};s+=7}throw Error('varint')};socket.setTimeout(timeout,()=>finish({online:false}));socket.on('error',()=>finish({online:false}));socket.on('data',d=>{buf=Buffer.concat([buf,d]);try{const h=rv(buf),body=buf.subarray(h.next,h.next+h.value);if(body.length<h.value)return;const id=rv(body);if(id.value!==0)return finish({online:false});const sl=rv(body,id.next);const obj=JSON.parse(body.subarray(sl.next,sl.next+sl.value).toString());finish({online:true,players:obj.players?.online||0,max:obj.players?.max||0,version:obj.version?.name||'Unknown'});}catch{}});socket.connect(Number(port),host,()=>{const hb=Buffer.from(host);const hs=Buffer.concat([vi(47),vi(hb.length),hb,Buffer.from([(port>>8)&255,port&255]),vi(1)]);const p=b=>Buffer.concat([vi(b.length),b]);socket.write(p(Buffer.concat([vi(0),hs])));socket.write(p(vi(0)));});});}
function serverInfo(id){const s=config.servers[id],t=telemetryFor(id),st=statusCache.get(id)||{online:false},managed=processes.has(id);const cs=crashState.get(id)||{count:0},launch=`${id} ${s.label||''} ${s.command||''} ${(s.args||[]).join(' ')}`;return{id,label:s.label,host:s.host,port:s.port,running:managed||!!st.online,managed,unmanaged:!managed&&!!st.online,status:st,telemetry:t,crashes:cs.count||0,maintenance:!!state.serverSettings[id]?.maintenance,proxy:s.type==='velocity'||/velocity|bungee|waterfall/i.test(launch),pluginsSupported:platform.pluginSupportSync(id),software:platform.softwareLabelSync(id)};}

app.disable('x-powered-by');app.use(helmet({contentSecurityPolicy:false}));app.use(express.json({limit:'3mb'}));
// Record successful state-changing API requests without storing request bodies or secrets.
app.use('/api',(req,res,next)=>{const method=req.method;const pathName=req.path;res.on('finish',()=>{const ok=(res.statusCode>=200&&res.statusCode<300)||(pathName==='/login'&&res.statusCode===401);if(!ok||!['POST','PUT','PATCH','DELETE'].includes(method)||pathName==='/logout'||pathName==='/notifications/read')return;const server=pathName.match(/^\/(?:servers|plugins|server-settings|maintenance)\/([^/]+)/)?.[1]||null;audit(req,`${method.toLowerCase()} ${pathName.split('/').filter(Boolean).slice(0,3).join('/')}`,{server,message:`HTTP ${res.statusCode}`});});const scoped=pathName.match(/^\/(?:servers|plugins|players|server-settings|maintenance)\/([^/]+)/),session=sessionFromReq(req);if(scoped&&session&&!isAdmin(session)){const user=getUsers().find(x=>x.username===session.username);if(Array.isArray(user?.servers)&&!user.servers.includes('*')&&!user.servers.includes(scoped[1]))return res.status(403).json({error:'You do not have access to this server.'})}next()});
const platform=require('./platform-api')({app,state,config,saveState,writeConfig,audit,notify,requireAdmin,requirePermission,isAdmin,getUsers,safeId,serverIdExists,serverRoot,safePath,inside,networkRoot,processes,ROOT,DATA,configureVelocityToml,normalizeRel,assertSafeClonePath,getCreationLock:()=>serverCreationInProgress,setCreationLock:v=>{serverCreationInProgress=!!v},panelVersion:require('./package.json').version,requireAuth,serverInfo,writeCommand,history,control:extControl,setHooks:h=>Object.assign(hnHooks,h)});
platform.installEarly();
app.use(express.static(path.join(ROOT,'public')));
app.get('/api/auth',(req,res)=>{const s=sessionFromReq(req);res.json({authenticated:!!s,username:s?.username||null,role:s?.role||null,permissions:s?.permissions||null,profile:state.profiles[s?.username]||{}})});
app.get('/api/sessions',requireAuth,(req,res)=>{const now=Date.now(),current=req.panelSession.id,items=[];for(const [key,s] of sessions){if(s.expiresAt<now){sessions.delete(key);continue}if(s.username===req.panelSession.username)items.push({id:s.id,username:s.username,role:s.role,createdAt:s.createdAt,lastSeen:s.lastSeen,ip:s.ip,userAgent:s.userAgent,current:s.id===current})}items.sort((a,b)=>b.lastSeen-a.lastSeen);res.json({sessions:items})});
app.get('/api/admin/sessions',requireAdmin,(req,res)=>{const now=Date.now(),items=[];for(const [key,s] of sessions){if(s.expiresAt<now){sessions.delete(key);continue}const online=[...wss.clients].some(ws=>ws.readyState===WebSocket.OPEN&&ws.panelSession?.id===s.id);items.push({id:s.id,username:s.username,role:s.role,createdAt:s.createdAt,lastSeen:s.lastSeen,ip:s.ip,userAgent:s.userAgent,current:s.id===req.panelSession.id,online})}items.sort((a,b)=>Number(b.online)-Number(a.online)||b.lastSeen-a.lastSeen);res.json({sessions:items})});
app.delete('/api/admin/sessions/:id',requireAdmin,(req,res)=>{for(const [key,s] of sessions){if(s.id!==req.params.id)continue;if(s.id===req.panelSession.id)return res.status(400).json({error:'You cannot revoke your current session here.'});sessions.delete(key);for(const ws of wss.clients)if(ws.panelSession?.id===s.id){try{ws.close(4001,'Session revoked by administrator')}catch{}}audit(req,'admin_session_revoked',{message:`Revoked ${s.username}'s panel session`});return res.json({ok:true})}return res.status(404).json({error:'Session not found.'})});
app.delete('/api/sessions',requireAuth,(req,res)=>{let revoked=0;for(const [key,s] of sessions)if(s.username===req.panelSession.username&&s.id!==req.panelSession.id){sessions.delete(key);revoked++}audit(req,'other_sessions_revoked',{message:`Signed out ${revoked} other session(s)`});res.json({ok:true,revoked})});
app.delete('/api/sessions/:id',requireAuth,(req,res)=>{for(const [key,s] of sessions)if(s.id===req.params.id&&s.username===req.panelSession.username){sessions.delete(key);audit(req,'session_revoked',{message:`Signed out ${s.id===req.panelSession.id?'this':'another'} session`});if(s.id===req.panelSession.id)res.setHeader('Set-Cookie','panel_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return res.json({ok:true,current:s.id===req.panelSession.id})}return res.status(404).json({error:'Session not found.'})});
app.post('/api/login',async(req,res)=>{const {username,password}=req.body||{},u=getUsers().find(x=>x.username===username);if(!u||!password||!(await bcrypt.compare(password,u.passwordHash||''))){notify('login_failed',`Failed login attempt for ${username||'unknown'}`,null,username||'unknown');return res.status(401).json({error:'Invalid login.'})}setSession(res,u,req);res.json({ok:true,username:u.username,role:normalizedRole(u.role),permissions:normalizedPermissions(u),profile:state.profiles[u.username]||{}})});
app.post('/api/logout',requireAuth,(req,res)=>{const raw=req.headers.cookie||'',item=raw.split(';').find(x=>x.trim().startsWith('panel_session='));if(item)sessions.delete(decodeURIComponent(item.trim().slice(14)));res.setHeader('Set-Cookie','panel_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');res.json({ok:true})});
app.get('/api/servers',requirePermission('dashboard'),(req,res)=>{discoverServers();const out={},u=getUsers().find(x=>x.username===req.panelSession.username),allowed=Array.isArray(u?.servers)?u.servers:null;for(const id of Object.keys(config.servers))if(isAdmin(req.panelSession)||!allowed||allowed.includes('*')||allowed.includes(id))out[id]=serverInfo(id);res.json(out)});
app.get('/api/startup-checks/:id',requirePermission('start'),async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});res.json(await startupChecks(id,Number(req.query.ramGB)||undefined))});
app.get('/api/servers/:id/telemetry',requireAuth,(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const t=telemetryFor(id),now=Date.now(),avg=(ms)=>{const a=t.points.filter(x=>now-x.time<=ms).map(x=>Number(x.tps)).filter(Number.isFinite);return a.length?a.reduce((x,y)=>x+y,0)/a.length:null};res.json({...t,aggregates:{lastSecond:t.lastTpsSecond||t.tps,lastMinute:avg(60000),lastHour:avg(3600000)}})});
async function confirmStart(id,r){
  if(!r?.ok)return r;
  await new Promise(resolve=>setTimeout(resolve,300));
  const child=processes.get(id);
  if(!child){return{ok:false,error:'Server process exited immediately. Check the console for the startup error.'};}
  if(child._spawnError)return{ok:false,error:`Could not start server: ${child._spawnError.message}`};
  return r;
}

async function buildCrashReport(id){
  const s=config.servers[id],cs=crashState.get(id)||{},checks=(await startupChecks(id,undefined,false)).checks;let lines=(history.get(id)||[]).map(x=>String(x.line||''));
  try{const f=await safePath(id,'logs/latest.log'),st=await fs.promises.stat(f.target),limit=2*1024*1024,start=Math.max(0,st.size-limit),h=await fs.promises.open(f.target,'r');try{const b=Buffer.alloc(st.size-start);await h.read(b,0,b.length,start);lines=lines.concat(b.toString('utf8').split(/\r?\n/).filter(Boolean))}finally{await h.close()}}catch{}
  const recentErrors=lines.slice(-1500).filter(x=>/error|exception|fatal|failed|crash|outofmemory|cannot|denied|unable|no such file|address already in use|unsupportedclassversion/i.test(x)).slice(-30).map(x=>x.slice(0,700)),blob=recentErrors.join('\n').toLowerCase(),findings=[];
  if(/outofmemoryerror|could not reserve enough space/.test(blob))findings.push('Memory pressure: lower the Java maximum heap or free memory for other programs.');
  if(/unsupportedclassversionerror|class file version/.test(blob))findings.push('Java version mismatch: install a version supported by this Minecraft server.');
  if(/eula=false|you need to agree to the eula|failed to load eula/.test(blob))findings.push('EULA setup may block startup. Review eula.txt and only set eula=true if you agree.');
  if(/address already in use|failed to bind|bindexception/.test(blob))findings.push('Port binding failed: check for another process and verify server.properties.');
  if(/unable to access jarfile|no such file or directory|cannot find the path/.test(blob))findings.push('A configured file may be missing. Check the server JAR name and working folder.');
  if(/permission denied|eacces|eperm/.test(blob))findings.push('The operating-system account running the panel may lack access to a required file or folder.');
  if(/unsupported major.minor|invalid or corrupt jarfile/.test(blob))findings.push('The server JAR may be damaged or incompatible. Verify its download and the Java version.');
  if(!findings.length)findings.push(recentErrors.length?'No common crash signature matched. Review the error lines and recent server/plugin changes.':'No recent error lines found in panel memory or logs/latest.log.');
  return{server:id,label:s.label||id,generatedAt:new Date().toISOString(),crashCount:cs.count||0,lastCrash:cs.lastCrash?new Date(cs.lastCrash).toISOString():null,running:processes.has(id),startupChecks:checks,findings,recentErrors};
}
app.get('/api/servers/:id/crash-report',requirePermission('console'),async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});try{res.json(await buildCrashReport(id))}catch(e){res.status(500).json({error:'Could not build crash report: '+e.message})}});
app.get('/api/servers/:id/logs',requirePermission('console'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});res.json({logs:history.get(id)||[]})});
app.post('/api/servers/:id/command',requirePermission('console_command'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const r=writeCommand(id,req.body?.command);if(!r.ok)return res.status(400).json(r);res.json(r)});
app.post('/api/servers/:id/quick-launch',requirePermission('start'),async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const r=await confirmStart(id,await safeStartProcess(id,{quick:true}));if(!r.ok)return res.status(400).json(r);res.json(r)});
app.post('/api/servers/:id/:action',requireAuth,async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const a=req.params.action,p={start:'start',stop:'stop',restart:'restart'}[a];if(!p||!req.panelSession.permissions?.[p])return res.status(403).json({error:'You do not have permission for this action.'});let r;if(a==='start')r=await confirmStart(id,await safeStartProcess(id,{ramGB:req.body?.ramGB}));if(a==='stop')r=await stopProcess(id);if(a==='restart')r=await restartProcess(id);if(r?.error)return res.status(400).json(r);res.json(r||{ok:true})});

app.get('/api/players/:id',requirePermission('players_view'),async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const t=history.get(id)||[];let names=[];for(let i=t.length-1;i>=0&&i>t.length-30;i--){const m=t[i].line.match(/There are \d+ of a max of \d+ players online:\s*(.*)/i);if(m){names=m[1].split(',').map(x=>x.trim()).filter(Boolean);break;}}res.json({players:names})});
app.post('/api/players/:id/action',requirePermission('players_actions'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const {action,player}=req.body||{};const allowed={kick:'kick',ban:'ban',ipban:'ban-ip',deop:'deop',op:'op',whitelistAdd:'whitelist add',whitelistRemove:'whitelist remove'};if(!allowed[action]||!/^[A-Za-z0-9_.-]{1,32}$/.test(player||''))return res.status(400).json({error:'Invalid player action.'});const r=writeCommand(id,`${allowed[action]} ${player}`);if(r.ok){notify('player_action',`${action} ${player}`,id,req.panelSession.username);sendHook('player_action',{message:`${action} ${player}`,user:req.panelSession.username},id).catch(()=>{});}res.json(r)});

app.get('/api/users',requirePermission('users_manage'),(req,res)=>res.json({users:publicUsers()}));
app.post('/api/users',requirePermission('users_manage'),async(req,res)=>{const {username,password,role='viewer'}=req.body||{};if(!/^[A-Za-z0-9_.-]{3,32}$/.test(username||''))return res.status(400).json({error:'Invalid username.'});if(typeof password!=='string'||password.length<8)return res.status(400).json({error:'Password must be at least 8 characters.'});if(getUsers().some(u=>u.username===username))return res.status(409).json({error:'User already exists.'});const users=getUsers();users.push({username,passwordHash:await bcrypt.hash(password,12),role,permissions:rolePermissions(role)});config.auth.users=users;delete config.auth.username;delete config.auth.passwordHash;writeConfig();res.json({ok:true,users:publicUsers()})});
app.put('/api/users/:username/permissions',requirePermission('users_manage'),(req,res)=>{const u=getUsers().find(x=>x.username===req.params.username);if(!u)return res.status(404).json({error:'User not found.'});const next={};for(const k of PERMISSIONS)next[k]=req.body?.permissions?.[k]===true;u.permissions=next;if(Array.isArray(req.body?.servers))u.servers=req.body.servers.filter(x=>x==='*'||safeId(x));config.auth.users=getUsers();writeConfig();syncUserSessions(u);res.json({ok:true})});
app.delete('/api/users/:username',requirePermission('users_manage'),(req,res)=>{if(req.params.username===req.panelSession.username)return res.status(400).json({error:'You cannot delete yourself.'});const users=getUsers().filter(x=>x.username!==req.params.username);if(users.length===getUsers().length)return res.status(404).json({error:'User not found.'});config.auth.users=users;writeConfig();res.json({ok:true})});
app.put('/api/users/:username/password',requireAdmin,async(req,res)=>{const u=getUsers().find(x=>x.username===req.params.username);if(!u)return res.status(404).json({error:'User not found.'});if(typeof req.body?.password!=='string'||req.body.password.length<8)return res.status(400).json({error:'Password must be at least 8 characters.'});u.passwordHash=await bcrypt.hash(req.body.password,12);config.auth.users=getUsers();writeConfig();res.json({ok:true})});
app.put('/api/profile',requireAuth,(req,res)=>{const p=state.profiles[req.panelSession.username]||{};if(typeof req.body?.name==='string')p.name=req.body.name.slice(0,48);if(typeof req.body?.icon==='string')p.icon=req.body.icon.slice(0,8);state.profiles[req.panelSession.username]=p;saveState();res.json({ok:true,profile:p})});
app.get('/api/profile/:username',requireAuth,(req,res)=>res.json({profile:state.profiles[req.params.username]||{},online:[...sessions.values()].filter(x=>x.username===req.params.username).length>0}));

// Files + locks/trust
app.get('/api/servers/:id/files',requirePermission('files_view'),async(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});try{const p=await safePath(id,req.query.path||'');checkLocked(req,id,p.rel,'view');const entries=await fs.promises.readdir(p.target,{withFileTypes:true}),files=[];for(const e of entries){if(e.name.startsWith('.blockpanel-upload-')||e.name.startsWith('.blockpanel-plugin-update-'))continue;const rel=p.rel?`${p.rel}/${e.name}`:e.name;const lock=lockFor(id,rel);let locked=!!lock&&!isAdmin(req.panelSession)&&!(lock.users||[]).includes(req.panelSession.username);let st;try{st=await fs.promises.stat(path.join(p.target,e.name))}catch{continue}files.push({name:e.name,path:rel,type:e.isDirectory()?'directory':'file',size:st.size,modified:st.mtime.toISOString(),locked,lock: isAdmin(req.panelSession) && lock ? {users:lock.users||[]} : undefined});}files.sort((a,b)=>a.type===b.type?a.name.localeCompare(b.name):(a.type==='directory'?-1:1));res.json({path:p.rel,files});}catch(e){res.status(e.status||400).json({error:e.message})}});
app.get('/api/servers/:id/file',requirePermission('files_edit'),async(req,res)=>{const id=safeId(req.params.id);try{const p=await safePath(id,req.query.path||'');checkLocked(req,id,p.rel,'edit');const st=await fs.promises.stat(p.target);if(!st.isFile())throw Error('Not a file.');if(st.size>2*1024*1024)throw Error('File is larger than 2 MB.');const b=await fs.promises.readFile(p.target);if(b.includes(0))throw Error('Binary files cannot be edited.');res.json({path:p.rel,content:b.toString('utf8')})}catch(e){res.status(e.status||400).json({error:e.message})}});
app.put('/api/servers/:id/file',requirePermission('files_edit'),async(req,res)=>{const id=safeId(req.params.id);try{checkLocked(req,id,normalizeRel(req.body?.path||''),'edit');const p=await safePath(id,req.body.path,true);await fs.promises.writeFile(p.target,String(req.body.content||''),'utf8');notify('file_change',`Edited ${p.rel}`,id,req.panelSession.username);res.json({ok:true})}catch(e){res.status(e.status||400).json({error:e.message})}});
app.get('/api/servers/:id/download',requirePermission('files_view'),async(req,res)=>{const id=safeId(req.params.id);try{const p=await safePath(id,req.query.path||'');checkLocked(req,id,p.rel,'download');const st=await fs.promises.stat(p.target);if(!st.isFile())throw Error('Not a file.');res.download(p.target,path.basename(p.target));}catch(e){res.status(e.status||400).json({error:e.message})}});
app.post('/api/servers/:id/mkdir',requirePermission('files_edit'),async(req,res)=>{const id=safeId(req.params.id);try{checkLocked(req,id,normalizeRel(req.body.path||''),'edit');const p=await safePath(id,req.body.path,true);await fs.promises.mkdir(p.target);res.json({ok:true})}catch(e){res.status(e.status||400).json({error:e.message})}});
app.post('/api/servers/:id/rename',requirePermission('files_edit'),async(req,res)=>{const id=safeId(req.params.id);try{checkLocked(req,id,normalizeRel(req.body.from||''),'rename');const p=await safePath(id,req.body.from),to=await safePath(id,req.body.to,true);checkLocked(req,id,to.rel,'rename');const exists=await fs.promises.lstat(to.target).then(()=>true,()=>false);if(exists)throw Error('A file or folder with that name already exists.');await fs.promises.rename(p.target,to.target);res.json({ok:true})}catch(e){res.status(e.status||400).json({error:e.message})}});
app.delete('/api/servers/:id/file',requirePermission('files_delete'),async(req,res)=>{const id=safeId(req.params.id);try{const p=await safePath(id,req.query.path||'');if(!p.rel)throw Error('Cannot delete server root.');checkLocked(req,id,p.rel,'delete');const st=await fs.promises.lstat(p.target);await fs.promises.rm(p.target,{recursive:st.isDirectory(),force:true});res.json({ok:true})}catch(e){res.status(e.status||400).json({error:e.message})}});
function uploadErrorResponse(res,error){
  if(error instanceof multer.MulterError){
    const messages={LIMIT_FILE_COUNT:'Too many files (100 maximum).',LIMIT_FIELD_COUNT:'The upload request contains too many fields.',LIMIT_FIELD_VALUE:'An upload field is too large.',LIMIT_UNEXPECTED_FILE:'Unexpected upload field.'};
    return res.status(400).json({error:messages[error.code]||'Upload failed: '+error.message});
  }
  const osDenied=error.code==='EACCES'||error.code==='EPERM',noSpace=error.code==='ENOSPC';
  const status=osDenied?403:(error.status||400);
  const message=osDenied?'The panel cannot write to this server folder with its operating-system account. Grant write access to the user running the panel, then retry. ('+error.code+')':noSpace?'The selected server drive is out of free space. Make space on that drive and retry.':error.message||'Upload failed.';
  return res.status(status).json({error:message});
}

async function prepareServerUpload(req,res,next){
  let stagingDir;
  try{
    const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});
    const dir=await safePath(id,req.query.path||'');checkLocked(req,id,dir.rel,'upload');
    stagingDir=path.join(dir.target,'.blockpanel-upload-'+crypto.randomUUID());
    await fs.promises.mkdir(stagingDir,{mode:0o700});
    req.uploadContext={id,dir,stagingDir};
    next();
  }catch(error){
    if(stagingDir)await fs.promises.rm(stagingDir,{recursive:true,force:true}).catch(()=>{});
    uploadErrorResponse(res,error);
  }
}

function parseServerUpload(req,res,next){
  upload.array('files',100)(req,res,async error=>{
    if(!error)return next();
    await fs.promises.rm(req.uploadContext?.stagingDir,{recursive:true,force:true}).catch(()=>{});
    uploadErrorResponse(res,error);
  });
}

app.post('/api/servers/:id/upload',requireAuth,prepareServerUpload,parseServerUpload,async(req,res)=>{
  const {id,dir,stagingDir}=req.uploadContext,createdTargets=[];
  try{
    const files=req.files||[];if(!files.length)return res.status(400).json({error:'No files were uploaded.'});
    const prepared=[],names=new Set();
    for(const f of files){
      const name=path.posix.basename(String(f.originalname||'').replace(/\\/g,'/')).replace(/[\x00-\x1f]/g,'_');
      if(!name||name==='.'||name==='..')continue;
      const folded=name.toLocaleLowerCase('en-US');if(names.has(folded))return res.status(409).json({error:'The upload contains the same filename more than once: '+name});names.add(folded);
      const rel=dir.rel?dir.rel+'/'+name:name;checkLocked(req,id,rel,'upload');
      const target=await safePath(id,rel,true);if(fs.existsSync(target.target))return res.status(409).json({error:name+' already exists. Rename or remove the existing file before uploading.'});
      prepared.push({name,rel,target,file:f});
    }
    if(!prepared.length)return res.status(400).json({error:'No valid files were provided.'});
    for(const {name,target,file} of prepared){
      let handle;
      try{
        try{
          await fs.promises.link(file.path,target.target);
          createdTargets.push(target.target);
          await fs.promises.unlink(file.path).catch(()=>{});
          continue;
        }catch(linkError){
          if(linkError.code==='EEXIST')throw Object.assign(new Error(name+' was created while uploading. The existing file was not overwritten.'),{status:409});
          if(!['EPERM','EACCES','EOPNOTSUPP','ENOSYS','EXDEV','EINVAL','EMLINK'].includes(linkError.code))throw linkError;
        }
        handle=await fs.promises.open(target.target,'wx');createdTargets.push(target.target);await pipeline(fs.createReadStream(file.path),handle.createWriteStream({autoClose:false}));await handle.sync();
      }catch(error){if(error.code==='EEXIST')throw Object.assign(new Error(name+' was created while uploading. The existing file was not overwritten.'),{status:409});throw error;}
      finally{await handle?.close().catch(()=>{});}
    }
    for(const {rel} of prepared)notify('file_change','Uploaded '+rel,id,req.panelSession.username);
    res.json({ok:true,count:prepared.length});
  }catch(error){
    for(const target of createdTargets.reverse())await fs.promises.rm(target,{force:true}).catch(()=>{});
    uploadErrorResponse(res,error);
  }finally{await fs.promises.rm(stagingDir,{recursive:true,force:true}).catch(()=>{});}
});
app.post('/api/locks',requireAdmin,async(req,res)=>{const {server,path:rel,users=[]}=req.body||{};if(!safeId(server))return res.status(400).json({error:'Unknown server.'});const clean=normalizeRel(rel);if(!clean)return res.status(400).json({error:'Cannot lock server root.'});state.locks[server]||={};state.locks[server][clean]={users:[...new Set(users)]};saveState();res.json({ok:true})});
app.post('/api/locks/unlock',requireAdmin,(req,res)=>{const {server,path:rel}=req.body||{};if(state.locks[server])delete state.locks[server][normalizeRel(rel)];saveState();res.json({ok:true})});
app.post('/api/locks/trust',requireAdmin,(req,res)=>{const {server,path:rel,user}=req.body||{},l=state.locks[server]?.[normalizeRel(rel)];if(!l)return res.status(404).json({error:'Lock not found.'});if(!getUsers().some(x=>x.username===user))return res.status(404).json({error:'User not found.'});l.users=[...new Set([...(l.users||[]),user])];saveState();res.json({ok:true,users:l.users})});
app.get('/api/locks',requireAdmin,(req,res)=>res.json({locks:state.locks}));

// Hooks and notifications
app.get('/api/hooks',requireAdmin,(req,res)=>res.json({actions:HOOK_ACTIONS,servers:['*',...Object.keys(config.servers)],hooks:(state.hooks||[]).map(h=>({id:h.id,name:h.name,server:h.server,action:h.action,configured:!!h.url}))}));
app.put('/api/hooks',requireAdmin,(req,res)=>{const {id,name,server='*',action,url=''}=req.body||{};const hooks=state.hooks||[];const item=id&&hooks.find(h=>h.id===id);if(id&&!item)return res.status(404).json({error:'Hook not found.'});if(!HOOK_ACTIONS.includes(action)||(!config.servers[server]&&server!=='*')||typeof name!=='string'||!name.trim()||name.trim().length>64||typeof url!=='string'||(!url&&!item)||(url&&!/^https:\/\//i.test(url)))return res.status(400).json({error:'Provide a name, valid action and server, and an HTTPS webhook URL for new hooks.'});const record={id:item?.id||crypto.randomUUID(),name:name.trim(),server,action,url:url?encrypt(url):item.url};if(item)Object.assign(item,record);else hooks.push(record);state.hooks=hooks;saveState();audit(req,item?'hook_updated':'hook_created',{server,message:`${record.name} (${action})`});res.json({ok:true,id:record.id})});
app.delete('/api/hooks/:id',requireAdmin,(req,res)=>{const hooks=state.hooks||[],index=hooks.findIndex(h=>h.id===req.params.id);if(index<0)return res.status(404).json({error:'Hook not found.'});const [removed]=hooks.splice(index,1);saveState();audit(req,'hook_deleted',{server:removed.server,message:removed.name});res.json({ok:true})});
app.get('/api/audit',requireAdmin,(req,res)=>res.json({entries:state.audit.slice(0,2000)}));
app.get('/api/notifications',requirePermission('notifications_view'),(req,res)=>res.json({notifications:state.notifications.slice(0,200)}));
app.post('/api/notifications/read',requirePermission('notifications_view'),(req,res)=>{for(const n of state.notifications)if(!req.body?.id||n.id===req.body.id)n.read=true;saveState();res.json({ok:true})});

// Backups
function configureVelocityToml(text,port,backends){
let content=String(text||'');const bind='bind = "0.0.0.0:'+port+'"';
if(/^\s*bind\s*=.*$/m.test(content))content=content.replace(/^\s*bind\s*=.*$/m,bind);else content=bind+'\n\n'+content;
const valid=backends.filter(x=>safeId(x.id)&&Number.isInteger(Number(x.port))&&Number(x.port)>0&&Number(x.port)<=65535&&typeof x.host==='string'&&x.host.trim());
const routes=valid.map(x=>{const host=isIP(x.host)===6?'['+x.host+']':x.host;const key=safeId(x.id)?x.id:JSON.stringify(x.id);return key+' = '+JSON.stringify(host+':'+Number(x.port))});
const first=valid.find(x=>x.id.toLowerCase()==='lobby')||valid[0];
const sectionText=['[servers]','# Backend routes generated from the panel server list.'].concat(routes.length?routes:['# Add backend servers in the panel to create routes.'],['','try = [']).concat(first?['    '+JSON.stringify(first.id)]:[]).concat([']','']).join('\n');
const section=/^\[servers\][ \t]*$/m.exec(content);
if(section){const after=section.index+section[0].length,next=/^\[[^\]]+\][ \t]*$/m.exec(content.slice(after)),end=next?after+next.index:content.length;content=content.slice(0,section.index)+sectionText+content.slice(end)}else content+=(content.endsWith('\n')?'':'\n')+'\n'+sectionText;
const query=/^\[query\][ \t]*$/m.exec(content);
if(query){const after=query.index+query[0].length,next=/^\[[^\]]+\][ \t]*$/m.exec(content.slice(after)),end=next?after+next.index:content.length,part=content.slice(after,end);content=content.slice(0,after)+( /^\s*port\s*=/m.test(part)?part.replace(/^\s*port\s*=.*$/m,'port = '+port):part)+content.slice(end)}
return content
}
function isVelocityServer(id,s={}){const launch=[id,s.type||'',s.label||'',s.command||'',...(Array.isArray(s.args)?s.args:[])].join(' ');return String(s.type||'').toLowerCase()==='velocity'||/velocity|bungee|waterfall/i.test(launch)}
function removeVelocityRouteFromToml(text,id){
  let content=String(text||'');const section=/^\[servers\][ \t]*$/m.exec(content);if(!section)return content;
  const after=section.index+section[0].length,next=/^\[[^\]]+\][ \t]*$/m.exec(content.slice(after)),end=next?after+next.index:content.length;let part=content.slice(section.index,end);
  const escaped=String(id).split('').map(ch=>'\\.^$*+?()[]{}|'.includes(ch)?'\\'+ch:ch).join('');const route=new RegExp('^[ \\t]*"?'+escaped+'"?[ \\t]*=[^\\r\\n]*(?:\\r?\\n|$)','gm');part=part.replace(route,'');
  const array=/^([ \t]*try[ \t]*=[ \t]*\[)([\s\S]*?)(\][ \t]*(?:#.*)?$)/m.exec(part);
  if(array){
    let values=[];for(const match of array[2].matchAll(/"((?:\\.|[^"\\])*)"/g)){try{values.push(JSON.parse('"'+match[1]+'"'))}catch{}}
    if(values.includes(id)){
      values=values.filter(x=>x!==id);
      if(!values.length){const tryAt=part.search(/^[ \t]*try[ \t]*=/m),routeText=tryAt<0?part:part.slice(0,tryAt),available=[...routeText.matchAll(/^[ \t]*(?:"([^"\\]+)"|([A-Za-z0-9_-]+))[ \t]*=/gm)].map(x=>x[1]||x[2]);if(available.length)values.push(available[0]);}
      const multiline=/\r?\n/.test(array[2]),indent=array[2].match(/\r?\n([ \t]*)"/)?.[1]||'    ',closingIndent=array[2].match(/\r?\n([ \t]*)$/)?.[1]||'';
      const inner=multiline?(values.length?'\n'+values.map(x=>indent+JSON.stringify(x)).join(',\n')+'\n'+closingIndent:'\n'+closingIndent):(values.length?' '+values.map(JSON.stringify).join(', ')+' ':'');
      part=part.slice(0,array.index)+array[1]+inner+array[3]+part.slice(array.index+array[0].length);
    }
  }
  return content.slice(0,section.index)+part+content.slice(end)
}
async function removeVelocityRouteFromProxies(serverId){
  const result={updated:[],warnings:[]};
  for(const [proxyId,proxy] of Object.entries(config.servers)){
    if(!isVelocityServer(proxyId,proxy))continue;
    let temp='';
    try{
      const root=serverRoot(proxyId),rootStat=await fs.promises.lstat(root);if(rootStat.isSymbolicLink()||!rootStat.isDirectory())throw Error('proxy folder is not a normal directory');
      const file=path.join(root,'velocity.toml'),fileStat=await fs.promises.lstat(file);if(fileStat.isSymbolicLink()||!fileStat.isFile())throw Error('velocity.toml is not a regular file');
      const original=await fs.promises.readFile(file,'utf8'),updated=removeVelocityRouteFromToml(original,serverId);if(updated===original)continue;
      temp=path.join(root,'.velocity.toml.blockpanel-'+crypto.randomUUID()+'.tmp');await fs.promises.writeFile(temp,updated,{mode:fileStat.mode&0o777});await fs.promises.rename(temp,file);temp='';result.updated.push(proxyId);
    }catch(e){result.warnings.push(proxyId+': '+e.message)}
    finally{if(temp)await fs.promises.unlink(temp).catch(()=>{})}
  }
  return result
}
function networkRoot(){return path.resolve(ROOT,config.networkRoot);}
function publicAddress(ip){if(ip.includes(':')){const x=ip.toLowerCase(),first=parseInt(x.split(':')[0]||'0',16);return first>=0x2000&&first<=0x3fff&&!x.startsWith('2001:db8:')&&!x.startsWith('2002:');}const p=ip.split('.').map(Number),special=p[0]===100&&p[1]>=64&&p[1]<=127||p[0]===192&&(p[1]===0||p[1]===88&&p[2]===99||p[1]===168)||p[0]===198&&(p[1]===18||p[1]===19||p[1]===51)||p[0]===203&&p[1]===0&&p[2]===113;return p.length===4&&p.every(x=>x>=0&&x<=255)&&!(special||p[0]===0||p[0]===10||p[0]===127||p[0]>=224||(p[0]===169&&p[1]===254)||(p[0]===172&&p[1]>=16&&p[1]<=31));}
async function assertPublicHttps(u){if(u.protocol!=='https:'||u.username||u.password)throw Error('Use a public HTTPS URL without credentials.');const hostname=u.hostname.replace(/^\[|\]$/g,'');const ipType=isIP(hostname);const addresses=ipType?[{address:hostname}]:await dns.lookup(hostname,{all:true,verbatim:true});if(!addresses.length||addresses.some(x=>!publicAddress(x.address)))throw Error('Plugin host resolves to a non-public address.');}
async function jarPluginMeta(file){try{const b=await fs.promises.readFile(file),sig=Buffer.from([0x50,0x4b,0x05,0x06]),end=b.lastIndexOf(sig);if(end<0)return null;const count=b.readUInt16LE(end+10);let p=b.readUInt32LE(end+16);for(let i=0;i<count&&p+46<b.length;i++){if(b.readUInt32LE(p)!==0x02014b50)break;const method=b.readUInt16LE(p+10),size=b.readUInt32LE(p+20),nameLen=b.readUInt16LE(p+28),extra=b.readUInt16LE(p+30),comment=b.readUInt16LE(p+32),local=b.readUInt32LE(p+42),name=b.subarray(p+46,p+46+nameLen).toString();if(['plugin.yml','paper-plugin.yml'].includes(name)&&size<1024*1024&&local+30<b.length){const lName=b.readUInt16LE(local+26),lExtra=b.readUInt16LE(local+28),start=local+30+lName+lExtra,compressed=b.subarray(start,start+size),raw=method===0?compressed:method===8?inflateRawSync(compressed):null;if(raw){const text=raw.toString('utf8'),get=k=>text.match(new RegExp(`^${k}:\\s*['\"]?([^\\r\\n'\"]+)`,'mi'))?.[1]?.trim();return{name:get('name'),version:get('version')}}}p+=46+nameLen+extra+comment}return null}catch{return null}}
function backupRoot(){const configured=typeof config.backupDirectory==='string'&&config.backupDirectory.trim()?config.backupDirectory.trim():path.join(path.dirname(networkRoot()),'MinecraftBackups');const dir=path.isAbsolute(configured)?path.resolve(configured):path.resolve(ROOT,configured);if(inside(networkRoot(),dir))throw new Error('Backup directory must be outside MinecraftNetwork.');return dir}
function legacyBackupRoot(){return path.resolve(path.dirname(networkRoot()),'MinecraftBackups')}
function backupRoots(){return [...new Set([backupRoot(),legacyBackupRoot()])]}
function isBackupPath(file){try{const target=path.resolve(String(file||''));return backupRoots().some(root=>target!==root&&inside(root,target))}catch{return false}}
function mountInfoHasTarget(file,mount){try{return fs.readFileSync(file,'utf8').split(/\r?\n/).some(line=>{const separator=line.indexOf(' - ');if(separator<0)return false;const fields=line.slice(0,separator).split(/\s+/),field=fields[4];if(!field)return false;const decoded=field.replace(/\\([0-7]{3})/g,(_,oct)=>String.fromCharCode(parseInt(oct,8)));return path.resolve(decoded)===mount})}catch{return false}}
function assertBackupDiskMounted(){if(process.platform!=='linux'||!config.backupMount)return;const mount=path.resolve(config.backupMount);let present=mountInfoHasTarget('/proc/self/mountinfo',mount);if(!present){try{const disk=fs.statSync(mount),parent=fs.statSync(path.dirname(mount));present=disk.dev!==parent.dev}catch{}}if(present)return;if(mountInfoHasTarget('/proc/1/mountinfo',mount))throw new Error(`The backup disk is mounted at ${mount} on Linux but is not visible to the panel. Restart the panel after mounting it or remove mount-namespace isolation from the the panel service.`);throw new Error(`The backup disk is not mounted at ${mount}. Mount it before creating or restoring backups.`)}
async function backupNow(kind='manual'){const src=networkRoot(),base=path.basename(src),dir=backupRoot();if(!fs.existsSync(src))throw new Error('MinecraftNetwork folder was not found: '+src);assertBackupDiskMounted();await fs.promises.mkdir(dir,{recursive:true});const stamp=new Date().toISOString().replace(/[:.]/g,'-'),out=path.join(dir,base+'-'+stamp+'.tar.gz'),temp=out+'.part-'+crypto.randomUUID();try{await new Promise((resolve,reject)=>execFile('tar',['-czf',temp,'-C',path.dirname(src),base],{timeout:30*60*1000},err=>err?reject(err):resolve()));await fs.promises.rename(temp,out)}catch(err){await fs.promises.unlink(temp).catch(()=>{});throw err}const item={file:out,created:new Date().toISOString(),size:(await fs.promises.stat(out)).size,kind};state.backups.unshift(item);saveState();notify('backup_completed','Backup completed: '+path.basename(out));await pruneBackups();return item}
async function pruneBackups(){const cfg=state.backupConfig||{},daily=state.backups.filter(x=>x.kind==='daily').sort((a,b)=>Date.parse(b.created)-Date.parse(a.created)).slice(0,Math.max(1,Number(cfg.keepDaily||7))),weekly=state.backups.filter(x=>x.kind==='weekly').sort((a,b)=>Date.parse(b.created)-Date.parse(a.created)).slice(0,Math.max(1,Number(cfg.keepWeekly||4))),manual=state.backups.filter(x=>!['daily','weekly'].includes(x.kind)).sort((a,b)=>Date.parse(b.created)-Date.parse(a.created)).slice(0,20),keep=new Set([...daily,...weekly,...manual]);for(const item of state.backups){if(keep.has(item))continue;try{if(isBackupPath(item.file))await fs.promises.unlink(path.resolve(item.file))}catch{}}state.backups=[...keep].sort((a,b)=>Date.parse(b.created)-Date.parse(a.created));saveState()}
app.get('/api/backups',requirePermission('backups'),(req,res)=>res.json({backups:state.backups.map(x=>({...x,file:path.basename(x.file)}))}));
app.post('/api/backups',requirePermission('backups'),async(req,res)=>{try{const b=await backupNow();res.json({ok:true,backup:{...b,file:path.basename(b.file)}})}catch(e){res.status(500).json({error:`Backup failed: ${e.message}`})}});
app.get('/api/backups/:file/download',requirePermission('backups'),(req,res)=>{const file=path.basename(req.params.file),item=state.backups.find(x=>path.basename(x.file)===file);if(!item||!isBackupPath(item.file)||!fs.existsSync(item.file))return res.status(404).json({error:'Backup not found.'});res.download(item.file,file)});
app.post('/api/backups/:file/restore',requireAdmin,async(req,res)=>{const file=path.basename(req.params.file),item=state.backups.find(x=>path.basename(x.file)===file);if(!item||!isBackupPath(item.file)||!fs.existsSync(item.file))return res.status(404).json({error:'Backup not found.'});if(processes.size)return res.status(409).json({error:'Stop every Minecraft server before restoring.'});const src=networkRoot(),parent=path.dirname(src),base=path.basename(src),store=backupRoot(),archive=path.resolve(item.file);if(!isBackupPath(archive))return res.status(400).json({error:'Invalid backup path.'});const temp=path.join(parent,'.blockpanel-restore-'+crypto.randomUUID()),staging=path.join(temp,base),stamp=new Date().toISOString().replace(/[:.]/g,'-'),safety=path.join(store,base+'-before-restore-'+stamp+'-'+crypto.randomUUID()),previous=path.join(parent,'.blockpanel-before-restore-'+crypto.randomUUID());try{assertBackupDiskMounted();await fs.promises.mkdir(store,{recursive:true});await fs.promises.mkdir(temp,{recursive:true});const listing=await new Promise((resolve,reject)=>execFile('tar',['-tzf',archive],{maxBuffer:20*1024*1024,timeout:30*60*1000},(err,out)=>err?reject(err):resolve(out)));for(const raw of listing.split(/\r?\n/).filter(Boolean)){const entry=raw.replace(/\\/g,'/');if(entry.startsWith('/')||entry.split('/').includes('..')||!(entry===base||entry.startsWith(base+'/')))throw Error('Backup contains an unsafe path.');}await new Promise((resolve,reject)=>execFile('tar',['-xzf',archive,'-C',temp,'--no-same-owner','--no-same-permissions'],{timeout:30*60*1000},err=>err?reject(err):resolve()));if(!fs.existsSync(staging)||!(await fs.promises.stat(staging)).isDirectory())throw Error('Backup does not contain the expected network folder.');await fs.promises.cp(src,safety,{recursive:true,errorOnExist:true,force:false,preserveTimestamps:true});await fs.promises.rename(src,previous);try{await fs.promises.rename(staging,src)}catch(e){await fs.promises.rename(previous,src);throw e}await fs.promises.rm(previous,{recursive:true,force:true}).catch(()=>{});await fs.promises.rm(temp,{recursive:true,force:true});audit(req,'backup_restored',{message:file+'; previous data saved as '+path.basename(safety)});res.json({ok:true,safetyCopy:path.basename(safety)})}catch(e){await fs.promises.rm(temp,{recursive:true,force:true}).catch(()=>{});res.status(500).json({error:'Restore failed: '+e.message})}});

// Server settings: auto restart, max crash restarts, delay, scheduled restart.
app.get('/api/server-settings/:id',requirePermission('server_settings'),(req,res)=>res.json({settings:state.serverSettings[req.params.id]||{autoRestart:false,maxRestarts:3,restartDelay:10,scheduleEnabled:false,scheduleTime:'04:00'}}));
app.put('/api/server-settings/:id',requirePermission('server_settings'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const old=state.serverSettings[id]||{},next={...old,autoRestart:req.body.autoRestart===true,maxRestarts:Math.max(0,Math.min(20,Number(req.body.maxRestarts??3))),restartDelay:Math.max(0,Math.min(3600,Number(req.body.restartDelay??10))),scheduleEnabled:req.body.scheduleEnabled===true,scheduleTime:/^\d\d:\d\d$/.test(req.body.scheduleTime||'')?req.body.scheduleTime:'04:00',tpsWarn:Math.max(1,Math.min(20,Number(req.body.tpsWarn??old.tpsWarn??15))),ramWarnMB:Math.max(0,Math.min(1048576,Number(req.body.ramWarnMB??old.ramWarnMB??0))),diskWarnPercent:Math.max(50,Math.min(99,Number(req.body.diskWarnPercent??old.diskWarnPercent??90)))};state.serverSettings[id]=next;saveState();res.json({ok:true,settings:next})});

// Plugin manager: safe file-based enable/disable plus PlugMan command if installed.
app.get('/api/plugins/:id',requirePermission('files_view'),async(req,res)=>{
  const id=safeId(req.params.id); if(!id)return res.status(404).json({error:'Unknown server.'});
  let root;try{root=(await safePath(id,'plugins')).target}catch(e){if(!fs.existsSync(path.join(serverRoot(id),'plugins')))return res.json({plugins:[]});throw e}
  const files=fs.readdirSync(root,{withFileTypes:true}); const items=[];
  for(const e of files){if(!e.isFile()||!/\.jar(?:\.disabled)?$/i.test(e.name))continue;const enabled=!/\.disabled$/i.test(e.name),base=e.name.replace(/\.jar(?:\.disabled)?$/i,'');const st=fs.statSync(path.join(root,e.name));const configs=files.filter(c=>c.isFile()&&new RegExp(`^${base.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\.(yml|yaml|properties|conf)$`,'i').test(c.name)).map(c=>c.name);items.push({file:e.name,name:base,enabled,size:st.size,modified:st.mtime.toISOString(),configs});}
  items.sort((a,b)=>a.name.localeCompare(b.name)); res.json({plugins:items});
});
app.post('/api/plugins/:id/toggle',requireAdmin,async(req,res)=>{
  const id=safeId(req.params.id),name=path.basename(String(req.body?.file||''));
  if(!id||!/^.+\.jar(?:\.disabled)?$/i.test(name))return res.status(400).json({error:'Invalid plugin.'});
  const from=await safePath(id,`plugins/${name}`).catch(()=>null),dest=name.endsWith('.disabled')?name.slice(0,-9):name+'.disabled',to=await safePath(id,`plugins/${dest}`,true).catch(()=>null);
  if(!from||!to||!fs.existsSync(from.target))return res.status(404).json({error:'Plugin not found.'});
  await fs.promises.rename(from.target,to.target); notify('file_change',`${name.endsWith('.disabled')?'Enabled':'Disabled'} plugin ${name.replace(/\.disabled$/,'')}`,id,req.panelSession.username); res.json({ok:true,restartRequired:true});
});
app.post('/api/plugins/:id/restart',requireAdmin,async(req,res)=>{
  const id=safeId(req.params.id),name=String(req.body?.name||'').replace(/[^A-Za-z0-9_.-]/g,''); if(!id||!name)return res.status(400).json({error:'Invalid plugin.'});
  const r=writeCommand(id,`plugman reload ${name}`); if(!r.ok)return res.status(400).json(r); res.json({ok:true,message:'PlugMan reload command sent.'});
});
app.post('/api/plugins/:id/install',requireAdmin,async(req,res)=>{
  const id=safeId(req.params.id),url=String(req.body?.url||''),replaceFile=String(req.body?.replaceFile||''); if(!id||!/^https:\/\//i.test(url)||replaceFile&&(!/^[A-Za-z0-9_. -]+\.jar$/i.test(replaceFile)||path.basename(replaceFile)!==replaceFile))return res.status(400).json({error:'Only HTTPS plugin URLs and valid JAR names are allowed.'});
  try{
    let u=new URL(url); let r; for(let n=0;n<=3;n++){await assertPublicHttps(u);r=await fetch(u,{redirect:'manual',signal:AbortSignal.timeout(60000)});if(r.status>=300&&r.status<400&&r.headers.get('location')){if(n===3)throw Error('Too many redirects.');u=new URL(r.headers.get('location'),u);continue}break} if(!r.ok)throw Error(`Download failed (${r.status}).`);
    const length=Number(r.headers.get('content-length')||0);if(length>100*1024*1024)throw Error('Plugin is larger than 100 MB.');const reader=r.body.getReader(),chunks=[];let size=0;for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>100*1024*1024){await reader.cancel();throw Error('Plugin is larger than 100 MB.')}chunks.push(Buffer.from(value))}const buf=Buffer.concat(chunks);if(buf.length<4||buf[0]!==0x50||buf[1]!==0x4b)throw Error('Downloaded file is not a ZIP/JAR archive.');
    let name=decodeURIComponent(path.basename(u.pathname)||'plugin.jar').replace(/[\x00-\x1f]/g,'_'); if(!/^[A-Za-z0-9_. -]+\.jar$/i.test(name))throw Error('URL must point to a .jar file with a safe filename.');
    const plugins=await safePath(id,'plugins',true);await fs.promises.mkdir(plugins.target,{recursive:true});const finalName=replaceFile||name,target=await safePath(id,`plugins/${finalName}`,true);if(replaceFile){if(!fs.existsSync(target.target))throw Error('Plugin to update was not found.');const temp=`${target.target}.download-${crypto.randomUUID()}`,backup=`${target.target}.previous-${new Date().toISOString().replace(/[:.]/g,'-')}`;await fs.promises.writeFile(temp,buf,{flag:'wx'});await fs.promises.rename(target.target,backup);try{await fs.promises.rename(temp,target.target)}catch(e){await fs.promises.rename(backup,target.target);throw e}}else await fs.promises.writeFile(target.target,buf,{flag:'wx'});notify('file_change',`${replaceFile?'Updated':'Installed'} plugin ${finalName}`,id,req.panelSession.username);res.json({ok:true,file:finalName,restartRequired:true});
  }catch(e){res.status(400).json({error:e.message||'Plugin install failed.'});}
});

async function preparePluginUpdateUpload(req,res,next){
  let stagingDir;
  try{
    const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});
    let plugins=await safePath(id,'plugins',true);
    await fs.promises.mkdir(plugins.target,{recursive:true});
    plugins=await safePath(id,'plugins');
    stagingDir=path.join(plugins.target,'.blockpanel-plugin-update-'+crypto.randomUUID());
    await fs.promises.mkdir(stagingDir,{mode:0o700});
    req.pluginUpdateContext={id,pluginsDir:plugins.target,stagingDir};
    pluginUpload.single('plugin')(req,res,async error=>{
      if(!error)return next();
      await fs.promises.rm(stagingDir,{recursive:true,force:true}).catch(()=>{});
      const message=error instanceof multer.MulterError&&error.code==='LIMIT_FILE_SIZE'?'Custom plugin JAR must be 100 MB or smaller.':error instanceof multer.MulterError?'Plugin upload failed: '+error.message:error.message||'Plugin upload failed.';
      res.status(error instanceof multer.MulterError?400:(error.status||400)).json({error:message});
    });
  }catch(error){
    if(stagingDir)await fs.promises.rm(stagingDir,{recursive:true,force:true}).catch(()=>{});
    const denied=error.code==='EACCES'||error.code==='EPERM';
    res.status(denied?403:(error.status||400)).json({error:denied?'The panel cannot write to this server plugin folder with its operating-system account. Grant write access to the user running the panel, then retry. ('+error.code+')':error.message||'Plugin upload failed.'});
  }
}

app.post('/api/plugins/:id/update-upload',requireAdmin,preparePluginUpdateUpload,async(req,res)=>{
  const context=req.pluginUpdateContext;
  let backupPath=null,previousMoved=false;
  try{
    const replaceFile=String(req.body?.replaceFile||'');
    if(!/^[A-Za-z0-9_. -]+\.jar(?:\.disabled)?$/i.test(replaceFile)||path.basename(replaceFile)!==replaceFile)throw Object.assign(new Error('Choose a valid installed plugin JAR.'),{status:400});
    if(!req.file)throw Object.assign(new Error('Choose a custom plugin JAR to upload.'),{status:400});
    const uploadedName=path.posix.basename(String(req.file.originalname||'').replace(/\\/g,'/'));
    if(!/^[A-Za-z0-9_. -]+\.jar$/i.test(uploadedName))throw Object.assign(new Error('The selected custom plugin file must end in .jar.'),{status:400});
    const handle=await fs.promises.open(req.file.path,'r');
    const header=Buffer.alloc(4);
    let bytesRead=0;
    try{({bytesRead}=await handle.read(header,0,4,0))}finally{await handle.close();}
    if(bytesRead<4||header[0]!==0x50||header[1]!==0x4b)throw Object.assign(new Error('The selected file is not a valid JAR/ZIP archive.'),{status:400});
    const targetPath=path.join(context.pluginsDir,replaceFile);
    await safePath(context.id,'plugins/'+replaceFile);
    const current=await fs.promises.lstat(targetPath).catch(()=>null);
    if(!current||!current.isFile()||current.isSymbolicLink())throw Object.assign(new Error('The installed plugin JAR was not found or is not a regular file.'),{status:404});
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    backupPath=targetPath+'.previous-'+stamp+'-'+crypto.randomUUID();
    await fs.promises.rename(targetPath,backupPath);
    previousMoved=true;
    try{
      await fs.promises.copyFile(req.file.path,targetPath,fs.constants.COPYFILE_EXCL);
      previousMoved=false;
    }catch(error){
      await fs.promises.rm(targetPath,{force:true}).catch(()=>{});
      throw error;
    }
    notify('file_change','Updated custom plugin '+replaceFile+'; previous JAR saved as '+path.basename(backupPath),context.id,req.panelSession.username);
    res.json({ok:true,file:replaceFile,backupFile:path.basename(backupPath),restartRequired:true,dataPreserved:true});
  }catch(error){
    if(previousMoved&&backupPath){
      await fs.promises.rm(path.join(context.pluginsDir,String(req.body?.replaceFile||'')),{force:true}).catch(()=>{});
      try{await fs.promises.rename(backupPath,path.join(context.pluginsDir,String(req.body?.replaceFile||'')));previousMoved=false}
      catch(restoreError){error.message+=' The previous JAR remains at '+backupPath+'; automatic restoration failed: '+restoreError.message}
    }
    const denied=error.code==='EACCES'||error.code==='EPERM',noSpace=error.code==='ENOSPC';
    const message=denied?'The panel cannot update this plugin in the server folder. Grant write access to the user running the panel, then retry. ('+error.code+')':noSpace?'The selected server drive is out of free space. The previous plugin JAR was kept.':error.message||'Plugin update failed.';
    res.status(denied?403:(error.status||400)).json({error:message});
  }finally{await fs.promises.rm(context.stagingDir,{recursive:true,force:true}).catch(()=>{});}
});
app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(400).json({error:err.code==='LIMIT_FILE_COUNT'?'Too many files (100 maximum).':`Upload failed: ${err.message}`});if(err)return res.status(err.status||500).json({error:err.message||'Internal server error.'});next();});

app.post('/api/plugins/:id/check-update',requireAdmin,async(req,res)=>{const id=safeId(req.params.id),file=path.basename(String(req.body?.file||''));if(!id||!/^.+\.jar$/i.test(file))return res.status(400).json({error:'Choose a valid plugin JAR.'});try{const p=await safePath(id,`plugins/${file}`),meta=await jarPluginMeta(p.target);if(!meta?.name||!meta?.version)return res.status(400).json({error:'Could not read name and version from plugin.yml.'});const q=new URL('https://api.modrinth.com/v2/search');q.searchParams.set('query',meta.name);q.searchParams.set('limit','10');q.searchParams.set('facets',JSON.stringify([['project_type:plugin']]));const search=await fetch(q,{headers:{'user-agent':'HellenicPanel/3.7 (plugin update lookup)'},signal:AbortSignal.timeout(15000)});if(!search.ok)throw Error(`Modrinth search failed (${search.status}).`);const hits=(await search.json()).hits||[],project=hits.find(x=>String(x.title||'').trim().toLowerCase()===meta.name.trim().toLowerCase());if(!project)return res.json({found:false,currentVersion:meta.version,suggestions:hits.slice(0,5).map(x=>({title:x.title,slug:x.slug,url:`https://modrinth.com/plugin/${x.slug}`}))});const vr=await fetch(`https://api.modrinth.com/v2/project/${encodeURIComponent(project.project_id)}/version`,{headers:{'user-agent':'HellenicPanel/3.7 (plugin update lookup)'},signal:AbortSignal.timeout(15000)});if(!vr.ok)throw Error(`Modrinth versions request failed (${vr.status}).`);const versions=await vr.json(),latest=versions.find(x=>x.version_type==='release')||versions[0];if(!latest)return res.status(404).json({error:'No published versions found.'});const primary=latest.files?.find(x=>x.primary)||latest.files?.[0];res.json({found:true,project:project.title,projectUrl:`https://modrinth.com/plugin/${project.slug}`,currentVersion:meta.version,latestVersion:latest.version_number,updateAvailable:latest.version_number!==meta.version,url:primary?.url||null,file:primary?.filename||null})}catch(e){res.status(400).json({error:e.message||'Update lookup failed.'})}});
app.get('/api/servers/:id/metrics',requireAuth,(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});res.json({points:(state.metrics[id]||[]).slice(-1440),current:telemetryFor(id)})});
app.get('/api/players/:id/activity',requirePermission('players_view'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});res.json({events:state.playerActivity.filter(x=>x.server===id).slice(0,200)})});
app.get('/api/backup-settings',requireAdmin,(req,res)=>res.json({settings:state.backupConfig}));
app.get('/api/backup-restore-status',requirePermission('backups'),(req,res)=>res.json({last:state.audit.find(x=>x.action==='backup_restored')||null}));
app.put('/api/backup-settings',requireAdmin,(req,res)=>{const b=req.body||{},old=state.backupConfig||{};state.backupConfig={dailyEnabled:b.dailyEnabled===true,dailyTime:/^\d\d:\d\d$/.test(b.dailyTime||'')?b.dailyTime:old.dailyTime||'04:00',weeklyEnabled:b.weeklyEnabled===true,weeklyTime:/^\d\d:\d\d$/.test(b.weeklyTime||'')?b.weeklyTime:old.weeklyTime||'05:00',keepDaily:Math.max(1,Math.min(60,Number(b.keepDaily??old.keepDaily??7))),keepWeekly:Math.max(1,Math.min(52,Number(b.keepWeekly??old.keepWeekly??4)))};saveState();res.json({ok:true,settings:state.backupConfig})});
app.get('/api/tasks',requireAdmin,(req,res)=>res.json({tasks:state.scheduledTasks}));
app.post('/api/tasks',requireAdmin,(req,res)=>{const {name,server,time,command}=req.body||{};if(typeof name!=='string'||!name.trim()||name.length>64||!safeId(server)||!/^\d\d:\d\d$/.test(time||'')||typeof command!=='string'||!command.trim()||command.length>500||/[\r\n]/.test(command))return res.status(400).json({error:'Enter a name, server, valid time, and one console command.'});const task={id:crypto.randomUUID(),name:name.trim(),server,time,command:command.trim(),enabled:true};state.scheduledTasks.push(task);saveState();res.json({ok:true,task})});
app.delete('/api/tasks/:id',requireAdmin,(req,res)=>{const old=state.scheduledTasks.length;state.scheduledTasks=state.scheduledTasks.filter(x=>x.id!==req.params.id);if(old===state.scheduledTasks.length)return res.status(404).json({error:'Task not found.'});saveState();res.json({ok:true})});
app.post('/api/multi-command',requireAuth,(req,res)=>{if(!req.panelSession.permissions?.console_command)return res.status(403).json({error:'Console command permission required.'});const {servers,command}=req.body||{},u=getUsers().find(x=>x.username===req.panelSession.username),allowed=Array.isArray(u?.servers)?u.servers:null;if(!Array.isArray(servers)||!servers.length||servers.length>20||typeof command!=='string'||!command.trim()||command.length>500||/[\r\n]/.test(command))return res.status(400).json({error:'Select servers and enter one command.'});const results=[];for(const id of [...new Set(servers)]){if(!safeId(id)||!isAdmin(req.panelSession)&&allowed&&!allowed.includes('*')&&!allowed.includes(id)){results.push({server:id,ok:false,error:'Unknown or inaccessible server.'});continue}results.push({server:id,...writeCommand(id,command.trim())})}res.json({results})});
app.post('/api/maintenance/:id',requirePermission('server_settings'),(req,res)=>{const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Unknown server.'});const enabled=req.body?.enabled===true,reason=String(req.body?.message||'Scheduled maintenance').replace(/[\r\n]/g,' ').slice(0,160);state.serverSettings[id]||={};state.serverSettings[id].maintenance=enabled;state.serverSettings[id].maintenanceMessage=reason;saveState();if(processes.has(id)){writeCommand(id,enabled?'whitelist on':'whitelist off');writeCommand(id,`say [${brandName()}] ${enabled?'Maintenance mode enabled: '+reason:'Maintenance mode ended.'}`)}res.json({ok:true,maintenance:enabled,message:reason})});
app.get('/api/server-templates',requireAdmin,(req,res)=>res.json({templates:state.templates.map(t=>({...t,sourceLabel:config.servers[t.source]?.label||t.source}))}));
app.post('/api/server-templates',requireAdmin,(req,res)=>{const {name,source}=req.body||{};if(typeof name!=='string'||!name.trim()||name.trim().length>64||!safeId(source))return res.status(400).json({error:'Provide a template name and source server.'});const template={id:crypto.randomUUID(),name:name.trim(),source};state.templates.push(template);saveState();res.json({ok:true,template})});
app.delete('/api/server-templates/:id',requireAdmin,(req,res)=>{const n=state.templates.length;state.templates=state.templates.filter(t=>t.id!==req.params.id);if(n===state.templates.length)return res.status(404).json({error:'Template not found.'});saveState();res.json({ok:true})});
app.delete('/api/servers/:id',requireAdmin,async(req,res)=>{
  const id=safeId(req.params.id);if(!id)return res.status(404).json({error:'Server not found.'});
  const removedServer=config.servers[id];
  const admin=getUsers().find(u=>u.username===req.panelSession.username),password=String(req.body?.password||'');
  if(!admin?.passwordHash||!password||!(await bcrypt.compare(password,admin.passwordHash)))return res.status(403).json({error:'Admin password is incorrect. Server was not removed.'});
  if(processes.has(id))return res.status(409).json({error:'Stop this server before removing it.'});
  const deleteFiles=req.body?.deleteFiles===true,folder=path.basename(serverRoot(id));if(deleteFiles&&String(req.body?.confirmId||'')!==id)return res.status(400).json({error:`Type ${id} to confirm permanent server file deletion.`});let network=null,realRoot=null,trash=null,moved=false,filesDeleted=deleteFiles&&!fs.existsSync(serverRoot(id));
  try{
    if(deleteFiles&&fs.existsSync(serverRoot(id))){
      network=await fs.promises.realpath(path.resolve(ROOT,config.networkRoot));
      if(fs.lstatSync(serverRoot(id)).isSymbolicLink())return res.status(400).json({error:'Refusing to delete a symbolic-link server folder.'});
      realRoot=await fs.promises.realpath(serverRoot(id));
      if(realRoot===network||!inside(network,realRoot))return res.status(400).json({error:'Server folder is outside MinecraftNetwork; refusing to delete files.'});
      trash=path.join(path.dirname(realRoot),`.blockpanel-delete-${id}-${crypto.randomUUID()}`);
      await fs.promises.rename(realRoot,trash);moved=true;
    }
    delete config.servers[id];
    config.ignoredServerFolders||=[];config.ignoredServerFolders=[...new Set([...config.ignoredServerFolders,folder.toLowerCase()])];
    writeConfig();
    const velocityCleanup=isVelocityServer(id,removedServer)?{updated:[],warnings:[]}:await removeVelocityRouteFromProxies(id);
    state.templates=state.templates.filter(t=>t.source!==id);state.scheduledTasks=state.scheduledTasks.filter(t=>t.server!==id);delete state.metrics[id];delete state.serverSettings[id];delete state.locks[id];state.playerActivity=state.playerActivity.filter(x=>x.server!==id);if(Array.isArray(state.hooks))state.hooks=state.hooks.filter(h=>h.server!==id);
    for(const u of getUsers())if(Array.isArray(u.servers)&&!u.servers.includes('*'))u.servers=u.servers.filter(x=>x!==id);
    saveState();
    if(moved){try{await fs.promises.rm(trash,{recursive:true,force:true});filesDeleted=true}catch{await fs.promises.rename(trash,realRoot).catch(()=>{});moved=false}}
    processes.delete(id);history.delete(id);telemetry.delete(id);statusCache.delete(id);crashState.delete(id);healthFlags.delete(id);lastTpsPoll.delete(id);
    res.json({ok:true,serverId:id,filesDeleted,folderKept:!filesDeleted,removedTemplates:true,velocityTomlsUpdated:velocityCleanup.updated,velocityTomlWarnings:velocityCleanup.warnings});
  }catch(e){
    if(moved&&trash&&realRoot)await fs.promises.rename(trash,realRoot).catch(()=>{});
    res.status(500).json({error:`Could not remove server: ${e.message}`});
  }
});
app.get('/api/email-settings',requireAdmin,(req,res)=>res.json({settings:safeEmailConfig(),actions:HOOK_ACTIONS}));
app.put('/api/email-settings',requireAdmin,(req,res)=>{const b=req.body||{},old=state.emailConfig||{},validUrl=(s)=>{if(!s)return true;try{return ['http:','https:'].includes(new URL(s).protocol)}catch{return false}},port=Number(b.port);if(typeof b.host!=='string'||b.host.length>255||typeof b.username!=='string'||b.username.length>255||typeof b.from!=='string'||b.from.length>320||typeof b.to!=='string'||b.to.length>320||!Number.isInteger(port)||port<1||port>65535||!validUrl(b.localUrl)||!validUrl(b.tailscaleUrl)||!Array.isArray(b.events)||b.events.some(x=>!HOOK_ACTIONS.includes(x)))return res.status(400).json({error:'Check the SMTP, link, port, and selected event values.'});const pass=typeof b.password==='string'&&b.password?encrypt(b.password.slice(0,2048)):b.clearPassword? '':(old.password||'');state.emailConfig={enabled:b.enabled===true,host:b.host.trim(),port,secure:b.secure===true,username:b.username.trim(),password:pass,from:b.from.trim(),to:b.to.trim(),events:[...new Set(b.events)],localUrl:String(b.localUrl||'').trim().replace(/\/$/,''),tailscaleUrl:String(b.tailscaleUrl||'').trim().replace(/\/$/,'')};saveState();audit(req,'email_settings_updated',{message:'SMTP alert settings updated'});res.json({ok:true,settings:safeEmailConfig()})});
app.post('/api/email-settings/test',requireAdmin,async(req,res)=>{try{const transport=emailTransport();await transport.verify();await transport.sendMail({from:state.emailConfig.from,to:state.emailConfig.to,subject:brandName()+' test email',text:`${brandName()} email delivery is working.\nLocal panel: ${panelLink(state.emailConfig.localUrl)}\nTailscale panel: ${panelLink(state.emailConfig.tailscaleUrl)}`});audit(req,'email_test_sent',{message:`Test message sent to ${state.emailConfig.to}`});res.json({ok:true})}catch(e){res.status(400).json({error:`Email test failed: ${e.message}`})}});
function assertSafeClonePath(root,target){if(!inside(root,target))throw Error('Destination leaves the network folder.');let current=root;for(const part of path.relative(root,target).split(path.sep).filter(Boolean)){current=path.join(current,part);try{const st=fs.lstatSync(current);if(st.isSymbolicLink())throw Error('Destination contains a symbolic link.');if(current!==target&&!st.isDirectory())throw Error('A destination path component is not a folder.')}catch(e){if(e.code==='ENOENT')break;throw e}}}
app.post('/api/server-templates/:id/instantiate',requireAdmin,async(req,res)=>{
  const template=state.templates.find(x=>x.id===req.params.id),{serverId,label,folder,port,ramGB}=req.body||{};
  if(!template||!safeId(template.source))return res.status(404).json({error:'Template not found.'});
  if(!/^[A-Za-z0-9_-]{2,24}$/.test(serverId||'')||serverIdExists(serverId))return res.status(400).json({error:'Choose a unique server ID (2–24 letters, numbers, _ or -).'});
  const sourceConfig=config.servers[template.source],src=serverRoot(template.source),serverType=String(req.body.serverType||'auto'),portNum=Number(port),host=String(req.body.host||sourceConfig.host||'127.0.0.1').trim(),command=String(req.body.command||sourceConfig.command||'java').trim();
  if(!Number.isInteger(portNum)||portNum<1||portNum>65535||Object.values(config.servers).some(s=>Number(s.port)===portNum))return res.status(400).json({error:'Choose a new server port.'});
  if(!/^[A-Za-z0-9:._-]{1,253}$/.test(host)||!command||command.length>512||/[\r\n]/.test(command))return res.status(400).json({error:'Enter a valid host and Java executable path.'});
  if(!['auto','backend','velocity'].includes(serverType))return res.status(400).json({error:'Choose Auto detect, Backend server, or Velocity proxy.'});
  if(processes.has(template.source))return res.status(409).json({error:'The template source server is running. Stop it first, then create the copy.'});
  if(serverCreationInProgress)return res.status(409).json({error:'Another server is being created. Wait for it to finish, then try again.'});
  let network,dest,temp,created=false,committed=false,configWriteAttempted=false,velocitySecretCreated=false;const ignoredBefore=[...(config.ignoredServerFolders||[])];let ignoredFolder='';
  serverCreationInProgress=true;
  try{
    network=await fs.promises.realpath(path.resolve(ROOT,config.networkRoot));
    const clean=normalizeRel(folder||serverId);dest=path.resolve(network,clean);
    ignoredFolder=path.basename(clean).toLowerCase();
    assertSafeClonePath(network,dest);
    if(dest===network||fs.existsSync(dest))return res.status(409).json({error:'That destination folder already exists. Choose another folder name.'});
    temp=path.join(path.dirname(dest),`.blockpanel-create-${crypto.randomUUID()}`);assertSafeClonePath(network,temp);
    const realSource=await fs.promises.realpath(src);
    if(!inside(network,realSource))throw Error('The template source must be inside MinecraftNetwork.');
    const sourceFiles=await fs.promises.readdir(realSource,{withFileTypes:true});
    if(!sourceFiles.some(x=>x.isFile()&&/\.jar$/i.test(x.name)))return res.status(400).json({error:'The template source folder has no server JAR to copy.'});
    const sourceIdentity=[template.source,sourceConfig.type||'',sourceConfig.label||'',sourceConfig.command||'',...(sourceConfig.args||[])].join(' ');
    const sourceHasVelocityToml=sourceFiles.some(x=>x.isFile()&&x.name.toLowerCase()==='velocity.toml'),sourceHasVelocityJar=sourceFiles.some(x=>x.isFile()&&/^velocity.*\.jar$/i.test(x.name)),detectedVelocity=sourceHasVelocityToml||sourceHasVelocityJar||/velocity/i.test(sourceIdentity),isVelocity=serverType==='velocity'||(serverType==='auto'&&detectedVelocity);
    if(!isVelocity&&!sourceFiles.some(x=>x.isFile()&&x.name==='server.properties'))return res.status(400).json({error:'The template source needs server.properties. Choose Velocity proxy for a Velocity source.'});
    const srcProps=isVelocity?'':await fs.promises.readFile(path.join(realSource,'server.properties'),'utf8');
    const worldName=srcProps.match(/^\s*level-name\s*=\s*(.+)\s*$/m)?.[1]?.trim()||'world';
    const excluded=new Set(['logs','crash-reports','cache','usercache.json','ops.json','whitelist.json','banned-ips.json','banned-players.json','world','world_nether','world_the_end',worldName,`${worldName}_nether`,`${worldName}_the_end`]);
    await fs.promises.mkdir(path.dirname(dest),{recursive:true});await fs.promises.mkdir(temp);created=true;
    await fs.promises.cp(realSource,temp,{recursive:true,dereference:false,filter:from=>{try{if(fs.lstatSync(from).isSymbolicLink())return false}catch{}return !excluded.has(path.basename(from))}});
    if(isVelocity){
      const velocityPath=path.join(temp,'velocity.toml');let toml;
      try{toml=await fs.promises.readFile(velocityPath,'utf8')}catch(e){if(e.code!=='ENOENT')throw e;toml=await fs.promises.readFile(path.join(ROOT,'templates','velocity.toml'),'utf8')}
      const backends=Object.entries(config.servers).filter(([id,s])=>id!==template.source&&!/velocity|bungee|waterfall/i.test((s.type||'')+' '+id+' '+(s.label||'')+' '+(s.command||'')+' '+(s.args||[]).join(' '))).map(([id,s])=>({id,host:s.host||'127.0.0.1',port:Number(s.port)}));
      await fs.promises.writeFile(velocityPath,configureVelocityToml(toml,portNum,backends),'utf8');
      const secretPath=path.join(temp,'forwarding.secret');if(!fs.existsSync(secretPath)){await fs.promises.writeFile(secretPath,crypto.randomBytes(32).toString('hex')+'\n',{mode:0o600,flag:'wx'});velocitySecretCreated=true}await fs.promises.chmod(secretPath,0o600).catch(()=>{});
    }else{
      const properties=path.join(temp,'server.properties');let text=await fs.promises.readFile(properties,'utf8');
      if(/^\s*server-port\s*=/m.test(text))text=text.replace(/^\s*server-port\s*=.*$/m,'server-port='+portNum);else text+='\nserver-port='+portNum+'\n';
      if(/^\s*query\.port\s*=/m.test(text))text=text.replace(/^\s*query\.port\s*=.*$/m,'query.port='+portNum);
      await fs.promises.writeFile(properties,text);
    }
    await fs.promises.rename(temp,dest);temp=null;
    state.metrics[serverId]=[];saveState();
    config.servers[serverId]={...sourceConfig,type:isVelocity?'velocity':'backend',label:String(label||serverId).trim().slice(0,64)||serverId,host,port:portNum,command,cwd:path.relative(ROOT,dest),args:buildStartArgs({...sourceConfig,command},ramGB,false)};
    config.ignoredServerFolders=(config.ignoredServerFolders||[]).filter(x=>String(x).toLowerCase()!==ignoredFolder);
    configWriteAttempted=true;writeConfig();committed=true;
    res.json({ok:true,serverId,directory:clean,port:portNum,velocity:isVelocity?{secretCreated:velocitySecretCreated}:null});
  }catch(e){
    if(!committed){delete config.servers[serverId];delete state.metrics[serverId];if(configWriteAttempted){config.ignoredServerFolders||=[];if(ignoredBefore.some(x=>String(x).toLowerCase()===ignoredFolder)&&!config.ignoredServerFolders.some(x=>String(x).toLowerCase()===ignoredFolder))config.ignoredServerFolders.push(ignoredFolder);try{writeConfig()}catch{}}try{saveState()}catch{}const cleanup=temp||dest;if(created&&network&&cleanup&&inside(network,cleanup))await fs.promises.rm(cleanup,{recursive:true,force:true}).catch(()=>{});}
    res.status(500).json({error:`Could not create server: ${e.message}`});
  }finally{serverCreationInProgress=false}
});
server.on('upgrade',(req,socket,head)=>{if(req.url!=='/ws')return socket.destroy();const s=sessionFromReq(req);if(!s)return socket.destroy();wss.handleUpgrade(req,socket,head,ws=>{ws.panelSession=s;wss.emit('connection',ws,req)})});
wss.on('connection',ws=>{ws.serverId=null;ws.send(JSON.stringify({type:'hello',servers:Object.keys(config.servers)}));ws.on('message',raw=>{try{const m=JSON.parse(raw),u=getUsers().find(x=>x.username===ws.panelSession.username),allowed=Array.isArray(u?.servers)?u.servers:null;if(m.type==='subscribe'&&safeId(m.server)&&ws.panelSession.permissions?.console&&(isAdmin(ws.panelSession)||!allowed||allowed.includes('*')||allowed.includes(m.server))){ws.serverId=m.server;ws.send(JSON.stringify({type:'history',server:m.server,logs:history.get(m.server)||[]}));}}catch{}})});

setInterval(discoverServers,15000);
// Lightweight monitoring loop: status every 5s, process metrics every 2s, TPS/MSPT polling every 5s.
setInterval(async()=>{for(const [id,s] of Object.entries(config.servers)){const st=await mcStatus(s.host,s.port,900);statusCache.set(id,st);const t=telemetryFor(id);recordTelemetry(id,{players:st.online?st.players:0});if(processes.get(id)){processMetrics(id);const now=Date.now();if(now-(lastTpsPoll.get(id)||0)>5000){lastTpsPoll.set(id,now);writeCommand(id,'tps',false);writeCommand(id,'mspt',false);writeCommand(id,'list',false);}}broadcast(id,{type:'status',status:st});}},5000);
setInterval(()=>{for(const id of processes.keys())processMetrics(id)},2000);
setInterval(async()=>{const now=new Date();const minuteKey=`${now.getFullYear()}-${now.getMonth()}-${now.getDate()}-${now.getHours()}-${now.getMinutes()}`;const hh=String(now.getHours()).padStart(2,'0'),mm=String(now.getMinutes()).padStart(2,'0');for(const [id,s] of Object.entries(state.serverSettings)){if(!config.servers[id]||!s.scheduleEnabled||s.scheduleTime!==`${hh}:${mm}`)continue;if(scheduledRuns.get(id)===minuteKey)continue;scheduledRuns.set(id,minuteKey);await restartProcess(id,'scheduled').catch(e=>addHistory(id,`Scheduled restart failed: ${e.message}`,'stderr'));}},1000);
setInterval(()=>{for(const id of processes.keys()){const arr=history.get(id)||[];for(let i=arr.length-1;i>=Math.max(0,arr.length-20);i--){const t=parseTpsFromText(arr[i].line),m=parseMspt(arr[i].line);if(t!=null){telemetryFor(id).lastTpsSecond=t;recordTelemetry(id,{tps:t});break;}if(m!=null){recordTelemetry(id,{mspt:m});break;}}}},2000);
setInterval(()=>evaluateHealth().catch(()=>{}),10000);
const backupRuns=new Map(),taskRuns=new Map();
setInterval(async()=>{const now=new Date(),date=now.toLocaleDateString('en-CA'),hhmm=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`,cfg=state.backupConfig||{};for(const kind of ['daily','weekly']){const enabled=kind==='daily'?cfg.dailyEnabled:cfg.weeklyEnabled,time=kind==='daily'?cfg.dailyTime:cfg.weeklyTime;if(!enabled||time!==hhmm||(kind==='weekly'&&now.getDay()!==0))continue;const key=`${kind}:${date}`;if(backupRuns.has(key))continue;backupRuns.set(key,true);try{await backupNow(kind)}catch(e){notify('backup_failed',`${kind} backup failed: ${e.message}`)}}for(const t of state.scheduledTasks){if(!t.enabled||t.time!==hhmm||!config.servers[t.server])continue;const key=`${t.id}:${date}`;if(taskRuns.has(key))continue;taskRuns.set(key,true);const r=writeCommand(t.server,t.command);if(r.ok){notify('scheduled_task',`Scheduled task ran: ${t.name}`,t.server);sendHook('scheduled_task',{message:`${t.name}: ${t.command}`},t.server).catch(()=>{})}else addHistory(t.server,`Scheduled task ${t.name} failed: ${r.error}`,'stderr')}},5000);

const host=config.panel.host||'0.0.0.0',port=Number(config.panel.port||3000);server.on('error',e=>{console.error(`The panel could not listen on ${host}:${port}: ${e.code||e.message}${e.code==='EADDRINUSE'?' — another process is already using this port. Stop that panel or change panel.port in config.json.':''}`);if(e.code==='EADDRINUSE'||e.code==='EACCES'){process.exitCode=1;process.nextTick(()=>process.exit(1));}});server.listen(port,host,()=>console.log(`${brandName()} running on ${host}:${port}`));
process.on('SIGINT',async()=>{for(const [id,c] of processes){c._panelStopping=true;try{await stopProcess(id,3000)}catch{}}process.exit(0)});
require('./operations-api')({brandName,app,state,config,history,processes,statusCache,telemetry,fs,path,os,net,execFile,requirePermission,requireAdmin,isAdmin,getUsers,safeId,serverRoot,safePath,inside,networkRoot,backupRoot,isBackupPath,writeCommand,notify,audit,saveState,HOOK_ACTIONS,getStartupChecks:()=>startupChecks,setStartupChecks:f=>startupChecks=f,getRecordTelemetry:()=>recordTelemetry,setRecordTelemetry:f=>recordTelemetry=f,getBackupNow:()=>backupNow,setBackupNow:f=>backupNow=f,getRestartProcess:()=>restartProcess,setRestartProcess:f=>restartProcess=f});
platform.installLate();
