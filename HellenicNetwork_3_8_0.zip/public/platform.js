/* Platform UI: branding, create-server, software, extensions, plugin manager, system check.
   Follows the add-on pattern used by operations.js (wraps window.navigate / render functions). */
(function () {
  'use strict';
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const $1 = (s, r = document) => r.querySelector(s);
  const content = () => $1('#content');
  const isAdminUser = () => state.role === 'admin';
  const pageTitle = (a, b) => { const h = $1('#title'), s = $1('#subtitle'); if (h) h.textContent = a; if (s) s.textContent = b || ''; document.title = (window.__brand?.name ? a + ' · ' + window.__brand.name : a); };
  const loadingHtml = (msg = 'Loading…') => `<div class="card panel loading" role="status"><span class="spinner" aria-hidden="true"></span> ${esc(msg)}</div>`;
  const errorHtml = (msg, retry) => `<div class="card panel error-box" role="alert"><b>That didn’t work.</b><p>${esc(msg)}</p>${retry ? `<button class="btn" data-retry>Try again</button>` : ''}</div>`;
  const adminOnlyHtml = '<div class="card panel">This page is for administrators.</div>';
  const badge = (text, kind = '') => `<span class="chip ${kind}">${esc(text)}</span>`;
  const statusIcon = { ok: '✔', warn: '▲', fail: '✖', info: 'ℹ', pending: '○', running: '◔', done: '✔', failed: '✖', skipped: '–' };

  // ---------- toast + dialog ----------
  function toast(message, kind = 'info') {
    let box = $1('#bpToasts');
    if (!box) { box = document.createElement('div'); box.id = 'bpToasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
    const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = message; box.appendChild(t);
    setTimeout(() => t.remove(), kind === 'error' ? 9000 : 5000);
  }
  function dialog({ title, body, actions = [{ label: 'OK', value: true, cls: 'blue' }], cancel = true }) {
    return new Promise(resolve => {
      const d = document.createElement('dialog'); d.className = 'bp-dialog card';
      d.innerHTML = `<form method="dialog"><h2>${esc(title)}</h2><div class="dlg-body">${body}</div><div class="dlg-actions">${cancel ? '<button class="btn" value="__cancel" formnovalidate>Cancel</button>' : ''}${actions.map((a, i) => `<button class="btn ${a.cls || ''}" value="${i}">${esc(a.label)}</button>`).join('')}</div></form>`;
      d.addEventListener('close', () => { const v = d.returnValue; const out = v === '__cancel' || v === '' ? null : { action: actions[Number(v)]?.value, root: d }; resolve(out); setTimeout(() => d.remove(), 0); });
      document.body.appendChild(d); d.showModal();
    });
  }
  const confirmDialog = async (title, bodyHtml, label = 'Continue', cls = 'blue') => !!(await dialog({ title, body: bodyHtml, actions: [{ label, value: true, cls }] }));
  async function run(btn, fn) {
    const old = btn?.textContent; if (btn) { btn.disabled = true; btn.setAttribute('aria-busy', 'true'); }
    try { return await fn(); } catch (e) { toast(e.message || 'Something went wrong.', 'error'); return undefined; }
    finally { if (btn) { btn.disabled = false; btn.removeAttribute('aria-busy'); if (old !== undefined) btn.textContent = old; } }
  }
  async function apiX(url, opts) { // like api() but keeps the server's details list
    const h = { ...(opts?.headers || {}) }; if (opts?.body && !(opts.body instanceof FormData)) h['Content-Type'] = 'application/json';
    const r = await fetch(url, { ...opts, headers: h }); let d = {}; try { d = await r.json(); } catch { /* not json */ }
    if (!r.ok) throw Object.assign(new Error(d.error || `Request failed (${r.status})`), { status: r.status, details: d.details, data: d });
    return d;
  }
  const bytes = n => typeof fmtBytes === 'function' ? fmtBytes(n) : n + ' B';

  // ---------- branding application ----------
  const NAV_KEY = { overview: 'overview', players: 'players', backups: 'backups', notifications: 'notifications', tools: 'tools', resources: 'resources', opslogs: 'opslogs', playerhistory: 'playerhistory', storage: 'storage', templates: 'templates', users: 'users', hooks: 'hooks', audit: 'audit', settings: 'settings', profile: 'profile', create: 'create', extensions: 'extensions', branding: 'branding', health: 'health', software: 'software' };
  function setNavText(btn, text) {
    if (!btn.dataset.glyph) { const m = /^\s*(\S+)\s+\S/.exec(btn.textContent); btn.dataset.glyph = m && !/[A-Za-z0-9]/.test(m[1]) ? m[1] : ''; }
    const node = [...btn.childNodes].find(n => n.nodeType === 3 && n.textContent.trim());
    const full = (btn.dataset.glyph ? btn.dataset.glyph + ' ' : '') + text + ' ';
    if (node) node.textContent = full; else btn.prepend(document.createTextNode(full));
  }
  function applyBranding(b) {
    window.__brand = b; if (!b) return;
    const tk = k => k.startsWith('group_') ? 'group.' + k.slice(6) : k === 'loginSubtitle' ? 'login.subtitle' : 'nav.' + k;
    const L = k => b.labels?.[k] || window.__i18n?.messages?.[tk(k)] || b.defaultLabels?.[k];
    document.title = b.name;
    $$('[data-brand-name]').forEach(el => {
      // Edit only our own text node and logo so buttons other scripts add inside .brand (menu toggles) survive.
      let t = [...el.childNodes].find(n => n.nodeType === 3 && n.textContent.trim());
      if (t) t.textContent = b.name; else el.appendChild(document.createTextNode(b.name));
      el.querySelector(':scope > .brand-logo')?.remove();
      if (b.logoUrl) { const img = document.createElement('img'); img.className = 'brand-logo'; img.alt = ''; img.src = b.logoUrl; el.prepend(img); }
    });
    $$('[data-brand-tagline]').forEach(el => { el.textContent = L('loginSubtitle'); });
    $$('.nav[data-page]').forEach(btn => { const k = NAV_KEY[btn.dataset.page]; if (k && L(k)) setNavText(btn, L(k)); });
    const lo = $1('#logout'); if (lo && L('logout')) setNavText(lo, L('logout'));
    $$('.side-group[data-group]').forEach(g => { const s = g.querySelector('summary'); if (s) s.textContent = L('group_' + g.dataset.group) || s.textContent; });
    const link = l => `<a href="${esc(l.url)}" target="_blank" rel="noopener noreferrer">${esc(l.label)}</a>`;
    const links = b.links || [];
    const foot = $1('#appFooter'); if (foot) foot.innerHTML = (b.footer ? `<span>${esc(b.footer)}</span>` : '') + links.filter(l => l.placement === 'footer').map(link).join('');
    const login = $1('#loginLinks'); if (login) login.innerHTML = links.filter(l => l.placement === 'login').map(link).join('');
    let side = $1('#sideLinks'); const sb = $1('.side-bottom');
    if (sb) { if (!side) { side = document.createElement('div'); side.id = 'sideLinks'; side.className = 'side-links'; sb.prepend(side); } side.innerHTML = links.filter(l => l.placement === 'sidebar').map(link).join(''); }
    const theme = $1('meta[name="theme-color"]'); if (theme && b.colors?.background) theme.content = b.colors.background;
    const css = $1('link[href^="/branding.css"]'); if (css) css.href = '/branding.css?v=' + b.version;
  }
  async function loadBranding() { try { const b = await (await fetch('/api/branding', { cache: 'no-store' })).json(); applyBranding(b); return b; } catch { return null; } }

  // ---------- navigation ----------
  const NAV = [['create', '✚ Create server', 'servers', false], ['software', '▣ Server software', 'management', true], ['extensions', '⧉ Extensions', 'management', true], ['branding', '✎ Branding', 'management', true], ['health', '✓ System check', 'management', true]];
  function installNav() {
    for (const [page, label, group, _] of NAV) {
      if ($1(`.nav[data-page="${page}"]`)) continue;
      const g = $1(`.side-group[data-group="${group}"]`); if (!g) continue;
      const b = document.createElement('button'); b.className = 'nav'; b.type = 'button'; b.dataset.page = page; b.dataset.adminOnly = '1'; b.textContent = label;
      b.onclick = () => { $1('.sidebar')?.classList.remove('mobile-open'); window.navigate(page); };
      if (page === 'create') { const ov = g.querySelector('[data-page="overview"]'); ov ? ov.after(b) : g.appendChild(b); } else g.appendChild(b);
    }
    $$('.nav[data-admin-only]').forEach(b => b.classList.toggle('hidden', !isAdminUser()));
    $$('.nav').forEach(b => b.setAttribute('aria-current', b.classList.contains('active') ? 'page' : 'false'));
    if (window.__brand) applyBranding(window.__brand);
  }
  const pages = {};
  const baseNavigate = window.navigate;
  window.navigate = async function (p) {
    if (pages[p]) {
      if (typeof editorDirty !== 'undefined' && editorDirty && !confirm('Discard unsaved changes?')) return;
      state.page = p; state.current = null;
      $$('.nav').forEach(x => x.classList.toggle('active', x.dataset.page === p));
      $1('.sidebar')?.classList.remove('mobile-open');
      content().innerHTML = loadingHtml();
      try { await pages[p](); } catch (e) { content().innerHTML = errorHtml(e.message, true); $1('[data-retry]', content())?.addEventListener('click', () => window.navigate(p)); }
      installNav(); content().focus({ preventScroll: true }); return;
    }
    const r = await baseNavigate(p); installNav(); return r;
  };
  const baseSetupNav = window.setupNav;
  if (typeof baseSetupNav === 'function') window.setupNav = function () { const r = baseSetupNav.apply(this, arguments); installNav(); return r; };

  // ---------- accessibility improvements to existing markup ----------
  function a11yPass() {
    $1('#loginError')?.setAttribute('role', 'alert');
    const dock = $1('.mobile-dock'); if (dock) dock.setAttribute('aria-label', 'Quick navigation');
    $$('table').forEach(t => { if (!t.parentElement.classList.contains('table-scroll')) { const w = document.createElement('div'); w.className = 'table-scroll'; w.tabIndex = 0; w.setAttribute('role', 'region'); w.setAttribute('aria-label', 'Table'); t.replaceWith(w); w.appendChild(t); } });
  }
  new MutationObserver(() => { clearTimeout(a11yPass.t); a11yPass.t = setTimeout(a11yPass, 150); }).observe(document.body, { childList: true, subtree: true });

  // expose for the second half of the file
  window.__bp = { pages, toast, dialog, confirmDialog, run, apiX, badge, esc: (...a) => esc(...a), loadingHtml, errorHtml, adminOnlyHtml, pageTitle, statusIcon, bytes, installNav, applyBranding, loadBranding, isAdminUser, $$, $1, content };
  loadBranding().then(() => installNav());
})();
