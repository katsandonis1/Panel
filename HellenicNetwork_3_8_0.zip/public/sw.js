// Network-first for the app shell so updates and branding changes reach people immediately; the cache is only an offline fallback.
const CACHE_NAME='blockpanel-shell-3.8.0';
const SHELL=['/','/style.css','/updates.css','/ops.css','/platform.css','/app.js','/features.js','/operations.js','/platform.js','/platform-pages.js','/platform-manage.js','/platform-props.js','/platform-ext.js','/branding.css','/manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE_NAME).then(cache=>Promise.all(SHELL.map(u=>cache.add(u).catch(()=>{})))).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('blockpanel-shell-')&&key!==CACHE_NAME).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const req=event.request,url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==location.origin||url.pathname.startsWith('/api/')||url.pathname==='/ws')return;
  event.respondWith(fetch(req).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(req,copy))}return response}).catch(()=>caches.match(req).then(hit=>hit||(req.mode==='navigate'?caches.match('/'):Response.error()))));
});
