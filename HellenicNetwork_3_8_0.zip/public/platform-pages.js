/* Platform pages (part 2): create server, server software, system check. Loaded after platform.js. */
(function () {
  'use strict';
  const { pages, toast, dialog, confirmDialog, run, apiX, badge, loadingHtml, errorHtml, adminOnlyHtml, pageTitle, statusIcon, bytes, $$, $1, content, isAdminUser } = window.__bp;
  const E = s => esc(s);
  const TRUST = { official: ['Official source', 'ok'], 'compiled-locally': ['Built on this machine', 'info'], unverified: ['Unverified', 'warn'], extension: ['From extension', 'info'] };
  const trustChip = t => { const [l, k] = TRUST[t] || [t, '']; return badge(l, k); };
  const field = (id, label, input, hint = '') => `<div class="fld"><label for="${id}">${E(label)}</label>${input}${hint ? `<small class="muted" id="${id}-hint">${hint}</small>` : ''}</div>`;

  // =============== Create server ===============
  pages.create = async function () {
    pageTitle('Create server', 'Pick software and a version. The panel downloads, verifies and configures it for you.');
    if (!isAdminUser()) return (content().innerHTML = adminOnlyHtml);
    const [cat, defs] = await Promise.all([apiX('/api/catalog'), apiX('/api/create-server/defaults')]);
    const sw = cat.software, groups = [['Servers', sw.filter(s => s.kind === 'server')], ['Proxies', sw.filter(s => s.kind === 'proxy')]];
    content().innerHTML = `<div class="cs-layout"><form id="csForm" class="card panel" novalidate aria-describedby="cs-intro">
      <p id="cs-intro" class="muted">No template needed. Versions and builds come directly from each project’s official download service; nothing is guessed.</p>
      <div class="fld-grid">
        ${field('cs-software', 'Server software', `<select id="cs-software" required>${groups.map(([n, l]) => l.length ? `<optgroup label="${n}">${l.map(s => `<option value="${E(s.id)}">${E(s.name)}${s.origin !== 'builtin' ? ' (custom)' : ''}</option>`).join('')}</optgroup>` : '').join('')}</select>`, '<span id="cs-sw-desc"></span>')}
        ${field('cs-version', 'Version', '<select id="cs-version" required><option>Loading…</option></select>', '<span id="cs-ver-hint"></span>')}
        <div class="fld" id="cs-build-wrap" hidden><label for="cs-build">Build</label><select id="cs-build"><option value="latest">Latest stable</option></select></div>
        ${field('cs-id', 'Server ID', '<input id="cs-id" required maxlength="24" pattern="[A-Za-z0-9_-]{2,24}" autocomplete="off" spellcheck="false">', '2–24 letters, numbers, _ or -. Used internally and as the folder name.')}
        ${field('cs-label', 'Display name', '<input id="cs-label" maxlength="64" autocomplete="off">')}
        ${field('cs-port', 'Port', `<input id="cs-port" type="number" min="1024" max="65535" value="${E(defs.port || 25565)}" required>`, 'Next free port suggested.')}
        ${field('cs-ram', 'Memory (GB)', `<input id="cs-ram" type="number" min="1" max="32" step="1" value="${E(defs.ramGB || 2)}" required>`, 'Suggested from this machine’s memory.')}
      </div>
      <div id="cs-vars"></div>
      <details class="adv"><summary>Advanced</summary><div class="fld-grid">
        ${field('cs-folder', 'Folder name', '<input id="cs-folder" maxlength="64" placeholder="same as Server ID">', 'Created inside the Minecraft network folder.')}
        ${field('cs-host', 'Host', '<input id="cs-host" value="127.0.0.1">')}
        ${field('cs-java', 'Java command', '<input id="cs-java" value="java" spellcheck="false">', 'Use a full path to select a specific Java version.')}
      </div></details>
      <div id="cs-agree" class="agree"></div>
      <div class="btn-row"><button type="button" class="btn" id="cs-check">Check &amp; preview</button><button type="submit" class="btn blue" id="cs-create" disabled>Create server</button></div>
      <div id="cs-plan" aria-live="polite"></div></form>
      <aside class="card panel" id="cs-job" aria-live="polite" hidden></aside></div>`;
    const el = id => $1('#' + id), vals = () => ({ software: el('cs-software').value, version: el('cs-version').value, build: el('cs-build-wrap').hidden ? 'latest' : el('cs-build').value, serverId: el('cs-id').value.trim(), label: el('cs-label').value.trim() || el('cs-id').value.trim(), port: Number(el('cs-port').value), ramGB: Number(el('cs-ram').value), folder: el('cs-folder').value.trim() || undefined, host: el('cs-host').value.trim(), javaCommand: el('cs-java').value.trim(), acceptEula: !!$1('#cs-eula')?.checked, acknowledgeUnverified: !!$1('#cs-unv')?.checked, vars: Object.fromEntries($$('[data-var]').map(i => [i.dataset.var, i.value])) });
    let current = null, checked = false;
    const invalidate = () => { checked = false; el('cs-create').disabled = true; };
    async function loadVersions() {
      const s = sw.find(x => x.id === el('cs-software').value); current = s;
      el('cs-sw-desc').innerHTML = `${E(s.description || '')} ${trustChip(s.trust)}`;
      el('cs-version').innerHTML = '<option>Loading…</option>'; el('cs-ver-hint').textContent = ''; invalidate();
      el('cs-vars').innerHTML = (s.variables || []).length ? `<h3>Startup variables</h3><div class="fld-grid">${s.variables.map(v => field('var-' + v.env, v.name, `<input id="var-${E(v.env)}" data-var="${E(v.env)}" value="${E(v.default)}" ${v.editable ? '' : 'readonly'}>`, E(v.description))).join('')}</div>` : '';
      try {
        const d = await apiX(`/api/catalog/${encodeURIComponent(s.id)}/versions`);
        if (!d.versions.length) { el('cs-version').innerHTML = '<option value="">No versions available</option>'; el('cs-ver-hint').textContent = s.origin === 'builtin' ? 'The publisher lists no versions right now.' : 'Add a version on the Server software page first.'; return; }
        el('cs-version').innerHTML = d.versions.map(v => `<option value="${E(v.version)}">${E(v.version)}${v.verified === false ? ' (no checksum)' : ''}</option>`).join('');
        if (s.kind === 'server') { if (d.targetAvailable) { el('cs-version').value = d.target; el('cs-ver-hint').textContent = `Recommended: ${d.target}`; } else el('cs-ver-hint').textContent = `${d.target} is not published for ${s.name}; showing the newest available.`; }
        else el('cs-ver-hint').textContent = 'This is the proxy’s own version, not a Minecraft version.';
        await loadBuilds();
      } catch (e) { el('cs-version').innerHTML = '<option value="">Unavailable</option>'; el('cs-ver-hint').textContent = `Could not load versions: ${e.message}`; }
    }
    async function loadBuilds() {
      const s = current, show = ['paper', 'folia', 'purpur', 'velocity'].includes(s.id) && s.origin === 'builtin';
      el('cs-build-wrap').hidden = !show; if (!show) return;
      try { const d = await apiX(`/api/catalog/${encodeURIComponent(s.id)}/builds?version=${encodeURIComponent(el('cs-version').value)}`); el('cs-build').innerHTML = '<option value="latest">Latest stable</option>' + d.builds.map(b => `<option value="${E(b.build)}">#${E(b.build)}${b.channel ? ' · ' + E(String(b.channel).toLowerCase()) : ''}</option>`).join(''); } catch { el('cs-build').innerHTML = '<option value="latest">Latest stable</option>'; }
    }
    el('cs-software').addEventListener('change', loadVersions); el('cs-version').addEventListener('change', () => { invalidate(); loadBuilds(); });
    $$('#csForm input,#csForm select').forEach(i => i.addEventListener('input', invalidate));
    el('cs-id').addEventListener('input', () => { if (!el('cs-label').dataset.touched) el('cs-label').value = el('cs-id').value; }); el('cs-label').addEventListener('input', () => { el('cs-label').dataset.touched = '1'; });
    el('cs-check').onclick = e => run(e.target, async () => {
      const v = vals(); const r = await apiX('/api/create-server/preflight', { method: 'POST', body: JSON.stringify(v) });
      const list = (arr, cls, icon) => arr?.length ? `<ul class="plan-list ${cls}">${arr.map(x => `<li><span aria-hidden="true">${icon}</span> ${E(typeof x === 'string' ? x : `${x.label}: ${x.detail}`)}</li>`).join('')}</ul>` : '';
      const res = r.resolved;
      el('cs-plan').innerHTML = `${r.errors.length ? `<div class="plan err" role="alert"><h3>Fix these first</h3>${list(r.errors, 'bad', statusIcon.fail)}</div>` : ''}
        ${res ? `<div class="plan"><h3>What will be installed</h3><dl class="kvgrid"><dt>Software</dt><dd>${E(res.software)} ${E(res.version)}${res.build ? ` · build #${E(res.build)}` : ''}${res.channel && String(res.channel).toUpperCase() !== 'STABLE' ? ' ' + badge(String(res.channel).toLowerCase(), 'warn') : ''}</dd><dt>Source</dt><dd>${E(res.source)} ${trustChip(res.trust)}</dd><dt>Verification</dt><dd>${E(res.verification)}</dd>${res.javaMajor ? `<dt>Java needed</dt><dd>${E(res.javaMajor)}+</dd>` : ''}</dl></div>` : ''}
        ${r.warnings.length ? `<div class="plan warn"><h3>Heads up</h3>${list(r.warnings, 'warn', statusIcon.warn)}</div>` : ''}
        ${r.checks.length ? `<div class="plan"><h3>Checks</h3>${list(r.checks, 'ok', statusIcon.ok)}</div>` : ''}
        ${r.willDo.length ? `<div class="plan"><h3>When you press Create</h3><ol>${r.willDo.map(x => `<li>${E(x)}</li>`).join('')}</ol><p class="muted">If anything fails, everything created is removed again.</p></div>` : ''}`;
      const agree = [];
      if (r.requires.acceptEula || $1('#cs-eula')) agree.push(`<label class="chk"><input type="checkbox" id="cs-eula" ${$1('#cs-eula')?.checked ? 'checked' : ''}> I accept the <a href="https://aka.ms/MinecraftEULA" target="_blank" rel="noopener noreferrer">Minecraft EULA</a> on behalf of this server.</label>`);
      if (r.requires.acknowledgeUnverified || $1('#cs-unv')) agree.push(`<label class="chk"><input type="checkbox" id="cs-unv" ${$1('#cs-unv')?.checked ? 'checked' : ''}> I trust this download even though it cannot be verified against a publisher checksum.</label>`);
      el('cs-agree').innerHTML = agree.join('');
      $$('#cs-agree input').forEach(i => i.addEventListener('change', () => { el('cs-create').disabled = !(checked && (!$1('#cs-eula') || $1('#cs-eula').checked) && (!$1('#cs-unv') || $1('#cs-unv').checked)); }));
      checked = r.ok; el('cs-create').disabled = !(r.ok && (!$1('#cs-eula') || $1('#cs-eula').checked) && (!$1('#cs-unv') || $1('#cs-unv').checked));
      if (r.suggestions?.port && !el('cs-port').dataset.touched) el('cs-port').value = r.suggestions.port;
      el('cs-plan').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    });
    el('csForm').addEventListener('submit', async e => {
      e.preventDefault(); if (!checked) return;
      await run(el('cs-create'), async () => {
        const r = await apiX('/api/create-server', { method: 'POST', body: JSON.stringify(vals()) });
        el('cs-job').hidden = false; el('cs-create').disabled = true; $$('#csForm input,#csForm select,#cs-check').forEach(i => i.disabled = true);
        await pollJob(r.jobId, el('cs-job'));
      });
    });
    await loadVersions();
  };

  async function pollJob(jobId, box) {
    const render = j => { box.innerHTML = `<h2>${E(j.title)}</h2><ol class="steps">${j.steps.map(s => `<li class="step ${s.status}"><span class="ico" aria-hidden="true">${statusIcon[s.status] || '○'}</span><span><b>${E(s.label)}</b> <span class="sr-only">${E(s.status)}</span><br><small class="muted">${E(s.detail || '')}</small></span></li>`).join('')}</ol>
      ${j.status === 'running' && j.log.length ? `<details><summary>Build log</summary><pre class="joblog">${E(j.log.join('\n'))}</pre></details>` : ''}
      ${j.status === 'succeeded' ? `<div class="plan ok" role="status"><h3>Server created</h3><p>${E(j.result.software)} ${E(j.result.version)}${j.result.build ? ` #${E(j.result.build)}` : ''} on port ${E(j.result.port)}${j.result.verified ? ` · ${E(j.result.verified.toUpperCase())} verified` : ''}.</p>${j.result.needsEula ? '<p class="warn-text">The EULA has not been accepted yet; the server will stop on first start until eula.txt is set to true.</p>' : ''}${j.result.velocitySecretCreated ? '<p>A forwarding secret was generated. Put the same value in each backend server for modern forwarding.</p>' : ''}<button class="btn blue" id="jobOpen">Open server</button></div>` : ''}
      ${j.status === 'failed' ? `<div class="plan err" role="alert"><h3>Creation failed</h3><p>${E(j.error)}</p>${j.rolledBack ? '<p>Nothing was left behind. You can fix the problem and try again.</p>' : ''}<button class="btn" id="jobAgain">Back to the form</button></div>` : ''}`; };
    for (let i = 0; i < 3000; i++) {
      let j; try { j = await apiX('/api/jobs/' + encodeURIComponent(jobId)); } catch (e) { box.innerHTML = errorHtml(e.message); return; }
      render(j);
      if (j.status !== 'running') {
        if (j.status === 'succeeded') { try { await refresh(); } catch { /* list refreshes later */ } $1('#jobOpen')?.addEventListener('click', () => window.navigate(j.result.serverId)); }
        $1('#jobAgain')?.addEventListener('click', () => window.navigate('create')); return;
      }
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  // =============== Server software (custom + eggs) ===============
  pages.software = async function () {
    pageTitle('Server software', 'Add your own software, upload JARs, or import Pterodactyl eggs');
    if (!isAdminUser()) return (content().innerHTML = adminOnlyHtml);
    const d = await apiX('/api/custom-software'), list = d.software;
    content().innerHTML = `<div class="card panel warn-box"><b>Only add software you trust.</b> Server JARs run with the same permissions as this panel. Uploaded and URL-based software cannot be verified by the panel unless you provide the publisher’s SHA-256 checksum.</div>
      <div class="card panel"><h2>Your software</h2>${list.length ? `<div class="table-scroll"><table><thead><tr><th>Name</th><th>Type</th><th>Versions</th><th>Plugins</th><th></th></tr></thead><tbody>${list.map(s => `<tr><td><b>${E(s.name)}</b><br><small class="muted">${E(s.id)} · ${s.origin === 'egg' ? 'Imported egg' : 'Added by admin'}</small></td><td>${E(s.kind)}</td><td>${(s.versions || []).map(v => `${E(v.version)} ${v.sha256 ? badge('SHA-256', 'ok') : badge('no checksum', 'warn')}${v.upload ? ' ' + badge('uploaded', 'info') : ''}`).join('<br>') || '<span class="muted">none yet</span>'}</td><td>${s.supportsPlugins ? E((s.pluginLoaders || []).join(', ')) : 'No'}</td><td class="actions-cell"><button class="btn" data-addver="${E(s.id)}">Add version</button> <button class="btn" data-upload="${E(s.id)}">Upload JAR</button> <button class="btn red" data-del="${E(s.id)}">Remove</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Nothing yet. Built-in software (Vanilla, Paper, Folia, Purpur, Spigot, Fabric, Velocity) is always available on the Create server page.</p>'}</div>
      <div class="card panel"><h2>Add software</h2><form id="swForm" class="fld-grid" novalidate>
        ${field('sw-id', 'ID', '<input id="sw-id" required pattern="[a-z0-9][a-z0-9-]{1,31}" maxlength="32">', 'Lowercase letters, numbers and dashes.')}
        ${field('sw-name', 'Name', '<input id="sw-name" required maxlength="48">')}
        ${field('sw-kind', 'Kind', '<select id="sw-kind"><option value="server">Game server</option><option value="proxy">Proxy</option></select>')}
        ${field('sw-jar', 'JAR file name', '<input id="sw-jar" value="server.jar">')}
        <div class="fld"><label><input type="checkbox" id="sw-plug"> Supports plugins</label><div class="loaders" id="sw-loaders">${['paper', 'spigot', 'bukkit', 'purpur', 'folia', 'velocity', 'bungeecord', 'waterfall'].map(l => `<label class="chk"><input type="checkbox" value="${l}"> ${l}</label>`).join('')}</div><small class="muted">Which plugin ecosystems this software can load.</small></div>
        ${field('sw-ver', 'First version (optional)', '<input id="sw-ver" placeholder="e.g. 1.21.11">')}
        ${field('sw-url', 'Download URL (https)', '<input id="sw-url" type="url" placeholder="https://…/server.jar">')}
        ${field('sw-sha', 'SHA-256 checksum (recommended)', '<input id="sw-sha" spellcheck="false" maxlength="64">', 'Copy it from the publisher so the panel can verify the download.')}
        <div class="btn-row wide"><button class="btn blue" type="submit">Save software</button></div></form></div>
      <div class="card panel"><h2>Import a Pterodactyl egg</h2><p class="muted">Eggs (PTDL_v1/PTDL_v2 JSON) describe Docker-based servers. The startup command and variables can be imported; installation scripts are shown for review but <b>never executed</b>.</p>
        <label class="file-pick">Egg file <input type="file" id="eggFile" accept=".json,application/json"></label><div id="eggReport" aria-live="polite"></div></div>`;
    const reload = () => window.navigate('software');
    $$('[data-del]').forEach(b => b.onclick = () => run(b, async () => { if (!await confirmDialog('Remove software?', `<p>Remove <b>${E(b.dataset.del)}</b> and its uploaded JARs? Servers already created from it keep running.</p>`, 'Remove', 'red')) return; const r = await apiX('/api/custom-software/' + encodeURIComponent(b.dataset.del), { method: 'DELETE' }); toast(r.serversUsingIt?.length ? `Removed. ${r.serversUsingIt.length} existing server(s) still use it.` : 'Removed.'); reload(); }));
    $$('[data-addver]').forEach(b => b.onclick = () => run(b, async () => {
      const s = list.find(x => x.id === b.dataset.addver);
      const r = await dialog({ title: `Add a version to ${s.name}`, body: `<div class="fld"><label for="d-ver">Version</label><input id="d-ver" required></div><div class="fld"><label for="d-url">Download URL (https)</label><input id="d-url" type="url"></div><div class="fld"><label for="d-sha">SHA-256</label><input id="d-sha" maxlength="64"></div><div class="fld"><label for="d-java">Minimum Java (optional)</label><input id="d-java" type="number" min="8" max="40"></div>`, actions: [{ label: 'Add', value: 'add', cls: 'blue' }] });
      if (!r) return; const g = i => r.root.querySelector('#' + i).value.trim();
      const entry = { version: g('d-ver'), url: g('d-url'), ...(g('d-sha') ? { sha256: g('d-sha') } : {}), ...(g('d-java') ? { javaMajor: Number(g('d-java')) } : {}) };
      await apiX('/api/custom-software', { method: 'PUT', body: JSON.stringify({ software: { ...s, versions: [...(s.versions || []).filter(v => v.version !== entry.version), entry] } }) }); toast('Version saved.'); reload();
    }));
    $$('[data-upload]').forEach(b => b.onclick = () => run(b, async () => {
      const r = await dialog({ title: 'Upload a server JAR', body: `<p class="muted">The JAR is checked to be runnable (it must have a Main-Class) and its SHA-256 is recorded. It is <b>not</b> verified against any publisher.</p><div class="fld"><label for="d-ver">Version label</label><input id="d-ver" required></div><div class="fld"><label for="d-file">JAR file</label><input id="d-file" type="file" accept=".jar" required></div>`, actions: [{ label: 'Upload', value: 'up', cls: 'blue' }] });
      if (!r) return; const file = r.root.querySelector('#d-file').files[0], ver = r.root.querySelector('#d-ver').value.trim(); if (!file || !ver) return toast('Choose a file and enter a version.', 'error');
      const fd = new FormData(); fd.append('jar', file);
      const res = await apiX(`/api/custom-software/${encodeURIComponent(b.dataset.upload)}/upload?version=${encodeURIComponent(ver)}`, { method: 'POST', body: fd });
      toast(`Uploaded. SHA-256 ${res.sha256.slice(0, 12)}…`); reload();
    }));
    const loaders = () => $$('#sw-loaders input:checked').map(i => i.value);
    $1('#swForm').addEventListener('submit', e => { e.preventDefault(); run($1('#swForm button[type=submit]'), async () => {
      const g = i => $1('#' + i).value.trim(), ver = g('sw-ver');
      const software = { id: g('sw-id'), name: g('sw-name'), kind: g('sw-kind'), jar: g('sw-jar') || undefined, supportsPlugins: $1('#sw-plug').checked, pluginLoaders: loaders(), versions: ver ? [{ version: ver, url: g('sw-url'), ...(g('sw-sha') ? { sha256: g('sw-sha') } : {}) }] : [] };
      try { await apiX('/api/custom-software', { method: 'PUT', body: JSON.stringify({ software }) }); toast('Saved.'); reload(); } catch (err) { toast((err.details || [err.message]).join(' '), 'error'); }
    }); });
    $1('#eggFile').addEventListener('change', async ev => {
      const box = $1('#eggReport'); const f = ev.target.files[0]; if (!f) return; box.innerHTML = loadingHtml('Reading egg…');
      let egg; try { egg = JSON.parse(await f.text()); } catch { box.innerHTML = errorHtml('That file is not valid JSON.'); return; }
      try {
        const p = await apiX('/api/eggs/preview', { method: 'POST', body: JSON.stringify({ egg }) }), rep = p.report, li = (a, i) => (a || []).map(x => `<li><span aria-hidden="true">${i}</span> ${E(x)}</li>`).join('');
        box.innerHTML = `<div class="plan"><h3>${E(p.profile.name)} <small class="muted">by ${E(p.profile.egg.author || 'unknown')}</small></h3><p>${p.importable ? badge('Partly importable', 'warn') : badge('Cannot be imported', 'bad')}</p><ul class="plan-list ok">${li(rep.supported, statusIcon.ok)}</ul><ul class="plan-list bad">${li(rep.unsupported, statusIcon.fail)}</ul><ul class="plan-list warn">${li(rep.warnings, statusIcon.warn)}</ul>${p.installScriptPreview ? `<details><summary>Installation script (not executed)</summary><pre class="joblog">${E(p.installScriptPreview)}</pre></details>` : ''}${p.importable ? '<button class="btn blue" id="eggGo">Import as software</button>' : ''}</div>`;
        $1('#eggGo')?.addEventListener('click', e => run(e.target, async () => { const r = await apiX('/api/eggs/import', { method: 'POST', body: JSON.stringify({ egg, confirm: true }) }); toast(r.nextStep); reload(); }));
      } catch (err) { box.innerHTML = errorHtml(err.message); }
    });
  };

  // =============== System check ===============
  pages.health = async function () {
    pageTitle('System check', 'Operating system, Java, resources, permissions and configuration');
    if (!isAdminUser()) return (content().innerHTML = adminOnlyHtml);
    const r = await apiX('/api/platform/environment'), f = r.facts;
    const label = { ok: 'OK', warn: 'Needs attention', fail: 'Problem', info: 'Info' };
    content().innerHTML = `<div class="card panel"><div class="toolbar"><h2 style="margin:0">Overall: ${E(label[r.overall])}</h2><button class="btn" id="hcRe">Run again</button></div>
      <ul class="checks">${r.checks.map(c => `<li class="check ${c.status}"><span class="ico" aria-hidden="true">${statusIcon[c.status]}</span><div><b>${E(c.label)}</b> <span class="sr-only">${E(label[c.status])}</span><div>${E(c.detail)}</div>${c.fix ? `<div class="fix"><b>What to do:</b> ${E(c.fix)}</div>` : ''}</div></li>`).join('')}</ul></div>
      <div class="card panel"><h2>Details</h2><dl class="kvgrid"><dt>Run by user</dt><dd>${E(f.os.user)}</dd><dt>Memory</dt><dd>${bytes(f.memory.totalBytes)} total · ${f.memory.cpus} CPU cores</dd><dt>Suggested memory per new server</dt><dd>${E(f.suggestedMemoryGB)} GB</dd>${f.disk ? `<dt>Free disk (servers)</dt><dd>${bytes(f.disk.freeBytes)}</dd>` : ''}<dt>Other Java installs</dt><dd>${f.jvms.length ? f.jvms.map(j => `Java ${j.major} (${E(j.path)})`).join('<br>') : 'None found in standard locations'}</dd></dl></div>`;
    $1('#hcRe').onclick = e => run(e.target, () => window.navigate('health'));
  };
})();
