/* Extension host UI: navigation, declarative page renderer, sandboxed iframe bridge, language picker.
   Loaded after platform-manage.js. Extension text is only ever inserted with textContent. */
(function () {
  'use strict';
  const { pages, toast, dialog, confirmDialog, run, apiX, loadingHtml, errorHtml, pageTitle, $$, $1, content } = window.__bp;
  const tr = (k, fb) => (window.__i18n?.messages?.[k]) ?? fb ?? k;
  window.t = tr;
  const el = (tag, props = {}, ...kids) => { const n = document.createElement(tag); for (const [k, v] of Object.entries(props)) { if (v === undefined || v === null || v === false) continue; if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v === true ? '' : v); } for (const c of kids.flat()) if (c != null) n.append(c); return n; };

  // ---------- i18n ----------
  const AVAILABLE_KEY = 'hn-lang';
  async function loadI18n(lang) {
    try {
      const d = await (await fetch('/api/i18n/' + encodeURIComponent(lang), { cache: 'no-store' })).json();
      if (!d.messages) return;
      window.__i18n = d; document.documentElement.lang = d.lang; document.documentElement.dir = d.dir;
      try { localStorage.setItem(AVAILABLE_KEY, d.lang); } catch { /* private mode */ }
      buildPicker(); if (window.__brand) window.__bp.applyBranding(window.__brand); applyStatic();
    } catch { /* stay on the current language */ }
  }
  function applyStatic() { $$('[data-i18n]').forEach(n => { const v = tr(n.dataset.i18n, ''); if (v) n.textContent = v; }); }
  function buildPicker() {
    const d = window.__i18n; if (!d) return;
    let sel = $1('#langPick');
    if (!sel) {
      const anchor = $1('#connection'); if (!anchor) return;
      sel = el('select', { id: 'langPick', 'aria-label': tr('common.language', 'Language'), class: 'lang-pick', onchange: e => loadI18n(e.target.value) }); anchor.before(sel);
    }
    sel.innerHTML = ''; for (const l of d.languages) sel.append(el('option', { value: l.code, text: l.name, selected: l.code === d.lang }));
    sel.hidden = d.languages.length < 2; sel.setAttribute('aria-label', tr('common.language', 'Language'));
  }
  let startLang = 'en'; try { startLang = localStorage.getItem(AVAILABLE_KEY) || (navigator.language || 'en').split('-')[0]; } catch { /* ignore */ }
  if (!/^[a-z]{2}(-[A-Z]{2})?$/.test(startLang)) startLang = 'en';
  loadI18n(startLang).then(() => { if (!window.__i18n && startLang !== 'en') loadI18n('en'); });

  // ---------- navigation ----------
  let uiPages = [], uiAt = 0;
  async function refreshPages(force) {
    if (!force && Date.now() - uiAt < 5000) return uiPages;
    if (!state.role) return uiPages;
    try { uiPages = (await apiX('/api/ext/ui')).pages; uiAt = Date.now(); } catch { uiPages = []; }
    for (const p of uiPages) pages[`ext:${p.ext}:${p.id}`] = () => renderExt(p.ext, p.id, null);
    return uiPages;
  }
  async function installExtNav() {
    const list = await refreshPages(); const navPages = list.filter(p => p.placement === 'nav');
    let g = $1('.side-group[data-group="extensions"]');
    if (!navPages.length) { g?.remove(); return; }
    if (!g) { const mgmt = $1('.side-group[data-group="management"]'); if (!mgmt) return; g = el('details', { class: 'side-group', 'data-group': 'extensions', open: true }, el('summary', { text: tr('group.extensions', 'Extensions') })); mgmt.before(g); }
    $1('summary', g).textContent = tr('group.extensions', 'Extensions');
    const want = new Set(navPages.map(p => `ext:${p.ext}:${p.id}`));
    $$('.nav', g).forEach(b => { if (!want.has(b.dataset.page)) b.remove(); });
    for (const p of navPages) {
      const key = `ext:${p.ext}:${p.id}`; let b = $1(`.nav[data-page="${CSS.escape(key)}"]`, g);
      if (!b) { b = el('button', { class: 'nav', type: 'button', 'data-page': key, onclick: () => { $1('.sidebar')?.classList.remove('mobile-open'); window.navigate(key); } }); g.append(b); }
      b.textContent = `${p.icon} ${p.title}`; b.title = p.extName;
      b.classList.toggle('active', state.page === key); b.setAttribute('aria-current', state.page === key ? 'page' : 'false');
    }
  }
  const baseInstallNav = window.__bp.installNav;
  window.__bp.installNav = function () { baseInstallNav(); installExtNav().catch(() => {}); };
  setInterval(() => { if (state.role) installExtNav().catch(() => {}); }, 60000);
  setTimeout(() => installExtNav().catch(() => {}), 800);

  // Per-server pages: buttons on the server page.
  const prevOpenPage = window.openPage;
  window.openPage = async function (id) {
    const r = await prevOpenPage.apply(this, arguments);
    try {
      const list = (await refreshPages(true)).filter(p => p.placement === 'server' && (p.serverType !== 'plugins' || state.servers[id]?.pluginsSupported === true));
      const anchor = $1('#content [data-props-btn]') || $1('#content button[onclick^="openFiles("]');
      if (anchor) for (const p of list.reverse()) { if ($1(`#content [data-ext-btn="${CSS.escape(p.ext + ':' + p.id)}"]`)) continue; const b = el('button', { class: 'btn', type: 'button', 'data-ext-btn': `${p.ext}:${p.id}`, title: p.extName, text: `${p.icon} ${p.title}`, onclick: () => { state.current = id; state.page = id; renderExt(p.ext, p.id, id); } }); anchor.after(b); }
    } catch { /* cosmetic */ }
    return r;
  };

  // ---------- page rendering ----------
  async function renderExt(extId, pageId, serverId) {
    const root = content(); root.innerHTML = loadingHtml();
    let v; try { v = await apiX(`/api/ext/${encodeURIComponent(extId)}/pages/${encodeURIComponent(pageId)}`); } catch (e) { root.innerHTML = errorHtml(e.message, true); $1('[data-retry]', root)?.addEventListener('click', () => renderExt(extId, pageId, serverId)); return; }
    pageTitle(v.page.title, serverId ? (state.servers[serverId]?.label || serverId) : v.extName); root.replaceChildren();
    const wrap = el('div', { class: 'ext-page', 'data-ext': extId });
    if (serverId) wrap.append(el('div', { class: 'toolbar' }, el('span', { class: 'muted', text: v.extName }), el('button', { class: 'btn', type: 'button', text: '← ' + tr('nav.overview', 'Server'), onclick: () => openPage(serverId) })));
    root.append(wrap);
    if (v.page.type === 'frame') return renderFrame(wrap, v, serverId);
    const ctx = { ext: extId, page: pageId, serverId: serverId || '', fixedServer: !!serverId, refreshers: [], onServer: [] };
    wrap.append(node(v.page.content, ctx));
    ctx.refresh = () => ctx.refreshers.forEach(f => f());
    ctx.refresh();
  }
  const SERVER_POST = (ctx, extra) => ({ page: ctx.page, serverId: ctx.serverId || undefined, ...extra });
  function askWithText(text, style) {
    return new Promise(resolve => {
      const d = document.createElement('dialog'); d.className = 'bp-dialog card';
      const f = el('form', { method: 'dialog' }, el('h2', { text: tr('common.confirm', 'Are you sure?') }), el('p', { text }), el('div', { class: 'dlg-actions' }, el('button', { class: 'btn', value: 'no', text: tr('common.cancel', 'Cancel') }), el('button', { class: 'btn ' + (style === 'danger' ? 'red' : 'blue'), value: 'yes', text: 'OK' })));
      d.append(f); d.addEventListener('close', () => { resolve(d.returnValue === 'yes'); d.remove(); }); document.body.append(d); d.showModal();
    });
  }
  async function act(ctx, n, body, btn) {
    if (n.confirm && !await askWithText(n.confirm, n.style)) return;
    await run(btn, async () => { await apiX(`/api/ext/${encodeURIComponent(ctx.ext)}/action`, { method: 'POST', body: JSON.stringify(SERVER_POST(ctx, body)) }); toast(n.successMessage || tr('common.done', 'Done.')); ctx.refresh(); });
  }
  function node(n, ctx) {
    switch (n.type) {
      case 'stack': return el('div', { class: 'ext-stack ' + n.direction }, (n.children || []).map(c => node(c, ctx)));
      case 'heading': return el('h' + (n.level + 1 > 4 ? 4 : n.level + 1), { text: n.text, class: 'ext-h' });
      case 'text': return el('p', { class: 'ext-text', text: n.text });
      case 'divider': return el('hr');
      case 'alert': return el('div', { class: 'ext-alert ' + n.kind, role: n.kind === 'error' ? 'alert' : 'note', text: n.text });
      case 'serverPicker': {
        if (ctx.fixedServer) return document.createComment('server fixed');
        const opts = Object.entries(state.servers || {}).filter(([, s]) => n.serverType !== 'plugins' || s.pluginsSupported === true);
        const sel = el('select', { id: 'ext-srv-' + n.path.replace(/\W/g, '_'), onchange: e => { ctx.serverId = e.target.value; ctx.refresh(); } }, el('option', { value: '', text: tr('ext.chooseServer', 'Choose a server') }), opts.map(([id, s]) => el('option', { value: id, text: s.label || id })));
        return el('div', { class: 'fld' }, el('label', { for: sel.id, text: n.label }), sel);
      }
      case 'button': { const b = el('button', { class: 'btn ' + (n.style === 'primary' ? 'blue' : n.style === 'danger' ? 'red' : ''), type: 'button', text: n.label, onclick: () => act(ctx, n, { path: n.path }, b) }); return b; }
      case 'tabs': {
        const list = el('div', { class: 'tabs', role: 'tablist' }), panels = n.tabs.map(t => el('div', { role: 'tabpanel', hidden: true }, t.children.map(c => node(c, ctx))));
        const tabs = n.tabs.map((t, i) => el('button', { class: 'btn', role: 'tab', type: 'button', text: t.title, onclick: () => show(i) })); list.append(...tabs);
        const show = i => { panels.forEach((p, j) => { p.hidden = j !== i; tabs[j].classList.toggle('blue', j === i); tabs[j].setAttribute('aria-selected', j === i); }); }; show(0);
        return el('div', {}, list, panels);
      }
      case 'form': return form(n, ctx);
      case 'table': return table(n, ctx);
    }
    return document.createComment('unknown');
  }
  function form(n, ctx) {
    const f = el('form', { class: 'card panel ext-form', novalidate: true });
    const inputs = {};
    for (const fld of n.fields) {
      const id = `ef-${n.path.replace(/\W/g, '_')}-${fld.name}`; let input;
      if (fld.type === 'select') input = el('select', { id }, fld.options.map(o => el('option', { value: o, text: o, selected: o === fld.default })));
      else if (fld.type === 'textarea') input = el('textarea', { id, rows: 3, maxlength: fld.maxLength });
      else if (fld.type === 'bool') input = el('input', { id, type: 'checkbox', checked: fld.default === true });
      else input = el('input', { id, type: fld.type === 'number' ? 'number' : 'text', min: fld.min, max: fld.max, maxlength: fld.maxLength, value: fld.default ?? '', autocomplete: 'off' });
      inputs[fld.name] = input;
      f.append(el('div', { class: 'fld' }, el('label', { for: id, text: fld.label + (fld.required ? ' *' : '') }), input, fld.help ? el('small', { class: 'muted', text: fld.help }) : null));
    }
    const err = el('div', { class: 'error-text', role: 'alert' }), submit = el('button', { class: 'btn blue', type: 'submit', text: n.submit.label });
    f.append(err, el('div', { class: 'btn-row' }, submit));
    f.addEventListener('submit', async e => {
      e.preventDefault(); err.textContent = '';
      const values = Object.fromEntries(n.fields.map(x => [x.name, x.type === 'bool' ? inputs[x.name].checked : inputs[x.name].value]));
      if (n.needsServer && !ctx.serverId) { err.textContent = tr('ext.chooseServer', 'Choose a server'); return; }
      if (n.submit.confirm && !await askWithText(n.submit.confirm, 'plain')) return;
      await run(submit, async () => {
        try { await apiX(`/api/ext/${encodeURIComponent(ctx.ext)}/action`, { method: 'POST', body: JSON.stringify(SERVER_POST(ctx, { path: n.path, values })) }); toast(n.submit.successMessage || tr('common.done', 'Done.')); if (n.resetOnSubmit) n.fields.forEach(x => { if (x.type === 'bool') inputs[x.name].checked = x.default === true; else if (x.type !== 'select') inputs[x.name].value = x.default ?? ''; }); ctx.refresh(); }
        catch (ex) { err.textContent = ex.message; throw ex; }
      });
    });
    return f;
  }
  function table(n, ctx) {
    const box = el('div', { class: 'card panel' }), status = el('div', { role: 'status', class: 'muted' });
    if (n.title) box.append(el('h3', { text: n.title }));
    const holder = el('div', { class: 'table-scroll' }); box.append(status, holder);
    const fmt = (v, c) => v == null ? '' : c.format === 'datetime' && v ? new Date(v).toLocaleString() : c.format === 'bool' ? (v ? '✔' : '–') : typeof v === 'object' ? JSON.stringify(v) : String(v);
    async function load() {
      if (n.needsServer && !ctx.serverId) { holder.replaceChildren(); status.textContent = tr('ext.chooseServer', 'Choose a server'); return; }
      status.textContent = tr('common.loading', 'Loading…');
      try {
        const r = await apiX(`/api/ext/${encodeURIComponent(ctx.ext)}/source`, { method: 'POST', body: JSON.stringify(SERVER_POST(ctx, { path: n.path })) });
        status.textContent = r.rows.length ? '' : n.empty;
        if (!r.rows.length) { holder.replaceChildren(); return; }
        const t = el('table', {}, el('thead', {}, el('tr', {}, n.columns.map(c => el('th', { scope: 'col', text: c.label })), n.rowActions.length ? el('th', { text: '' }) : null)),
          el('tbody', {}, r.rows.map(row => el('tr', {}, n.columns.map(c => el('td', { text: fmt(row[c.key], c) })), n.rowActions.length ? el('td', { class: 'actions-cell' }, n.rowActions.map((a, i) => (a.when && String(row[a.when.key]) !== a.when.equals) ? null : el('button', { class: 'btn ' + (a.style === 'danger' ? 'red' : ''), type: 'button', text: a.label, onclick: e => act(ctx, a, { path: n.path, index: i, row }, e.target) }))) : null))));
        holder.replaceChildren(t);
      } catch (e) { status.textContent = e.message; }
    }
    ctx.refreshers.push(load); if (n.refreshSeconds) { const id = setInterval(() => { if (!document.body.contains(box)) clearInterval(id); else load(); }, n.refreshSeconds * 1000); }
    return box;
  }

  // ---------- sandboxed frames ----------
  function renderFrame(wrap, v, serverId) {
    const ifr = el('iframe', { sandbox: 'allow-scripts allow-forms', src: `/ext-frame/${encodeURIComponent(v.ext)}/${encodeURIComponent(v.page.entry)}`, title: `${v.extName}: ${v.page.title}`, referrerpolicy: 'no-referrer', class: 'ext-frame', style: `height:${v.page.height}px` });
    wrap.append(ifr);
    let inflight = 0;
    const ctxMsg = () => { const cs = getComputedStyle(document.body), tokens = {}; for (const k of ['--bg', '--panel', '--text', '--muted', '--blue', '--line']) tokens[k] = cs.getPropertyValue(k).trim(); return { hn: 1, type: 'context', context: { lang: window.__i18n?.lang || 'en', dir: window.__i18n?.dir || 'ltr', serverId: serverId || null, user: state.user || null, isAdmin: state.role === 'admin', settings: v.page.settings || {}, tokens, messages: window.__i18n?.messages || {} } }; };
    const onMsg = async ev => {
      if (!document.body.contains(ifr)) { removeEventListener('message', onMsg); return; }
      if (ev.source !== ifr.contentWindow) return;
      const m = ev.data; if (!m || m.hn !== 1) return;
      if (m.type === 'hello') { ifr.contentWindow.postMessage(ctxMsg(), '*'); return; }
      if (m.type === 'resize') { ifr.style.height = Math.max(100, Math.min(3000, Number(m.height) || 0)) + 'px'; return; }
      if (m.type !== 'call' || typeof m.capability !== 'string' || !Number.isInteger(m.id)) return;
      if (inflight >= 8) { ifr.contentWindow.postMessage({ hn: 1, id: m.id, ok: false, error: 'Too many requests at once.' }, '*'); return; }
      inflight++;
      try { const r = await apiX(`/api/ext/${encodeURIComponent(v.ext)}/bridge`, { method: 'POST', body: JSON.stringify({ page: v.page.id, capability: m.capability, args: m.args && typeof m.args === 'object' ? m.args : {} }) }); ifr.contentWindow?.postMessage({ hn: 1, id: m.id, ok: true, result: r.result }, '*'); }
      catch (e) { ifr.contentWindow?.postMessage({ hn: 1, id: m.id, ok: false, error: e.message, status: e.status }, '*'); }
      finally { inflight--; }
    };
    addEventListener('message', onMsg);
  }
  window.__bp.renderExt = renderExt; window.__bp.refreshExtPages = () => installExtNav();
})();
