/* Platform pages (part 3): extensions, branding, plugin manager. Loaded after platform-pages.js. */
(function () {
  'use strict';
  const { pages, toast, dialog, confirmDialog, run, apiX, badge, loadingHtml, errorHtml, adminOnlyHtml, pageTitle, statusIcon, bytes, $$, $1, content, isAdminUser, applyBranding, loadBranding } = window.__bp;
  const E = s => esc(s);
  const field = (id, label, input, hint = '') => `<div class="fld"><label for="${id}">${E(label)}</label>${input}${hint ? `<small class="muted">${hint}</small>` : ''}</div>`;
  let PERM = {}, SENSITIVE = [];

  // =============== Extensions ===============
  pages.extensions = async function () {
    pageTitle('Extensions', 'Install, configure, update and remove extensions');
    if (!isAdminUser()) return (content().innerHTML = adminOnlyHtml);
    const d = await apiX('/api/extensions'); PERM = d.permissions || {}; SENSITIVE = d.sensitive || [];
    let found = { extensions: [], errors: [], note: null }; try { found = await apiX('/api/extensions-discover'); } catch { /* discovery is optional */ }
    const reload = () => window.navigate('extensions');
    let safe = { safeMode: false }; try { safe = await apiX('/api/extensions-safe-mode'); } catch { /* optional */ }
    const supportChip = c => ({ native: badge('Valid native extension', 'ok'), partial: badge('Egg — use Import egg', 'warn'), none: badge('Not supported here', 'bad') })[c] || '';
    const permList = ps => ps.length ? `<ul class="perm-list">${ps.map(p => p.startsWith('http:') ? `<li><code>${E(p)}</code> — may send web requests to <b>${E(p.slice(5))}</b> ${badge('sensitive', 'warn')}</li>` : `<li><code>${E(p)}</code> — ${E(PERM[p] || '')} ${SENSITIVE.includes(p) ? badge('sensitive', 'warn') : ''}</li>`).join('')}</ul>` : '<p class="muted">Requests no permissions.</p>';
    content().innerHTML = `<div class="card panel ${safe.safeMode ? 'warn-box' : 'info-box'}" role="${safe.safeMode ? 'alert' : 'note'}"><label class="chk"><input type="checkbox" id="safeToggle" ${safe.safeMode ? 'checked' : ''} ${safe.forcedByStartup ? 'disabled' : ''}> <span><b>Safe mode</b> — switch every extension’s pages, jobs, events and translations off without removing anything.${safe.forcedByStartup ? ' (Forced on by the --no-extensions startup option.)' : ''}</span></label></div><div class="card panel info-box"><b>About compatibility.</b> Pterodactyl itself has no official extension system. Community add-ons for it (for example Blueprint packages) are PHP/Laravel code that patches Pterodactyl, so they <b>cannot run in this Node.js panel</b>. Pterodactyl <b>eggs</b> can be imported on the Server software page. Extensions here are packages (<code>extension.json</code>) that add pages, buttons, forms, scheduled jobs, event reactions, translations, software definitions, themes or links. They never run code in the panel; their own web pages run in a locked-down sandbox. See docs/EXTENSIONS.md. “Valid” below means the package passed this panel’s own validation — not that it has been tested in any other product.</div>
      <div class="card panel"><h2>Installed</h2>${d.installed.length ? d.installed.map(x => {
        const m = x.manifest; return `<article class="ext" aria-labelledby="ext-${E(x.id)}"><header><h3 id="ext-${E(x.id)}">${E(m?.name || x.id)} <small>v${E(x.version)}</small></h3>${x.broken ? badge('Damaged', 'bad') : x.enabled ? badge('Enabled', 'ok') : badge('Disabled', 'warn')}${x.needsApproval ? badge('Needs permission approval', 'warn') : ''}${badge(x.validation === 'schema-validated' ? 'Schema-validated' : '', 'info')}</header>
          <p>${E(m?.description || '')}</p><p class="muted">${m?.author ? 'By ' + E(m.author) + ' · ' : ''}${m?.license ? E(m.license) + ' · ' : ''}Source: ${E(x.source?.type || 'unknown')} · ${E(x.compatibility.note)}</p>
          ${x.lastResult ? `<p class="muted" role="status">Last action: ${E(x.lastResult.message)} (${E(new Date(x.lastResult.at).toLocaleString())})</p>` : ''}
          <details><summary>Permissions &amp; contributions</summary>${permList(m?.permissions || [])}<p class="muted">Provides: ${m ? `${m.provides.software.length} software, ${m.provides.themes.length} themes, ${m.provides.links.length} links${m.schemaVersion === 2 ? `, ${m.pages.length} pages, ${m.events.length} event reactions, ${m.jobs.length} scheduled jobs, ${Object.keys(m.translations).length} languages` : ''}` : '—'}</p>${m?.schemaVersion === 2 && m.pages.some(p => p.type === 'frame') ? '<p class="muted">Includes pages that run the extension’s own HTML/JavaScript inside a locked-down sandbox (no access to your session, cookies or the panel page). They can only use the capabilities listed in the permissions above.</p>' : ''}</details>${(x.jobs || []).length ? `<details><summary>Scheduled jobs</summary><ul class="perm-list">${x.jobs.map(j => `<li><b>${E(j.title)}</b> — ${E(j.schedule)} · ${j.lastRun ? 'last run ' + E(new Date(j.lastRun).toLocaleString()) + (j.lastOk === false ? ' ' + badge('failed', 'bad') : ' ' + badge('ok', 'ok')) : 'not run yet'} ${x.enabled ? `<button class="btn" data-runjob="${E(x.id)}:${E(j.id)}">Run now</button>` : ''}${j.history?.[0] && !j.history[0].ok ? `<br><small class="error-text">${E(j.history[0].message)}</small>` : ''}</li>`).join('')}</ul></details>` : ''}
          ${m?.settings?.length ? `<details><summary>Settings</summary><form data-settings="${E(x.id)}" class="fld-grid">${m.settings.map(s => { const val = x.settings[s.key] ?? s.default, id = `st-${x.id}-${s.key}`; if (s.type === 'secret') return field(id, s.label, `<input id="${id}" data-key="${E(s.key)}" data-type="secret" type="password" autocomplete="new-password" placeholder="${x.secretsSet?.[s.key] ? '•••••• (set — leave blank to keep)' : 'not set'}">${x.secretsSet?.[s.key] ? `<button type="button" class="btn" data-clearsecret="${E(x.id)}:${E(s.key)}">Clear stored secret</button>` : ''}`, s.help ? E(s.help) + ' ' : 'Stored encrypted; never shown again.'); return field(id, s.label, s.type === 'boolean' ? `<input type="checkbox" id="${id}" data-key="${E(s.key)}" data-type="boolean" ${val ? 'checked' : ''}>` : s.type === 'select' ? `<select id="${id}" data-key="${E(s.key)}" data-type="select">${s.options.map(o => `<option ${o === val ? 'selected' : ''}>${E(o)}</option>`).join('')}</select>` : `<input id="${id}" data-key="${E(s.key)}" data-type="${s.type}" type="${s.type === 'number' ? 'number' : 'text'}" value="${E(val)}">`); }).join('')}<div class="btn-row wide"><button class="btn blue" type="submit">Save settings</button></div></form></details>` : ''}
          <div class="btn-row">${x.enabled ? `<button class="btn" data-act="disable" data-id="${E(x.id)}">Disable</button>` : `<button class="btn blue" data-act="enable" data-id="${E(x.id)}" ${x.broken ? 'disabled' : ''}>Review &amp; enable</button>`}${x.canRollback ? `<button class="btn" data-act="rollback" data-id="${E(x.id)}">Roll back to v${E(x.rollbackVersion)}</button>` : ''}<button class="btn red" data-act="remove" data-id="${E(x.id)}">Remove</button></div></article>`; }).join('') : '<p class="muted">No extensions installed.</p>'}</div>
      <div class="card panel"><h2>Available</h2><h3>Bundled with this panel</h3>${d.bundled.length ? d.bundled.map(b => `<div class="avail"><div><b>${E(b.name)}</b> <small>v${E(b.version)}</small><br><span class="muted">${E(b.description)}</span></div>${b.installed === b.version ? badge('Installed', 'ok') : b.compat.ok ? `<button class="btn blue" data-bundled="${E(b.id)}">${b.installed ? 'Update' : 'Install'}</button>` : badge(b.compat.note, 'bad')}</div>`).join('') : '<p class="muted">None.</p>'}
        <h3>From registries</h3>${found.note ? `<p class="muted">${E(found.note)}</p>` : ''}${found.errors.map(e => `<p class="error-text">${E(e.registry)}: ${E(e.error)}</p>`).join('')}${found.extensions.map(x => `<div class="avail"><div><b>${E(x.name)}</b> <small>v${E(x.version)}</small> ${x.hasChecksum ? badge('Checksum listed', 'ok') : badge('No checksum — cannot install', 'bad')}<br><span class="muted">${E(x.description)}</span><br><small>Permissions: ${x.permissions.length ? x.permissions.map(E).join(', ') : 'none'} · ${E(x.registry)}</small></div><button class="btn blue" data-reg="${E(x.id)}" data-regurl="${E(x.registry)}" ${x.hasChecksum ? '' : 'disabled'}>Install</button></div>`).join('')}
        <details><summary>Registries (${d.registries.length})</summary><p class="muted">Registries are JSON lists you choose to trust. This panel ships none by default.</p><form id="regForm"><label for="regUrls">One https URL per line (max 5)</label><textarea id="regUrls" rows="3" spellcheck="false">${E(d.registries.join('\n'))}</textarea><button class="btn" type="submit">Save registries</button></form></details></div>
      <div class="card panel"><h2>Install from a file</h2><p class="muted">Accepts native extension packages (.bpext / .zip). Blueprint packages and eggs are recognised and explained, never run.</p><label class="file-pick">Package <input type="file" id="extFile" accept=".hnx,.bpext,.zip,.json"></label><div id="extReport" aria-live="polite"></div></div>`;
    $$('[data-act]').forEach(b => b.onclick = () => run(b, async () => {
      const id = b.dataset.id, x = d.installed.find(i => i.id === id), base = `/api/extensions/${encodeURIComponent(id)}`;
      if (b.dataset.act === 'enable') {
        const perms = x.manifest.permissions, r = await dialog({ title: `Enable ${x.manifest.name}?`, body: `<p>This extension requests:</p>${permList(perms)}<p class="muted">It runs no code. These permissions only allow the contributions described above.</p>`, actions: [{ label: perms.length ? 'Approve & enable' : 'Enable', value: 'ok', cls: 'blue' }] });
        if (!r) return; await apiX(base + '/enable', { method: 'POST', body: JSON.stringify({ approve: perms }) }); toast('Enabled.');
      } else if (b.dataset.act === 'disable') { await apiX(base + '/disable', { method: 'POST' }); toast('Disabled.'); }
      else if (b.dataset.act === 'rollback') { if (!await confirmDialog('Roll back?', `<p>Restore v${E(x.rollbackVersion)}? The extension will be disabled until you enable it again.</p>`, 'Roll back')) return; await apiX(base + '/rollback', { method: 'POST' }); toast('Rolled back.'); }
      else if (b.dataset.act === 'remove') { const rr = await dialog({ title: 'Remove extension?', body: `<p>Remove <b>${E(x.manifest?.name || id)}</b> and all its versions?</p><label class="chk"><input type="checkbox" id="keepData"> Keep its stored data and secrets (so a reinstall picks up where it left off)</label>`, actions: [{ label: 'Remove', value: 'rm', cls: 'red' }] }); if (!rr) return; await apiX(base + (rr.root.querySelector('#keepData').checked ? '?keepData=1' : ''), { method: 'DELETE' }); toast('Removed.'); }
      reload();
    }));
    $$('[data-bundled]').forEach(b => b.onclick = () => run(b, async () => { const r = await apiX(`/api/extensions/bundled/${encodeURIComponent(b.dataset.bundled)}/install`, { method: 'POST' }); toast(r.message + ' Review and enable it to use it.'); reload(); }));
    $$('[data-reg]').forEach(b => b.onclick = () => run(b, async () => { const r = await apiX('/api/extensions-registry-install', { method: 'POST', body: JSON.stringify({ registry: b.dataset.regurl, id: b.dataset.reg }) }); toast(r.message); reload(); }));
    $$('[data-settings]').forEach(f => f.addEventListener('submit', e => { e.preventDefault(); run(f.querySelector('button'), async () => {
      const values = {}; $$('[data-key]', f).forEach(i => { if (i.dataset.type === 'secret' && !i.value) return; values[i.dataset.key] = i.dataset.type === 'boolean' ? i.checked : i.dataset.type === 'number' ? Number(i.value) : i.value; });
      try { await apiX(`/api/extensions/${encodeURIComponent(f.dataset.settings)}/settings`, { method: 'PUT', body: JSON.stringify({ values }) }); toast('Settings saved.'); } catch (err) { toast((err.details || [err.message]).join(' '), 'error'); }
    }); }));
    $1('#safeToggle')?.addEventListener('change', e => run(e.target, async () => { await apiX('/api/extensions-safe-mode', { method: 'PUT', body: JSON.stringify({ enabled: e.target.checked }) }); toast(e.target.checked ? 'Safe mode on: extensions are paused.' : 'Safe mode off.'); await window.__bp.refreshExtPages?.(); reload(); }));
    $$('[data-runjob]').forEach(b => b.onclick = () => run(b, async () => { const [eid, jid] = b.dataset.runjob.split(':'); await apiX(`/api/ext/${encodeURIComponent(eid)}/jobs/${encodeURIComponent(jid)}/run`, { method: 'POST' }); toast('Job ran.'); reload(); }));
    $$('[data-clearsecret]').forEach(b => b.onclick = () => run(b, async () => { const [eid, key] = b.dataset.clearsecret.split(':'); await apiX(`/api/extensions/${encodeURIComponent(eid)}/settings`, { method: 'PUT', body: JSON.stringify({ values: { [key]: null } }) }); toast('Secret cleared.'); reload(); }));
    $1('#regForm').addEventListener('submit', e => { e.preventDefault(); run(e.submitter, async () => { await apiX('/api/extension-registries', { method: 'PUT', body: JSON.stringify({ urls: $1('#regUrls').value.split('\n').map(s => s.trim()).filter(Boolean) }) }); toast('Registries saved.'); reload(); }); });
    $1('#extFile').addEventListener('change', async ev => {
      const f = ev.target.files[0], box = $1('#extReport'); if (!f) return; box.innerHTML = loadingHtml('Checking package…');
      const fd = () => { const x = new FormData(); x.append('package', f); return x; };
      try {
        const r = await apiX('/api/extensions/check', { method: 'POST', body: fd() });
        const canInstall = r.format === 'native' && r.support === 'native';
        box.innerHTML = `<div class="plan ${r.support === 'none' ? 'err' : ''}"><h3>${E(r.summary)}</h3><p>${E({ native: 'Native extension', blueprint: 'Pterodactyl Blueprint package', egg: 'Pterodactyl egg' }[r.format] || r.format)} · ${r.support === 'native' ? badge('Supported', 'ok') : r.support === 'partial' ? badge('Partly supported', 'warn') : badge('Not supported', 'bad')}</p>${(r.details || []).map(t => `<p>${E(t)}</p>`).join('')}${r.manifest ? `<p>Requests: ${r.manifest.permissions.map(p => `<code>${E(p)}</code>`).join(', ') || 'no permissions'}</p>` : ''}${canInstall ? '<button class="btn blue" id="extGo">Install</button>' : ''}${r.format === 'egg' ? '<p>Open <b>Server software</b> to import this egg.</p>' : ''}</div>`;
        $1('#extGo')?.addEventListener('click', e => run(e.target, async () => { const res = await apiX('/api/extensions/install', { method: 'POST', body: fd() }); toast(res.message); reload(); }));
      } catch (err) { box.innerHTML = `<div class="plan err" role="alert"><h3>${E(err.message)}</h3>${(err.details || []).map(t => `<p>${E(t)}</p>`).join('')}</div>`; }
    });
  };

  // =============== Branding ===============
  pages.branding = async function () {
    pageTitle('Branding', 'Name, logo, colours, labels and links. Internal routes and permissions never change.');
    if (!isAdminUser()) return (content().innerHTML = adminOnlyHtml);
    const [b, th] = await Promise.all([apiX('/api/branding'), apiX('/api/branding/themes')]);
    const colorKeys = [['accent', 'Primary accent'], ['accent2', 'Secondary accent'], ['background', 'Page background'], ['surface', 'Panels and cards'], ['text', 'Main text'], ['muted', 'Secondary text']];
    const labelKeys = Object.keys(b.defaultLabels);
    const linkRow = (l = {}) => `<div class="link-row"><input aria-label="Link label" placeholder="Label" maxlength="30" value="${E(l.label || '')}"><input aria-label="Link URL" type="url" placeholder="https://…" value="${E(l.url || '')}"><select aria-label="Placement">${['sidebar', 'footer', 'login'].map(p => `<option ${p === (l.placement || 'sidebar') ? 'selected' : ''}>${p}</option>`).join('')}</select><button type="button" class="btn red" data-rmlink aria-label="Remove link">✕</button></div>`;
    content().innerHTML = `<form id="brForm" class="card panel" novalidate>
      <h2>Identity</h2><div class="fld-grid">${field('br-name', 'Panel name', `<input id="br-name" maxlength="40" required value="${E(b.name)}">`)}${field('br-short', 'Short name', `<input id="br-short" maxlength="12" value="${E(b.shortName)}">`, 'Shown under installed app icons.')}</div>
      <div class="fld-grid"><div class="fld"><span class="lbl">Logo</span><div class="asset">${b.logoUrl ? `<img src="${E(b.logoUrl)}" alt="Current logo">` : '<span class="muted">Using text only</span>'}</div><input type="file" id="br-logo" accept="image/png,image/jpeg,image/webp,image/gif" aria-label="Upload logo">${b.logoUrl ? '<button type="button" class="btn" data-rm="logo">Remove logo</button>' : ''}<small class="muted">PNG, JPEG, WebP or GIF, up to 1 MB. SVG is not accepted.</small></div>
        <div class="fld"><span class="lbl">Icon (favicon / app icon)</span><div class="asset">${b.iconUrl ? `<img src="${E(b.iconUrl)}" alt="Current icon">` : '<span class="muted">Using default icon</span>'}</div><input type="file" id="br-icon" accept="image/png,image/jpeg,image/webp,image/gif,image/x-icon" aria-label="Upload icon">${b.iconUrl ? '<button type="button" class="btn" data-rm="icon">Remove icon</button>' : ''}<small class="muted">Square, 16–2048 px, up to 512 KB.</small></div></div>
      <h2>Colours</h2>${th.themes.length ? `<div class="btn-row" role="group" aria-label="Theme presets">${th.themes.map(t => `<button type="button" class="btn" data-preset="${E(JSON.stringify(t.colors))}">${E(t.name)}</button>`).join('')}</div>` : '<p class="muted">Install and enable the Hellenic Themes extension for ready-made presets.</p>'}
      <div class="fld-grid colors">${colorKeys.map(([k, l]) => field('c-' + k, l, `<span class="colorpair"><input type="color" id="c-${k}" value="${E(b.colors[k])}" data-color="${k}"><input aria-label="${E(l)} hex value" data-hex="${k}" value="${E(b.colors[k])}" maxlength="7" spellcheck="false"></span>`)).join('')}</div>
      <p class="muted">The server rejects combinations with unreadable contrast. Colours apply to the default dark theme; people who choose the Blue or White personal theme keep that palette.</p>
      <h2>Labels</h2><p class="muted">Change displayed names only. Leave blank for the default.</p><div class="fld-grid labels">${labelKeys.map(k => field('lb-' + k, b.defaultLabels[k], `<input id="lb-${k}" data-label="${k}" maxlength="40" placeholder="${E(b.defaultLabels[k])}" value="${E(b.labels[k] || '')}">`)).join('')}</div>
      <h2>Support links &amp; footer</h2><div id="linkRows">${(b.links || []).filter(l => !l.fromExtension).map(linkRow).join('')}</div><button type="button" class="btn" id="addLink">Add link</button>
      <div class="fld">${field('br-foot', 'Footer text', `<input id="br-foot" maxlength="200" value="${E(b.footer)}">`)}</div>
      <div class="btn-row"><button class="btn blue" type="submit">Save branding</button><button type="button" class="btn red" id="brReset">Reset to defaults</button></div><div id="brErr" role="alert" class="error-text"></div></form>`;
    $$('[data-color]').forEach(i => i.addEventListener('input', () => { $1(`[data-hex="${i.dataset.color}"]`).value = i.value; }));
    $$('[data-hex]').forEach(i => i.addEventListener('input', () => { if (/^#[0-9a-f]{6}$/i.test(i.value)) $1(`[data-color="${i.dataset.hex}"]`).value = i.value; }));
    $$('[data-preset]').forEach(t => t.onclick = () => { const c = JSON.parse(t.dataset.preset); for (const [k, v] of Object.entries(c)) { const h = $1(`[data-hex="${k}"]`); if (h) { h.value = v; $1(`[data-color="${k}"]`).value = v; } } toast('Preset loaded. Save to apply.'); });
    $1('#addLink').onclick = () => { $1('#linkRows').insertAdjacentHTML('beforeend', linkRow()); $1('#linkRows .link-row:last-child input').focus(); };
    $1('#linkRows').addEventListener('click', e => { if (e.target.closest('[data-rmlink]')) e.target.closest('.link-row').remove(); });
    const readFile = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('Could not read that file.')); r.readAsDataURL(f); });
    for (const kind of ['logo', 'icon']) $1('#br-' + kind).addEventListener('change', ev => run(null, async () => { const f = ev.target.files[0]; if (!f) return; await apiX(`/api/branding/asset/${kind}`, { method: 'PUT', body: JSON.stringify({ data: await readFile(f) }) }); await loadBranding(); toast('Image updated.'); window.navigate('branding'); }));
    $$('[data-rm]').forEach(b2 => b2.onclick = () => run(b2, async () => { await apiX(`/api/branding/asset/${b2.dataset.rm}`, { method: 'DELETE' }); await loadBranding(); window.navigate('branding'); }));
    $1('#brReset').onclick = e => run(e.target, async () => { if (!await confirmDialog('Reset branding?', '<p>Name, colours, labels, links, footer, logo and icon return to the defaults.</p>', 'Reset', 'red')) return; await apiX('/api/branding/reset', { method: 'POST' }); await loadBranding(); window.navigate('branding'); });
    $1('#brForm').addEventListener('submit', e => { e.preventDefault(); run(e.submitter, async () => {
      $1('#brErr').textContent = '';
      const colors = Object.fromEntries($$('[data-hex]').map(i => [i.dataset.hex, i.value.trim()])), labels = Object.fromEntries($$('[data-label]').map(i => [i.dataset.label, i.value.trim()]));
      const links = $$('.link-row').map(r => { const [a, u, p] = $$('input,select', r); return { label: a.value.trim(), url: u.value.trim(), placement: p.value }; }).filter(l => l.label || l.url);
      try { await apiX('/api/branding', { method: 'PUT', body: JSON.stringify({ name: $1('#br-name').value, shortName: $1('#br-short').value, colors, labels, links, footer: $1('#br-foot').value }) }); await loadBranding(); toast('Branding saved.'); }
      catch (err) { $1('#brErr').textContent = err.message; $1('#brErr').scrollIntoView({ block: 'nearest' }); }
    }); });
  };

  // =============== Plugin manager (replaces the old plugins page) ===============
  const SRC = { modrinth: 'Modrinth', upload: 'Manual upload' };
  const compatChip = c => badge({ compatible: 'Compatible', warning: 'Check notes', incompatible: 'Incompatible', unknown: 'Unknown' }[c.status], { compatible: 'ok', warning: 'warn', incompatible: 'bad', unknown: '' }[c.status]);
  window.renderPlugins = async function () {
    const id = state.current; if (!id) return;
    pageTitle('Plugins', state.servers[id]?.label || id);
    const root = $1('#content'); root.innerHTML = loadingHtml('Loading plugins…');
    let m;
    try { m = await apiX(`/api/plugins/${encodeURIComponent(id)}/manager`); } catch (e) { root.innerHTML = errorHtml(e.message, true); $1('[data-retry]', root).onclick = window.renderPlugins; return; }
    const base = `/api/plugins/${encodeURIComponent(id)}`, label = state.servers[id]?.label || id, admin = m.admin;
    const head = `<div class="card panel"><div class="toolbar"><div><h2 style="margin:0">Plugins · ${E(label)}</h2><span class="muted">${E(m.software.name)}${m.software.version ? ' ' + E(m.software.version) : ''}</span> ${m.software.via === 'detected' ? badge(`Detected (${m.software.confidence} confidence)`, 'info') : m.software.via === 'recorded' ? badge('Known', 'ok') : ''}</div><button class="btn" id="pgBack">← Server</button></div></div>`;
    const back = () => { $1('#pgBack').onclick = () => openPage(id); };
    if (m.supported === false) { root.innerHTML = head + `<div class="card panel"><h3>Plugins aren’t available for this server</h3><p>${E(m.reason)}</p><p class="muted">Plugin management only appears for server software that can load plugins.</p></div>`; return back(); }
    if (m.supported === null) {
      root.innerHTML = head + `<div class="card panel"><h3>Which software does this server run?</h3><p>${E(m.reason)} Choosing it unlocks plugin management and lets the panel check compatibility.</p>${admin ? `<form id="pgSw" class="fld-grid">${field('pg-sw', 'Software', `<select id="pg-sw">${m.choices.map(c => `<option value="${E(c.id)}">${E(c.name)}</option>`).join('')}</select>`)}${field('pg-ver', 'Minecraft version', '<input id="pg-ver" placeholder="e.g. 1.21.11">')}<div class="btn-row wide"><button class="btn blue" type="submit">Save</button></div></form>` : '<p class="muted">Ask an administrator to set it.</p>'}</div>`; back();
      $1('#pgSw')?.addEventListener('submit', e => { e.preventDefault(); run(e.submitter, async () => { await apiX(base.replace('/plugins/', '/plugins/') + '/software', { method: 'PUT', body: JSON.stringify({ software: $1('#pg-sw').value, version: $1('#pg-ver').value.trim() || null }) }); window.renderPlugins(); }); }); return;
    }
    let tab = state.pluginTab || 'installed'; const updates = {};
    const fileRow = p => { const u = updates[p.file]; return `<tr class="${p.enabled ? '' : 'off'}"><td><b>${E(p.name)}</b> <small>${E(p.version || '')}</small><br><small class="muted">${E(p.file)} · ${bytes(p.size)}</small>${p.description ? `<br><small>${E(p.description.slice(0, 120))}</small>` : ''}</td>
      <td>${p.enabled ? badge('Enabled', 'ok') : badge('Disabled', 'warn')}</td><td>${compatChip(p.compat)}${p.compat.notes.map(n => `<br><small>${E(n)}</small>`).join('')}</td>
      <td>${p.source ? `${E(SRC[p.source.type] || p.source.type)} ${p.source.verified ? badge('hash verified', 'ok') : badge('unverified', 'warn')}` : badge('unknown origin', '')}${u ? (u.updateAvailable ? `<br>${badge(`Update ${E(u.latest.number)}`, 'info')}` : u.identified ? '<br><small class="muted">Up to date</small>' : '') : ''}</td>
      <td class="actions-cell">${admin ? `<button class="btn" data-tg="${E(p.file)}">${p.enabled ? 'Disable' : 'Enable'}</button>${u?.updateAvailable ? ` <button class="btn blue" data-upd="${E(p.file)}">Update</button>` : ''} <button class="btn red" data-rm="${E(p.file)}">Remove</button>` : ''}${p.dataDir ? ` <button class="btn" data-files="${E(p.dataDir)}">Files</button>` : ''}</td></tr>`; };
    const draw = () => {
      const restart = state.pluginRestart ? `<div class="card panel info-box" role="status">Plugin changes take effect after the server restarts. ${admin ? '<button class="btn" id="pgRestart">Restart now</button>' : ''}</div>` : '';
      const tabs = [['installed', `Installed (${m.plugins.length})`], ['find', 'Find plugins'], ['upload', 'Upload JAR'], ['recovery', `Recovery (${m.trash.length})`]].filter(t => admin || ['installed'].includes(t[0]));
      let body = '';
      if (tab === 'installed') body = `<div class="card panel"><div class="toolbar"><h3 style="margin:0">Installed plugins</h3>${admin ? '<button class="btn" id="pgCheck">Check for updates</button>' : ''}</div>${m.plugins.length ? `<div class="table-scroll"><table><thead><tr><th>Plugin</th><th>Status</th><th>Compatibility with ${E(m.software.name)}</th><th>Source</th><th></th></tr></thead><tbody>${m.plugins.map(fileRow).join('')}</tbody></table></div>` : '<p class="muted">No plugins installed yet. Use “Find plugins” or upload a JAR.</p>'}<p class="muted" id="pgNote"></p></div>`;
      if (tab === 'find') body = `<div class="card panel"><form id="pgSearch" class="toolbar" role="search"><label class="grow"><span class="sr-only">Search plugins</span><input id="pgQ" type="search" placeholder="Search Modrinth for ${E(m.software.name)} plugins…"></label><button class="btn blue" type="submit">Search</button></form><p class="muted">Showing only plugins built for ${E(m.loaders.join(', '))}${m.mcVersion ? ' and Minecraft ' + E(m.mcVersion) : ''}. Downloads are verified against Modrinth’s published SHA-512.</p><div id="pgResults" aria-live="polite"></div></div>`;
      if (tab === 'upload') body = `<div class="card panel"><h3>Upload a plugin JAR</h3><div class="warn-box">Manual uploads are <b>not verified</b>. Only upload plugins from sources you trust.</div><form id="pgUp"><label class="file-pick">Plugin JAR <input type="file" id="pgFile" accept=".jar" required></label><div id="pgUpFlags"></div><div class="btn-row"><button class="btn blue" type="submit">Upload &amp; check</button></div></form></div>`;
      if (tab === 'recovery') body = `<div class="card panel"><h3>Recently removed or replaced</h3>${m.trash.length ? `<div class="table-scroll"><table><thead><tr><th>File</th><th>Removed</th><th></th></tr></thead><tbody>${m.trash.map(t => `<tr><td>${E(t.file)}</td><td>${E(t.removedAt ? new Date(t.removedAt).toLocaleString() : '')}</td><td class="actions-cell"><button class="btn blue" data-restore="${E(t.trashFile)}">Restore</button> <button class="btn red" data-purge="${E(t.trashFile)}">Delete for good</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Nothing here. Removed or replaced plugins are kept so you can undo mistakes.</p>'}</div>`;
      root.innerHTML = head + restart + `<div class="tabs" role="tablist" aria-label="Plugin manager">${tabs.map(([k, l]) => `<button role="tab" class="btn ${k === tab ? 'blue' : ''}" aria-selected="${k === tab}" data-tab="${k}">${E(l)}</button>`).join('')}</div>` + body;
      wire();
    };
    const afterChange = async (r) => { if (r?.restartRequired) state.pluginRestart = true; m = await apiX(`${base}/manager`); draw(); };
    function wire() {
      back(); $$('[data-tab]').forEach(t => t.onclick = () => { tab = state.pluginTab = t.dataset.tab; draw(); });
      $1('#pgRestart')?.addEventListener('click', e => run(e.target, async () => { await act(id, 'restart'); state.pluginRestart = false; draw(); }));
      $$('[data-files]').forEach(b => b.onclick = () => openFiles(id, encodeURIComponent('plugins/' + b.dataset.files)));
      $$('[data-tg]').forEach(b => b.onclick = () => run(b, async () => { await apiX(`${base}/toggle`, { method: 'POST', body: JSON.stringify({ file: b.dataset.tg }) }); await afterChange({ restartRequired: true }); }));
      $$('[data-rm]').forEach(b => b.onclick = () => run(b, async () => { if (!await confirmDialog('Remove plugin?', `<p><b>${E(b.dataset.rm)}</b> will be moved to Recovery, where you can restore it.</p>`, 'Remove', 'red')) return; const r = await apiX(`${base}/remove`, { method: 'POST', body: JSON.stringify({ file: b.dataset.rm }) }); toast('Removed. You can restore it from Recovery.'); await afterChange(r); }));
      $$('[data-restore]').forEach(b => b.onclick = () => run(b, async () => { const r = await apiX(`${base}/restore`, { method: 'POST', body: JSON.stringify({ trashFile: b.dataset.restore }) }); toast('Restored ' + r.file); await afterChange(r); }));
      $$('[data-purge]').forEach(b => b.onclick = () => run(b, async () => { if (!await confirmDialog('Delete permanently?', '<p>This cannot be undone.</p>', 'Delete', 'red')) return; await apiX(`${base}/purge`, { method: 'POST', body: JSON.stringify({ trashFile: b.dataset.purge }) }); await afterChange(); }));
      $1('#pgCheck')?.addEventListener('click', e => run(e.target, async () => {
        const r = await apiX(`${base}/updates`); for (const k of Object.keys(updates)) delete updates[k]; for (const row of [...r.updates, ...m.plugins.map(p => ({ file: p.file, identified: !r.unidentified.includes(p.file) }))]) updates[row.file] = updates[row.file]?.updateAvailable ? updates[row.file] : row;
        draw(); $1('#pgNote').textContent = `${r.updates.length} update(s) available, ${r.upToDate} up to date, ${r.unidentified.length} not found on Modrinth. ${r.note}`;
      }));
      $$('[data-upd]').forEach(b => b.onclick = () => run(b, async () => { const u = updates[b.dataset.upd]; const r = await installVersion(u.latest.versionId, b.dataset.upd, u.latest.channel); if (r) await afterChange(r); }));
      $1('#pgSearch')?.addEventListener('submit', e => { e.preventDefault(); run(e.submitter, () => search()); });
      $1('#pgUp')?.addEventListener('submit', e => { e.preventDefault(); run(e.submitter, () => upload({})); });
    }
    async function installVersion(versionId, replace, channel, extra = {}) {
      if (channel && channel !== 'release' && !extra.acknowledgeUnstable) { if (!await confirmDialog('Pre-release version', `<p>This is a <b>${E(channel)}</b> build and may be unstable.</p>`, 'Install anyway')) return null; extra.acknowledgeUnstable = true; }
      try {
        const r = await apiX(`${base}/install-source`, { method: 'POST', body: JSON.stringify({ versionId, replace, ...extra }) });
        const notes = [...(r.warnings || []), ...(r.requiredDependencies?.length ? [`Requires: ${r.requiredDependencies.map(d => d.title || d.projectId).join(', ')} — install these too.`] : [])];
        toast(`${replace ? 'Updated' : 'Installed'} ${r.file}${r.verifiedWith ? ' (hash verified)' : ''}.` + (notes.length ? ' ' + notes.join(' ') : ''), notes.length ? 'warn' : 'info'); return r;
      } catch (err) {
        if (err.status === 409 && /confirm|incompatible|does not list/i.test(err.message) && !extra.allowIncompatible) { if (await confirmDialog('Possible problem', `<p>${E(err.message)}</p><p>Installing anyway may break the server.</p>`, 'Install anyway', 'red')) return installVersion(versionId, replace, null, { ...extra, allowIncompatible: true, acknowledgeUnstable: true }); return null; }
        throw err;
      }
    }
    async function search() {
      const box = $1('#pgResults'); box.innerHTML = loadingHtml('Searching…');
      try {
        const r = await apiX(`${base}/search?q=${encodeURIComponent($1('#pgQ').value)}`);
        box.innerHTML = r.hits.length ? r.hits.map(h => `<article class="hit"><div><b>${E(h.title)}</b> <small class="muted">by ${E(h.author)} · ${Number(h.downloads).toLocaleString()} downloads</small><p>${E(h.description)}</p><a href="${E(h.url)}" target="_blank" rel="noopener noreferrer">View on Modrinth</a></div><div><button class="btn blue" data-vers="${E(h.projectId)}" aria-expanded="false">Versions</button></div><div class="vers" id="v-${E(h.projectId)}" hidden></div></article>`).join('') : '<p class="muted">No matching plugins for this server software and version.</p>';
        $$('[data-vers]', box).forEach(b => b.onclick = () => run(b, async () => {
          const holder = $1('#v-' + b.dataset.vers); if (!holder.hidden) { holder.hidden = true; b.setAttribute('aria-expanded', 'false'); return; }
          const v = await apiX(`${base}/projects/${encodeURIComponent(b.dataset.vers)}/versions`);
          holder.innerHTML = v.versions.length ? v.versions.slice(0, 15).map(x => `<div class="ver"><span><b>${E(x.number)}</b> ${x.channel !== 'release' ? badge(x.channel, 'warn') : ''} <small class="muted">${E(new Date(x.published).toLocaleDateString())} · ${x.gameVersions.slice(-3).map(E).join(', ')}</small>${x.file?.verified ? ' ' + badge('hash listed', 'ok') : x.file ? ' ' + badge('no hash', 'warn') : ' ' + badge('no jar', 'bad')}</span>${x.file ? `<button class="btn" data-inst="${E(x.id)}" data-ch="${E(x.channel)}">Install</button>` : ''}</div>`).join('') : '<p class="muted">No version is published for this software and Minecraft version.</p>';
          holder.hidden = false; b.setAttribute('aria-expanded', 'true');
          $$('[data-inst]', holder).forEach(i => i.onclick = () => run(i, async () => { const r = await installVersion(i.dataset.inst, null, i.dataset.ch); if (r) { tab = state.pluginTab = 'installed'; await afterChange(r); } }));
        }));
      } catch (err) { box.innerHTML = errorHtml(err.message); }
    }
    async function upload(flags) {
      const f = $1('#pgFile').files[0]; if (!f) return; const fd = new FormData(); fd.append('plugin', f);
      const q = new URLSearchParams(flags).toString();
      try {
        const r = await apiX(`${base}/upload${q ? '?' + q : ''}`, { method: 'POST', body: fd });
        toast(`Uploaded ${r.file}. ${r.warnings.join(' ')}`, 'warn'); tab = state.pluginTab = 'installed'; await afterChange(r);
      } catch (err) {
        if (err.status === 409 && /already installed/.test(err.message)) { if (await confirmDialog('Replace existing plugin?', `<p>${E(err.message)}</p><p>The old file goes to Recovery.</p>`, 'Replace')) return upload({ ...flags, replace: f.name }); return; }
        if (err.status === 409 && !flags.allowIncompatible) { const unknown = /No plugin descriptor/.test(err.message); if (await confirmDialog(unknown ? 'Not recognised as a plugin' : 'Looks incompatible', `<p>${E(err.message)}</p>`, 'Install anyway', 'red')) return upload({ ...flags, [unknown ? 'allowUnrecognized' : 'allowIncompatible']: '1' }); return; }
        throw err;
      }
    }
    draw();
  };

  // Hide the Plugins button on the server page when the software cannot use plugins.
  const baseOpenPage = window.openPage;
  if (typeof baseOpenPage === 'function') window.openPage = async function (id) {
    const r = await baseOpenPage.apply(this, arguments);
    try { if (state.servers[id]?.pluginsSupported === false) $$('button[onclick^="openPlugins("]').forEach(b => b.remove()); } catch { /* cosmetic */ }
    return r;
  };
})();
