/* Hellenic Network extension SDK. Include in a sandboxed extension page:  <script src="hn-sdk.js"></script>
   The page runs in an opaque-origin sandbox and can only reach the panel through hn.call(), which the panel
   permission-checks on the server for the signed-in user. Example:  const servers = await hn.call('servers.list'); */
(function () {
  'use strict';
  let seq = 0; const waiting = new Map(); let ctx = {}; let resolveReady; const ready = new Promise(r => { resolveReady = r; });
  addEventListener('message', ev => {
    if (ev.source !== parent) return;
    const m = ev.data; if (!m || m.hn !== 1) return;
    if (m.type === 'context') { ctx = m.context || {}; applyTokens(ctx.tokens); document.documentElement.lang = ctx.lang || 'en'; document.documentElement.dir = ctx.dir || 'ltr'; resolveReady(ctx); return; }
    const w = waiting.get(m.id); if (!w) return; waiting.delete(m.id);
    m.ok ? w.resolve(m.result) : w.reject(Object.assign(new Error(m.error || 'Request failed'), { status: m.status }));
  });
  function applyTokens(t) { if (t) for (const [k, v] of Object.entries(t)) document.documentElement.style.setProperty(k, v); }
  function call(capability, args) {
    return new Promise((resolve, reject) => {
      const id = ++seq; waiting.set(id, { resolve, reject });
      parent.postMessage({ hn: 1, type: 'call', id, capability, args: args || {} }, '*');
      setTimeout(() => { if (waiting.delete(id)) reject(new Error('The panel did not respond.')); }, 30000);
    });
  }
  const t = (key, fallback) => (ctx.messages && ctx.messages[key]) || fallback || key;
  window.hn = { ready, call, t, get context() { return ctx; }, resize(h) { parent.postMessage({ hn: 1, type: 'resize', height: Math.max(100, Math.min(3000, Number(h) || 0)) }, '*'); } };
  parent.postMessage({ hn: 1, type: 'hello' }, '*');
})();
