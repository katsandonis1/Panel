/* server.properties editor. Loaded after platform-manage.js. */
(function () {
  'use strict';
  const { toast, run, apiX, badge, loadingHtml, errorHtml, pageTitle, $$, $1, confirmDialog } = window.__bp;
  const E = s => esc(s);

  window.openProperties = id => { state.current = id; state.page = id; window.renderProperties(); };
  window.renderProperties = async function () {
    const id = state.current; if (!id) return;
    const root = $1('#content'), label = state.servers[id]?.label || id;
    pageTitle('Server properties', label); root.innerHTML = loadingHtml('Loading server.properties…');
    let d;
    try { d = await apiX(`/api/properties/${encodeURIComponent(id)}`); } catch (e) { root.innerHTML = errorHtml(e.message, true); $1('[data-retry]', root).onclick = window.renderProperties; return; }
    const orig = {}, cur = {}, fields = new Map(d.schema.map(f => [f.key, f]));
    for (const f of d.schema) { const v = f.type === 'secret' ? '' : (d.values[f.key] ?? null); orig[f.key] = v; cur[f.key] = v; }
    const others = Object.keys(d.values).filter(k => !fields.has(k)).sort(); for (const k of others) { orig[k] = d.values[k]; cur[k] = d.values[k]; }
    const added = {}; // brand-new custom keys
    const effective = f => cur[f.key] ?? String(f.default);
    const isDirty = k => (k in added) ? added[k] !== '' : String(cur[k] ?? '') !== String(orig[k] ?? '');
    const dirtyKeys = () => [...Object.keys(cur), ...Object.keys(added)].filter(isDirty);
    const setDirtyFlag = () => { if (typeof editorDirty !== 'undefined') editorDirty = dirtyKeys().length > 0; };

    function control(f) {
      const id2 = 'pp-' + f.key.replace(/[^A-Za-z0-9]/g, '_'), v = effective(f), set = d.exists && d.values[f.key] !== undefined;
      const ro = d.canEdit ? '' : 'disabled';
      if (f.type === 'bool') return `<label class="switch"><input type="checkbox" id="${id2}" data-k="${E(f.key)}" ${v === 'true' ? 'checked' : ''} ${ro}> <span>${v === 'true' ? 'On' : 'Off'}</span></label>`;
      if (f.type === 'enum') return `<select id="${id2}" data-k="${E(f.key)}" ${ro}>${f.options.map(o => `<option ${o === v ? 'selected' : ''}>${E(o)}</option>`).join('')}</select>`;
      if (f.type === 'int') return `<input id="${id2}" data-k="${E(f.key)}" type="number" inputmode="numeric" step="1" min="${E(f.min)}" max="${E(f.max)}" value="${E(v)}" ${ro}>`;
      if (f.type === 'secret') return `<input id="${id2}" data-k="${E(f.key)}" type="password" autocomplete="new-password" placeholder="${d.secretsSet[f.key] ? '•••••• (set — leave blank to keep)' : 'not set'}" ${ro}>`;
      return `<input id="${id2}" data-k="${E(f.key)}" type="text" value="${E(v)}" maxlength="${f.max || 2000}" spellcheck="false" ${ro}>`;
    }
    const fieldHtml = f => { const id2 = 'pp-' + f.key.replace(/[^A-Za-z0-9]/g, '_');
      return `<div class="pp-field" data-field="${E(f.key)}" data-text="${E((f.label + ' ' + f.key + ' ' + f.help).toLowerCase())}"><label for="${id2}">${E(f.label)}${f.danger ? ' ' + badge('sensitive', 'warn') : ''}<code>${E(f.key)}</code></label>${control(f)}${f.help ? `<small class="muted" id="${id2}-h">${E(f.help)}</small>` : ''}<small class="pp-err error-text" role="alert"></small><div class="pp-meta"><span class="muted">Default: ${f.type === 'secret' ? '—' : E(f.default === '' ? '(empty)' : f.default)}</span> <button type="button" class="btn pp-reset" data-reset="${E(f.key)}" hidden>Reset to default</button> <span class="pp-mod" hidden>${badge('changed', 'info')}</span></div></div>`; };

    function draw() {
      const byGroup = {}; for (const f of d.schema) (byGroup[f.group] ||= []).push(f);
      root.innerHTML = `<div class="card panel"><div class="toolbar"><div><h2 style="margin:0">Server properties · ${E(label)}</h2><span class="muted">${d.exists ? 'Edits keep your comments, order and unknown settings. A backup is made on every save.' : 'No server.properties yet — it is created when you save, or when the server first starts.'}</span></div><button class="btn" id="ppBack">← Server</button></div>
        ${d.running ? '<div class="info-box" role="status">This server is running. Changes are saved now but only take effect after a restart.</div>' : ''}
        ${d.canEdit ? '' : '<div class="warn-box">You can view these settings but do not have permission to change them.</div>'}
        <div class="toolbar"><label class="grow"><span class="sr-only">Search settings</span><input id="ppSearch" type="search" placeholder="Search settings (e.g. difficulty, port, view distance)…" autocomplete="off"></label><label class="chk"><input type="checkbox" id="ppOnlyChanged"> Only changed</label></div></div>
        ${Object.keys(d.groups).filter(g => byGroup[g]).map(g => `<details class="card panel pp-group" open data-group="${g}"><summary><h3 style="display:inline">${E(d.groups[g])}</h3> <span class="muted pp-count"></span></summary><div class="fld-grid pp-grid">${byGroup[g].map(fieldHtml).join('')}</div></details>`).join('')}
        <details class="card panel pp-group" ${others.length ? 'open' : ''} data-group="other"><summary><h3 style="display:inline">Other settings</h3> <span class="muted">Not in the built-in list (mods, plugins, newer versions)</span></summary>
          <div class="fld-grid pp-grid">${others.map(k => `<div class="pp-field" data-field="${E(k)}" data-text="${E(k.toLowerCase())}" data-other="1"><label for="po-${E(k)}"><code>${E(k)}</code></label><input id="po-${E(k)}" data-k="${E(k)}" data-other-input type="text" value="${E(cur[k])}" maxlength="2000" spellcheck="false" ${d.canEdit ? '' : 'disabled'}><small class="pp-err error-text" role="alert"></small><div class="pp-meta"><span class="pp-mod" hidden>${badge('changed', 'info')}</span></div></div>`).join('') || '<p class="muted">None.</p>'}</div>
          ${d.canEdit ? `<form id="ppAdd" class="link-row" style="grid-template-columns:1fr 1fr auto"><input aria-label="New setting name" placeholder="setting-name" maxlength="64" id="ppAddK"><input aria-label="New setting value" placeholder="value" maxlength="2000" id="ppAddV"><button class="btn" type="submit">Add</button></form><small class="pp-err error-text" id="ppAddErr" role="alert"></small><div id="ppAdded"></div>` : ''}</details>
        <div class="pp-bar card" id="ppBar" hidden role="region" aria-label="Unsaved changes"><span id="ppCount" role="status"></span><span class="grow"></span><button class="btn" id="ppDiscard" type="button">Discard</button><button class="btn blue" id="ppSave" type="button">Save changes</button></div>`;
      wire();
    }
    function refreshUi() {
      $$('.pp-field', root).forEach(el => { const k = el.dataset.field, f = fields.get(k), dirty = isDirty(k); el.classList.toggle('dirty', dirty); const m = $1('.pp-mod', el); if (m) m.hidden = !dirty; const r = $1('.pp-reset', el); if (r && f) r.hidden = !(f.type !== 'secret' && effective(f) !== String(f.default)); const sw = $1('.switch span', el); if (sw && f) sw.textContent = effective(f) === 'true' ? 'On' : 'Off'; });
      const n = dirtyKeys().length, bar = $1('#ppBar'); if (bar) { bar.hidden = n === 0 || !d.canEdit; $1('#ppCount').textContent = `${n} unsaved change${n === 1 ? '' : 's'}`; }
      setDirtyFlag(); filter();
    }
    function filter() {
      const q = ($1('#ppSearch')?.value || '').trim().toLowerCase(), only = $1('#ppOnlyChanged')?.checked;
      $$('.pp-field', root).forEach(el => { el.hidden = !!((q && !el.dataset.text.includes(q)) || (only && !isDirty(el.dataset.field))); });
      $$('.pp-group', root).forEach(g => { const vis = $$('.pp-field', g).filter(x => !x.hidden).length; g.hidden = (q || only) && !vis && g.dataset.group !== 'other' ? true : (q || only) && !vis && !$1('#ppAdd', g); });
    }
    function wire() {
      $1('#ppBack').onclick = () => openPage(id);
      $1('#ppSearch').addEventListener('input', filter); $1('#ppOnlyChanged').addEventListener('change', filter);
      root.addEventListener('input', onEdit); root.addEventListener('change', onEdit);
      function onEdit(ev) {
        const t = ev.target, k = t.dataset?.k; if (!k) return;
        cur[k] = t.type === 'checkbox' ? String(t.checked) : t.value;
        const f = fields.get(k); if (f?.type === 'secret') { orig[k] = ''; }
        refreshUi();
      }
      $$('[data-reset]').forEach(b => b.onclick = () => { const f = fields.get(b.dataset.reset), el = $1(`[data-k="${CSS.escape(f.key)}"]`); cur[f.key] = String(f.default); if (el.type === 'checkbox') el.checked = f.default === true || f.default === 'true'; else el.value = f.default; refreshUi(); });
      $1('#ppDiscard')?.addEventListener('click', () => { for (const k of Object.keys(added)) delete added[k]; window.renderProperties(); setDirtyFlag(); });
      $1('#ppAdd')?.addEventListener('submit', ev => { ev.preventDefault(); const k = $1('#ppAddK').value.trim(), v = $1('#ppAddV').value, err = $1('#ppAddErr'); err.textContent = '';
        if (!/^[A-Za-z0-9._-]{1,64}$/.test(k)) { err.textContent = 'Use letters, numbers, dots, dashes and underscores (max 64).'; return; }
        if (fields.has(k) || k in cur || k in added) { err.textContent = 'That setting already exists above.'; return; }
        added[k] = v; $1('#ppAdded').insertAdjacentHTML('beforeend', `<p class="muted">＋ <code>${E(k)}</code> = ${E(v)}</p>`); $1('#ppAddK').value = ''; $1('#ppAddV').value = ''; refreshUi(); });
      $1('#ppSave')?.addEventListener('click', e => run(e.target, async () => {
        const changes = {}; for (const k of dirtyKeys()) changes[k] = (k in added) ? added[k] : cur[k];
        $$('.pp-err', root).forEach(x => { x.textContent = ''; });
        if (changes['online-mode'] === 'false' && orig['online-mode'] !== 'false' && !await confirmDialog('Turn off online mode?', '<p>With online mode off, <b>anyone can join using any name</b>, including an operator’s. Only do this behind a trusted proxy such as Velocity, or for offline play.</p>', 'Turn it off', 'red')) return;
        try {
          const r = await apiX(`/api/properties/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify({ etag: d.etag, changes }) });
          toast(r.changed.length ? `Saved ${r.changed.length} setting${r.changed.length === 1 ? '' : 's'}.${r.restartRequired ? ' Restart the server to apply.' : ''}${r.notes?.length ? ' ' + r.notes.join(' ') : ''}` : r.notes.join(' '), r.notes?.length ? 'warn' : 'info');
          if (typeof editorDirty !== 'undefined') editorDirty = false; window.renderProperties();
        } catch (err) {
          for (const [k, m] of Object.entries(err.data?.errors || {})) { const el = $1(`.pp-field[data-field="${CSS.escape(k)}"] .pp-err`); if (el) { el.textContent = m; el.closest('.pp-field').scrollIntoView({ block: 'center' }); } }
          throw err;
        }
      }));
      refreshUi();
    }
    draw();
  };

  // Add a "Properties" button next to "Files" on each backend server's page.
  const baseOpenPage = window.openPage;
  window.openPage = async function (id) {
    const r = await baseOpenPage.apply(this, arguments);
    try {
      const files = $1('#content button[onclick^="openFiles("]');
      if (files && !state.servers[id]?.proxy && !$1('#content [data-props-btn]')) { const b = document.createElement('button'); b.className = 'btn'; b.type = 'button'; b.dataset.propsBtn = '1'; b.textContent = 'Properties'; b.onclick = () => window.openProperties(id); files.after(b); }
    } catch { /* cosmetic */ }
    return r;
  };
})();
