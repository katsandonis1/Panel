'use strict';
// Interactive setup for Hellenic Network.
//   npm run setup                 guided setup (detects your environment, previews changes, backs up config.json)
//   npm run setup -- --check      read-only environment report (works without a terminal; exit code 1 on problems)
//   npm run setup -- --dry-run    go through the questions and show what would change, but write nothing
//   npm run setup -- --rollback   restore the most recent config.json backup
//   npm run setup -- --reset-admin  choose a new administrator password
//   npm run setup -- --yes        apply without the final confirmation question
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');
const crypto = require('crypto');
const { inspectEnvironment, isPortFree, suggestMemoryGB } = require('../lib/environment');

const root = process.env.PANEL_ROOT ? path.resolve(process.env.PANEL_ROOT) : path.resolve(__dirname, '..');
const example = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.example.json'), 'utf8'));
const target = path.join(root, 'config.json');
const args = new Set(process.argv.slice(2));
const flags = { install: args.has('--install'), resetAdmin: args.has('--reset-admin'), check: args.has('--check'), dryRun: args.has('--dry-run'), rollback: args.has('--rollback'), yes: args.has('--yes') };
const KEEP_BACKUPS = 5;

const resolveConfiguredPath = value => { const t = String(value || '').trim(); return path.isAbsolute(t) ? path.resolve(t) : path.resolve(root, t); };
function isInside(parent, child) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel));
}
function plainError(e) {
  if (e?.code === 'EACCES' || e?.code === 'EPERM') return `Permission denied (${e.path || 'a file'}). Run setup as the user that will run the panel, or grant that user write access.`;
  if (e?.code === 'ENOSPC') return 'The disk is full.';
  if (e?.code === 'ENOENT') return `A required file or folder is missing (${e.path || ''}).`;
  return e?.message || String(e);
}

async function checkDirectoryPath(label, value, { mustExist = false, absolute = false, optional = false } = {}) {
  if (optional && !String(value || '').trim()) return '';
  if (!value || !String(value).trim()) throw new Error(`${label} cannot be empty.`);
  if (absolute && !path.isAbsolute(value)) throw new Error(`${label} must be an absolute path (for example /mnt/backup).`);
  const resolved = resolveConfiguredPath(value);
  let probe = resolved;
  while (!fs.existsSync(probe) && path.dirname(probe) !== probe) probe = path.dirname(probe);
  const stat = await fs.promises.stat(probe).catch(() => null);
  if (!stat?.isDirectory()) throw new Error(`${label} is not in an accessible folder: ${resolved}`);
  await fs.promises.access(probe, fs.constants.R_OK | fs.constants.W_OK).catch(() => { throw new Error(`The panel cannot read and write the folder containing ${label}: ${probe}. Grant write access to ${os.userInfo().username}.`); });
  if (mustExist) {
    const exact = await fs.promises.stat(resolved).catch(() => null);
    if (!exact?.isDirectory()) throw new Error(`${label} folder does not exist: ${resolved}. Create it first (mkdir -p "${resolved}") or enter another folder.`);
    await fs.promises.access(resolved, fs.constants.R_OK | fs.constants.W_OK).catch(() => { throw new Error(`The panel cannot read and write ${label}: ${resolved}`); });
  }
  return String(value).trim();
}
const hasUsableUser = c => Array.isArray(c.auth?.users) ? c.auth.users.some(u => u?.username && u?.passwordHash) : Boolean(c.auth?.username && c.auth?.passwordHash);
function findServerForRole(servers, role) {
  const pattern = role === 'proxy' ? /\b(proxy|velocity|bungee(?:cord)?|waterfall)\b/i : /\b(hub|lobby)\b/i;
  return Object.entries(servers).find(([id, s]) => pattern.test([id, s?.label, s?.type, s?.command, ...(s?.args || [])].join(' ')));
}

// ---- backups & rollback ----
async function backupConfig(file = target) {
  if (!fs.existsSync(file)) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-'), dest = `${file}.bak-${stamp}`;
  await fs.promises.copyFile(file, dest, fs.constants.COPYFILE_EXCL);
  await fs.promises.chmod(dest, 0o600).catch(() => {});
  const all = (await fs.promises.readdir(path.dirname(file))).filter(n => n.startsWith(path.basename(file) + '.bak-')).sort();
  for (const old of all.slice(0, Math.max(0, all.length - KEEP_BACKUPS))) await fs.promises.rm(path.join(path.dirname(file), old), { force: true });
  return dest;
}
async function rollbackConfig(file = target) {
  const dir = path.dirname(file), list = (await fs.promises.readdir(dir)).filter(n => n.startsWith(path.basename(file) + '.bak-')).sort();
  if (!list.length) throw new Error('There is no config.json backup to restore.');
  const latest = path.join(dir, list[list.length - 1]);
  JSON.parse(await fs.promises.readFile(latest, 'utf8')); // refuse to restore a damaged backup
  const safety = fs.existsSync(file) ? await backupConfig(file) : null; // keep what is being replaced
  const tmp = `${file}.tmp-${crypto.randomUUID()}`;
  await fs.promises.copyFile(latest, tmp); await fs.promises.rename(tmp, file);
  return { restored: latest, safety };
}
async function writeConfigAtomic(config, file = target) {
  const tmp = `${file}.tmp-${crypto.randomUUID()}`;
  await fs.promises.writeFile(tmp, JSON.stringify(config, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  await fs.promises.rename(tmp, file);
}

// ---- change preview ----
const clone = x => JSON.parse(JSON.stringify(x));
function planChanges(before, after) {
  const rows = [], b = before || {}, a = after;
  const add = (what, from, to) => { if (JSON.stringify(from) !== JSON.stringify(to)) rows.push({ what, from: from === undefined || from === '' ? '(not set)' : from, to: to === undefined || to === '' ? '(not set)' : to }); };
  add('Minecraft network folder', b.networkRoot, a.networkRoot);
  add('Panel address', b.panel && `${b.panel.host}:${b.panel.port}`, `${a.panel.host}:${a.panel.port}`);
  add('Backup disk mount (optional check)', b.backupMount, a.backupMount);
  add('Backup destination', b.backupDirectory, a.backupDirectory);
  for (const [id, s] of Object.entries(a.servers || {})) add(`Server folder for “${s.label || id}”`, b.servers?.[id]?.cwd, s.cwd);
  const names = c => (c?.auth?.users || []).map(u => u.username).join(', ') || c?.auth?.username;
  add('Administrator account', names(b), names(a));
  const hashes = c => (c?.auth?.users || []).map(u => u.passwordHash).join('|');
  if (b.auth && hashes(b) !== hashes(a)) rows.push({ what: 'Administrator password', from: '(current)', to: '(changed)' });
  if (!before) rows.push({ what: 'config.json', from: '(does not exist)', to: 'will be created' });
  return rows;
}

function printReport(report) {
  const icon = { ok: '✔', warn: '▲', fail: '✖', info: 'ℹ' };
  for (const c of report.checks) { console.log(` ${icon[c.status] || '-'} ${c.label}: ${c.detail}`); if (c.fix && c.status !== 'ok') console.log(`     → ${c.fix}`); }
}

async function runCheck() {
  const config = fs.existsSync(target) ? JSON.parse(fs.readFileSync(target, 'utf8')) : null;
  const report = await inspectEnvironment({ root, config, panelPort: config?.panel?.port ? Number(config.panel.port) : null });
  console.log('\nHellenic Network · environment check\n'); printReport(report);
  console.log(`\nResult: ${report.overall === 'ok' ? 'everything looks good' : report.overall === 'warn' ? 'usable, with warnings above' : 'problems found (see the → hints above)'}\n`);
  process.exitCode = report.overall === 'fail' ? 1 : 0;
}

async function main() {
  if (flags.check) return runCheck();
  if (flags.rollback) {
    const r = await rollbackConfig();
    console.log(`\nRestored ${path.basename(r.restored)} as config.json.${r.safety ? ` The replaced file was kept as ${path.basename(r.safety)}.` : ''}\nRestart the panel for the change to take effect.\n`);
    return;
  }
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    const message = 'Interactive setup was skipped because this install has no terminal. Run `npm run setup` in a terminal to choose the folders (or `npm run setup -- --check` for a read-only report).';
    if (flags.install) { console.log(`\n${message}\n`); return; }
    throw new Error(message);
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  const ask = q => new Promise(resolve => rl.question(q, resolve));
  const askSecret = q => new Promise(resolve => { const write = rl._writeToOutput; rl._writeToOutput = s => { if (s.includes(q)) write.call(rl, s); else write.call(rl, s.replace(/[^\r\n]/g, '*')); }; rl.question(q, a => { rl._writeToOutput = write; process.stdout.write('\n'); resolve(a); }); });
  const askYesNo = async (q, def = true) => { const a = (await ask(`${q} [${def ? 'Y/n' : 'y/N'}]: `)).trim().toLowerCase(); return a ? a.startsWith('y') : def; };
  const askDirectory = async (label, current, options) => {
    for (;;) {
      const value = (await ask(`${label}${current ? ` [${current}]` : ''}: `)).trim() || current;
      try { return await checkDirectoryPath(label, value, options); } catch (e) { console.log(`  ${e.message}`); }
    }
  };

  try {
    const existing = fs.existsSync(target) ? JSON.parse(fs.readFileSync(target, 'utf8')) : null;
    const config = existing ? clone(existing) : clone(example);
    config.panel ||= clone(example.panel); config.auth ||= {}; config.servers ||= {};

    console.log('\nHellenic Network setup · press Enter to keep each value shown in [brackets].\n');
    console.log('Detecting your environment…\n');
    const report = await inspectEnvironment({ root, config: existing });
    printReport(report);
    if (report.overall === 'fail') console.log('\nSome checks failed. You can continue, but the panel may not work until they are fixed.');
    if (!(await askYesNo('\nContinue with setup?'))) { console.log('Nothing was changed.'); return; }
    console.log(existing ? '\nAn existing config.json was found. Your current values are offered as defaults; a backup is made before anything is written.\n' : '\nNo config.json yet; one will be created.\n');

    const sensibleNetwork = config.networkRoot || example.networkRoot || '../MinecraftNetwork';
    config.networkRoot = await askDirectory('Minecraft network folder', sensibleNetwork, { mustExist: true });

    // Panel address/port: keep, but make sure the default is actually free for a first setup.
    let port = Number(config.panel.port) || 25564;
    if (!existing && !(await isPortFree(port))) { for (let p = port + 1; p < port + 50; p++) if (await isPortFree(p)) { console.log(`Port ${port} is in use on this machine; suggesting ${p}.`); port = p; break; } }
    for (;;) { const a = (await ask(`Panel port [${port}]: `)).trim(); const n = a ? Number(a) : port; if (Number.isInteger(n) && n >= 1 && n <= 65535) { config.panel.port = n; break; } console.log('  Enter a whole number from 1 to 65535.'); }
    config.panel.host ||= '0.0.0.0';

    for (const role of [{ id: 'proxy', label: 'Proxy' }, { id: 'hub', label: 'Hub' }]) {
      const match = findServerForRole(config.servers, role.id);
      if (!match) continue;
      match[1].cwd = await askDirectory(`${role.label} server folder`, match[1].cwd || config.networkRoot, { mustExist: true });
    }

    const defaultBackup = config.backupDirectory || path.join(path.dirname(resolveConfiguredPath(config.networkRoot)), 'MinecraftBackups');
    const useMount = await askYesNo('Do backups go to a separate disk that must be mounted (for example a USB or network drive)?', !!config.backupMount);
    config.backupMount = useMount ? await askDirectory('Backup disk mount folder', config.backupMount || '', { absolute: true, mustExist: process.platform === 'linux' }) : '';
    config.backupDirectory = await askDirectory('Backup destination folder', defaultBackup, {});

    const networkPath = resolveConfiguredPath(config.networkRoot), backupPath = resolveConfiguredPath(config.backupDirectory);
    if (isInside(networkPath, backupPath)) throw new Error('The backup destination must be outside the Minecraft network folder.');
    if (config.backupMount && process.platform === 'linux' && !isInside(resolveConfiguredPath(config.backupMount), backupPath)) throw new Error('The backup destination must be inside the selected backup disk mount folder.');
    for (const [id, s] of Object.entries(config.servers)) if (isInside(resolveConfiguredPath(s.cwd), backupPath)) throw new Error(`The backup destination cannot be inside the server folder “${s.label || id}”.`);

    if (flags.resetAdmin || !hasUsableUser(config)) {
      if (flags.resetAdmin && hasUsableUser(config) && !(await askYesNo('This replaces the administrator password. Continue?', false))) throw new Error('Cancelled; the administrator password was not changed.');
      const bcrypt = require('bcryptjs');
      const defaultUsername = config.auth.users?.find(u => u?.role === 'admin')?.username || config.auth.username || example.auth.username || 'admin';
      const username = (await ask(`Panel admin username [${defaultUsername}]: `)).trim() || defaultUsername;
      if (!/^[A-Za-z0-9._-]{2,32}$/.test(username)) throw new Error('Usernames may use letters, numbers, . _ - (2–32 characters).');
      let password = '';
      while (password.length < 8) { password = await askSecret('Panel admin password (minimum 8 characters, hidden): '); if (password.length < 8) console.log('  Password must be at least 8 characters.'); }
      const confirm = await askSecret('Repeat the password: ');
      if (confirm !== password) throw new Error('The passwords did not match; nothing was saved. Run setup again.');
      const passwordHash = await bcrypt.hash(password, 12);
      const old = Array.isArray(config.auth.users) ? config.auth.users : [];
      config.auth.users = [{ username, passwordHash, role: 'admin' }, ...old.filter(u => u?.username !== username)];
      delete config.auth.username; delete config.auth.passwordHash;
    }

    const rows = planChanges(existing, config);
    console.log('\nPlanned changes:');
    if (!rows.length) console.log('  (none — everything already matches)');
    for (const r of rows) console.log(`  • ${r.what}: ${r.from} → ${r.to}`);
    if (flags.dryRun) { console.log('\nDry run: nothing was written.\n'); return; }
    if (!rows.length) { console.log('\nNothing to do.\n'); return; }
    if (!flags.yes && !(await askYesNo('\nApply these changes?'))) { console.log('Nothing was changed.'); return; }

    const backup = await backupConfig();
    try { await writeConfigAtomic(config); }
    catch (e) { console.log(`\nCould not save config.json: ${plainError(e)}`); if (backup) console.log(`Your previous configuration is unchanged (backup: ${path.basename(backup)}).`); process.exitCode = 1; return; }
    console.log(`\nSaved ${target}${backup ? `\nPrevious version backed up as ${path.basename(backup)} (restore with: npm run setup -- --rollback)` : ''}`);
    console.log('Run `npm start` to launch the panel. Run `npm run setup` any time to review these choices.\n');
  } finally { rl.close(); }
}

if (require.main === module) main().catch(e => { console.error(`Setup failed: ${plainError(e)}`); process.exitCode = 1; });
module.exports = { backupConfig, rollbackConfig, writeConfigAtomic, planChanges, checkDirectoryPath, isInside, suggestMemoryGB };
