#!/usr/bin/env node
'use strict';
// Extension developer tool.
//   node scripts/ext-tool.js create <id>        scaffold extensions-src/<id>
//   node scripts/ext-tool.js validate <dir>     validate a folder exactly like the panel does on upload
//   node scripts/ext-tool.js pack <dir> [out]   validate, then write <id>-<version>.hnx (+ .sha256)
//   node scripts/ext-tool.js dev <dir>          re-validate and re-pack whenever a file changes (upload the result in the panel)
//   node scripts/ext-tool.js build-examples     pack every folder in extensions-src/ into extensions-examples/
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { buildZip } = require('../lib/zip');
const { inspectPackage } = require('../lib/extensions');

const ROOT = path.resolve(__dirname, '..');
const PANEL_VERSION = require('../package.json').version;
const [cmd, arg, out] = process.argv.slice(2);
const die = m => { console.error(m); process.exit(1); };

function collect(dir) {
  const files = [];
  (function walk(d, rel) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      if (e.name.startsWith('.') || e.name === 'node_modules') continue;
      const p = path.join(d, e.name), r = rel ? `${rel}/${e.name}` : e.name;
      if (e.isSymbolicLink()) die(`Refusing symlink: ${r}`);
      if (e.isDirectory()) walk(p, r); else if (e.isFile() && r !== 'README.md.draft') files.push({ name: r, data: fs.readFileSync(p) });
    }
  })(dir, '');
  return files;
}
async function validate(dir) {
  if (!fs.existsSync(path.join(dir, 'extension.json'))) die(`No extension.json in ${dir}`);
  const buf = buildZip(collect(dir));
  try { const r = await inspectPackage(buf, PANEL_VERSION); return { buf, r }; }
  catch (e) { console.error(`✖ ${e.message}`); for (const d of e.details || []) console.error(`  - ${d}`); process.exit(1); }
}
async function pack(dir, outDir) {
  const { buf, r } = await validate(dir);
  if (r.format !== 'native' || r.support !== 'native') die(`✖ ${r.summary}`);
  const m = r.manifest; fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, `${m.id}-${m.version}.hnx`), sha = crypto.createHash('sha256').update(buf).digest('hex');
  fs.writeFileSync(file, buf); fs.writeFileSync(file + '.sha256', `${sha}  ${path.basename(file)}\n`);
  console.log(`✔ ${m.name} ${m.version} (API v${m.schemaVersion}) → ${path.relative(process.cwd(), file)}  sha256 ${sha.slice(0, 16)}…`);
  console.log(`  permissions: ${m.permissions.join(', ') || 'none'}`);
  return file;
}
(async () => {
  if (cmd === 'create') {
    if (!/^[a-z0-9][a-z0-9-]{1,31}$/.test(arg || '')) die('Usage: create <id>  (2–32 chars: lowercase letters, numbers, dashes)');
    const dir = path.join(ROOT, 'extensions-src', arg); if (fs.existsSync(dir)) die(`${dir} already exists.`);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'extension.json'), JSON.stringify({ schemaVersion: 2, id: arg, name: arg.replace(/-/g, ' ').replace(/^./, c => c.toUpperCase()), version: '0.1.0', description: 'Describe what this extension does.', author: '', license: 'MIT', panel: { min: '3.7.0' }, permissions: ['ui.pages', 'servers.read', 'servers.command'],
      pages: [{ id: 'main', title: 'Hello', icon: '★', placement: 'nav', permission: 'console_command', type: 'declarative', content: { type: 'stack', children: [{ type: 'heading', text: 'Hello from my extension' }, { type: 'serverPicker' }, { type: 'form', needsServer: true, fields: [{ name: 'message', type: 'text', label: 'Message', required: true }], submit: { label: 'Broadcast', successMessage: 'Sent', action: [{ capability: 'servers.command', args: { serverId: '{{server}}', command: 'say {{form.message}}' } }] } }] } }] }, null, 2) + '\n');
    fs.writeFileSync(path.join(dir, 'README.md'), `# ${arg}\n\nSee docs/EXTENSIONS.md. Validate with \`npm run ext:validate extensions-src/${arg}\`, pack with \`npm run ext:pack extensions-src/${arg}\`, then upload the .hnx on Management → Extensions.\n`);
    console.log(`Created ${path.relative(process.cwd(), dir)}`);
  } else if (cmd === 'validate') {
    if (!arg) die('Usage: validate <dir>');
    const { r } = await validate(path.resolve(arg)); console.log(`✔ ${r.summary}`); console.log(`  permissions: ${(r.manifest?.permissions || []).join(', ') || 'none'}`);
  } else if (cmd === 'pack') {
    if (!arg) die('Usage: pack <dir> [outDir]'); await pack(path.resolve(arg), path.resolve(out || path.join(ROOT, 'dist')));
  } else if (cmd === 'dev') {
    if (!arg) die('Usage: dev <dir>'); const dir = path.resolve(arg); let t = null;
    const go = () => pack(dir, path.join(ROOT, 'dist')).catch(() => {});
    await go(); console.log(`Watching ${dir} … upload the newest file from dist/ after each change (the panel does not hot-load unpacked folders).`);
    fs.watch(dir, { recursive: true }, () => { clearTimeout(t); t = setTimeout(() => { console.log('\nChange detected.'); validate(dir).then(go).catch(() => {}); }, 250); });
  } else if (cmd === 'build-examples') {
    const src = path.join(ROOT, 'extensions-src'), outDir = path.join(ROOT, 'extensions-examples');
    for (const d of fs.readdirSync(src, { withFileTypes: true })) if (d.isDirectory()) await pack(path.join(src, d.name), outDir);
  } else die('Commands: create <id> | validate <dir> | pack <dir> [outDir] | dev <dir> | build-examples');
})().catch(e => die(e.stack || e.message));
