'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const P = require('../lib/properties');
const { setup, ADMIN, VIEWER } = require('./harness');

const SAMPLE = '#Minecraft server properties\n#Sat Jan 01 00:00:00 UTC 2026\nmotd=\\u00A7aHello\\: World\nmax-players=20\npvp=true\ncustom-plugin-key=abc def\n\n# trailing comment\nserver-port=25565\n';
test('properties: edits are minimal and preserve comments, order, unknown keys and escapes', () => {
  const r = P.apply(SAMPLE, { 'max-players': '50', pvp: 'false' });
  assert.deepEqual(r.changed.sort(), ['max-players', 'pvp']);
  assert.equal(r.text, SAMPLE.replace('max-players=20', 'max-players=50').replace('pvp=true', 'pvp=false'));
  assert.equal(P.apply(SAMPLE, { 'max-players': '20' }).text, SAMPLE, 'no-op leaves file byte-identical');
  assert.equal(P.parse(SAMPLE).values.motd, '§aHello: World');
});
test('properties: strings are re-encoded like Java, new keys appended, defaults not written for absent keys', () => {
  const r = P.apply(SAMPLE, { motd: '§bHi: there=1', difficulty: 'hard', 'view-distance': '10', 'brand-new': 'x' });
  assert.match(r.text, /^motd=\\u00a7bHi\\: there\\=1$/m);
  assert.ok(r.text.endsWith('difficulty=hard\nbrand-new=x\n')); assert.ok(!r.text.includes('view-distance'));
  assert.equal(P.parse(r.text).values.motd, '§bHi: there=1');
});
test('properties: CRLF files and missing trailing newline survive; duplicates edit the one Java uses', () => {
  const crlf = 'a=1\r\npvp=true\r\n'; assert.equal(P.apply(crlf, { pvp: 'false' }).text, 'a=1\r\npvp=false\r\n');
  assert.equal(P.apply('pvp=true', { pvp: 'false' }).text, 'pvp=false\n');
  const dup = P.apply('pvp=true\npvp=false\n', { pvp: 'true' }); assert.equal(dup.text, 'pvp=true\npvp=true\n');
  assert.equal(P.apply('', { motd: 'x' }).text, 'motd=x\n');
});
test('properties: validation by type', () => {
  const bad = { 'max-players': 'lots', pvp: 'yes', difficulty: 'impossible', 'server-port': '70000', 'view-distance': '2', 'level-name': '../etc', motd: 'a\nb', 'rcon.password': 'abc', 'bad key!': 'x' };
  const r = P.apply(SAMPLE, bad); assert.equal(r.text, SAMPLE); assert.deepEqual(Object.keys(r.errors).sort(), Object.keys(bad).sort());
  assert.equal(Object.keys(P.apply(SAMPLE, { 'max-players': '-0' }).errors).length, 0);
  assert.equal(P.apply(SAMPLE, { 'rcon.password': 'secret123' }).changed[0], 'rcon.password');
});

async function withServer(extra = {}) {
  const S = await setup({ servers: { surv: { cwd: 'net/surv', label: 'Survival', port: 25565, software: { id: 'paper', version: '1.21.11' } }, other: { cwd: 'net/other', label: 'Other', port: 25570 }, proxy: { cwd: 'net/proxy', type: 'velocity', port: 25577, software: { id: 'velocity' } } } });
  for (const d of ['surv', 'other', 'proxy']) fs.mkdirSync(path.join(S.network, d));
  fs.writeFileSync(path.join(S.network, 'surv/server.properties'), 'motd=Hi\nserver-port=25565\nrcon.password=topsecret\nonline-mode=true\n', { mode: 0o640 });
  return S;
}
test('properties routes: read masks secrets and includes schema; permissions and tenancy enforced', async () => {
  const S = await withServer(), file = path.join(S.network, 'surv/server.properties');
  const r = await S.app.call('GET', '/api/properties/surv', { user: ADMIN });
  assert.equal(r.status, 200); assert.equal(r.body.values.motd, 'Hi'); assert.equal(r.body.values['rcon.password'], undefined); assert.equal(r.body.secretsSet['rcon.password'], true);
  assert.ok(!JSON.stringify(r.body).includes('topsecret')); assert.ok(r.body.schema.length > 40); assert.ok(r.body.schema.every(f => !('pattern' in f)));
  assert.equal(r.body.canEdit, true);
  assert.equal((await S.app.call('GET', '/api/properties/surv', { user: VIEWER })).body.canEdit, false);
  assert.equal((await S.app.call('GET', '/api/properties/surv')).status, 401);
  assert.equal((await S.app.call('GET', '/api/properties/nope', { user: ADMIN })).status, 404);
  assert.equal((await S.app.call('PUT', '/api/properties/surv', { user: VIEWER, body: { etag: r.body.etag, changes: { motd: 'x' } } })).status, 403);
  assert.equal((await S.app.call('GET', '/api/properties/proxy', { user: ADMIN })).status, 409);
  assert.equal(fs.readFileSync(file, 'utf8').includes('motd=Hi'), true);
});
test('properties routes: save keeps unknown content, backs up, updates port record, detects concurrent edits', async () => {
  const S = await withServer(), file = path.join(S.network, 'surv/server.properties');
  let g = (await S.app.call('GET', '/api/properties/surv', { user: ADMIN })).body;
  let r = await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: { motd: 'New', 'server-port': 25580, 'online-mode': false, 'rcon.password': '' } } });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.deepEqual(r.body.changed.sort(), ['motd', 'online-mode', 'server-port']);
  assert.equal(fs.readFileSync(file, 'utf8'), 'motd=New\nserver-port=25580\nrcon.password=topsecret\nonline-mode=false\n');
  assert.equal(S.config.servers.surv.port, 25580); assert.ok(S.written() > 0); assert.match(r.body.notes.join(' '), /proxy|Online mode is off/);
  assert.equal(fs.statSync(file).mode & 0o777, 0o640); assert.equal(fs.readdirSync(path.join(S.network, 'surv')).filter(n => n.includes('.tmp-')).length, 0);
  const bk = fs.readdirSync(path.join(S.network, 'surv/.blockpanel-backups')); assert.equal(bk.length, 1); assert.match(fs.readFileSync(path.join(S.network, 'surv/.blockpanel-backups', bk[0]), 'utf8'), /motd=Hi/);
  assert.ok(!JSON.stringify(S.state.audit).includes('topsecret')); assert.ok(!JSON.stringify(S.state.audit).includes('=New'));
  const stale = await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: { motd: 'Late' } } }); assert.equal(stale.status, 409); assert.match(stale.body.error, /changed on disk/);
  g = (await S.app.call('GET', '/api/properties/surv', { user: ADMIN })).body;
  const secret = await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: { 'rcon.password': 'newpass1' } } }); assert.equal(secret.status, 200); assert.match(fs.readFileSync(file, 'utf8'), /rcon\.password=newpass1/);
});
test('properties routes: validation errors are per-field, nothing is written; port clash refused; missing file is created', async () => {
  const S = await withServer(), file = path.join(S.network, 'surv/server.properties'), before = fs.readFileSync(file, 'utf8');
  const g = (await S.app.call('GET', '/api/properties/surv', { user: ADMIN })).body;
  const bad = await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: { 'max-players': 'x', 'server-port': 25570, difficulty: 'hard' } } });
  assert.equal(bad.status, 400); assert.ok(bad.body.errors['max-players']); assert.match(bad.body.errors['server-port'], /already used by “Other”/); assert.equal(fs.readFileSync(file, 'utf8'), before);
  assert.equal((await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: {} } })).status, 400);
  assert.equal((await S.app.call('PUT', '/api/properties/surv', { user: ADMIN, body: { etag: g.etag, changes: { motd: ['a'] } } })).status, 400);
  const o = await S.app.call('GET', '/api/properties/other', { user: ADMIN }); assert.equal(o.body.exists, false);
  const c = await S.app.call('PUT', '/api/properties/other', { user: ADMIN, body: { etag: o.body.etag, changes: { motd: 'Fresh' } } }); assert.equal(c.status, 200);
  assert.equal(fs.readFileSync(path.join(S.network, 'other/server.properties'), 'utf8'), 'motd=Fresh\n');
});
