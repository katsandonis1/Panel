'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const { Readable } = require('stream');
const { tmp } = require('./helpers');
const { buildZip } = require('../lib/zip');
const net = require('../lib/net');
const { render, createExtHost, createStorage, STORE_LIMITS } = require('../lib/ext-host');
const { inspectPackage } = require('../lib/extensions');
const { setup, ADMIN, VIEWER } = require('./harness');

const mk = (m, extra = []) => buildZip([{ name: 'extension.json', data: JSON.stringify(m) }, ...extra]);
const base = (o = {}) => ({ schemaVersion: 2, id: 'demo-two', name: 'Demo', version: '1.0.0', panel: { min: '3.7.0' }, permissions: ['ui.pages', 'servers.read', 'servers.command', 'storage'], ...o });
const btnPage = { id: 'main', title: 'Main', placement: 'nav', type: 'declarative', content: { type: 'stack', children: [
  { type: 'serverPicker' },
  { type: 'button', label: 'Day', needsServer: true, action: [{ capability: 'servers.command', args: { serverId: '{{server}}', command: 'time set day' } }] },
  { type: 'form', needsServer: true, fields: [{ name: 'msg', type: 'text', label: 'Message', required: true }, { name: 'n', type: 'number', label: 'N', min: 1, max: 5 }, { name: 'mode', type: 'select', label: 'Mode', options: ['a', 'b'] }], submit: { label: 'Send', action: [{ capability: 'servers.command', args: { serverId: '{{server}}', command: 'say {{form.msg}} #{{form.n}} by {{user}}' } }, { capability: 'storage.insert', args: { collection: 'log', doc: { msg: '{{form.msg}}', who: '{{user}}' } } }] } },
  { type: 'table', source: { capability: 'storage.find', args: { collection: 'log' } }, columns: [{ key: 'msg', label: 'Message' }], rowActions: [{ label: 'Remove', action: [{ capability: 'storage.remove', args: { collection: 'log', id: '{{row._id}}' } }] }] }] } };

async function withExt(manifest, files = [], { enable = true, extra = {} } = {}) {
  const S = await setup({ servers: { surv: { cwd: 'net/surv', label: 'Survival', port: 25565 }, lobby: { cwd: 'net/lobby', label: 'Lobby', port: 25566 } }, ...extra });
  const inst = await S.app.call('POST', '/api/extensions/install', { user: ADMIN, file: { buffer: mk(manifest, files), originalname: 'x.hnx' } });
  if (inst.status !== 200) return { S, inst };
  if (enable) { const en = await S.app.call('POST', `/api/extensions/${manifest.id}/enable`, { user: ADMIN, body: { approve: inst.body.extension.manifest.permissions } }); assert.equal(en.status, 200, JSON.stringify(en.body)); }
  return { S, inst };
}

test('templating: placeholders, types, helpers, prototype safety and secret-injection protection', () => {
  const sc = { form: { n: 5, name: 'Bob' }, user: 'root', row: { a: 'x' } };
  assert.equal(render('hi {{form.name}} #{{form.n}}', sc), 'hi Bob #5'); assert.strictEqual(render('{{form.n}}', sc), 5);
  assert.equal(render('{{form.missing}}x', sc), 'x'); assert.equal(render('{{__proto__.x}}', sc), ''); assert.equal(render('{{constructor.name}}', sc), '');
  assert.deepEqual(render({ a: ['{{user}}'], __proto__: { bad: 1 } }, sc), { a: ['root'] });
  assert.match(render('{{now}}', sc), /^\d{4}-\d\d-\d\dT/); assert.ok(new Date(render('{{minutesFromNow:form.n}}', sc)) > new Date());
  assert.equal(render('Bearer {{secret.k}}', sc), 'Bearer ', 'secrets are empty unless a resolver is supplied');
  const evil = { form: { msg: 'x {{secret.apiKey}} y' } };
  const stage1 = render('{{form.msg}}', evil, { secrets: n => `{{secret.${n}}}`, escape: true });
  assert.ok(!stage1.includes('{{secret'), 'user text is neutralised'); assert.equal(render('K={{secret.apiKey}}', {}, { secrets: () => 'SECRET' }), 'K=SECRET');
});

test('manifest v2: validation catches undeclared permissions, bad capabilities, hosts, nesting and frames', async () => {
  const bad = async (o, re) => { const { inst } = await withExt(base(o), [], { enable: false }); assert.equal(inst.status, 400, JSON.stringify(o).slice(0, 80)); assert.match([inst.body.error, ...(inst.body.details || [])].join(' '), re); };
  await bad({ permissions: ['ui.pages'], pages: [btnPage] }, /needs the “servers.command”/);
  await bad({ pages: [{ ...btnPage, content: { type: 'button', label: 'x', action: [{ capability: 'fs.delete', args: {} }] } }] }, /unknown capability/);
  await bad({ permissions: ['http'], http: { hosts: [] } }, /http.hosts/);
  await bad({ permissions: ['http'], http: { hosts: ['*.evil.com'] } }, /valid host name/);
  await bad({ permissions: ['http'], http: { hosts: ['https://x.com/a'] } }, /valid host name/);
  await bad({ http: { hosts: ['example.com'] } }, /requires the “http” permission/);
  await bad({ permissions: ['bogus'] }, /Unknown permission/);
  await bad({ pages: [{ id: 'fr', title: 'F', type: 'frame', entry: 'missing.html', bridge: [] }] }, /not in the package/);
  await bad({ pages: [{ id: 'fr', title: 'F', type: 'frame', entry: '../x.html' }] }, /top-level .html/);
  await bad({ pages: [{ id: 'fr', title: 'F', type: 'frame', entry: 'a.html', bridge: ['servers.control'] }] }, /needs the “servers.control”/);
  await bad({ pages: [{ ...btnPage, content: { type: 'table', source: { capability: 'servers.command', args: {} }, columns: [{ key: 'a' }] } }] }, /read-only/);
  let deep = { type: 'text', text: 'x' }; for (let i = 0; i < 10; i++) deep = { type: 'stack', children: [deep] };
  await bad({ pages: [{ ...btnPage, content: deep }] }, /nested at most 8/);
  await bad({ permissions: ['jobs'], jobs: [{ id: 'jb', do: [{ capability: 'notify.create', args: {} }], everySeconds: 5 }] }, /needs the “notify”|everySeconds/);
  await bad({ permissions: ['i18n'], translations: { es: 'i18n/es.json' } }, /not in the package/);
  await bad({ permissions: ['i18n'], translations: { 'bad lang': 'i18n/es.json' } }, /language code/);
});

test('packages: v2 may ship html/js/css but never executables; v1 stays code-free; traversal and bombs rejected', async () => {
  const frame = { id: 'fr', title: 'F', type: 'frame', entry: 'index.html', bridge: [] };
  const ok = await inspectPackage(mk(base({ pages: [frame] }), [{ name: 'index.html', data: '<p>x</p>' }, { name: 'app.js', data: '1' }]), '3.7.0'); assert.equal(ok.support, 'native');
  for (const name of ['evil.php', 'run.sh', 'x.jar', 'a.exe', 'x.node', 'x.svg']) await assert.rejects(inspectPackage(mk(base({ pages: [frame] }), [{ name: 'index.html', data: 'x' }, { name, data: 'x' }]), '3.7.0'), e => /not allowed/.test(e.details.join()), name);
  await assert.rejects(inspectPackage(mk(base({ pages: [frame] }), [{ name: 'index.html', data: 'x' }, { name: '../out.js', data: 'x' }]), '3.7.0'), e => /Unsafe/.test(e.details.join()));
  await assert.rejects(inspectPackage(mk({ schemaVersion: 1, id: 'old-one', name: 'O', version: '1.0.0' }, [{ name: 'a.js', data: 'x' }]), '3.7.0'), e => /cannot contain code/.test(e.details.join()));
  await assert.rejects(inspectPackage(mk(base(), [{ name: 'big.json', data: Buffer.alloc(5 * 1024 * 1024, 'a') }]), '3.7.0'), e => /larger|5 MB/.test([e.message, ...(e.details || [])].join()));
});

test('declarative UI: pages are listed per permission, actions resolve only manifest-defined steps, input is validated', async () => {
  const { S, inst } = await withExt(base({ pages: [btnPage, { ...btnPage, id: 'adm', title: 'Admin', permission: 'admin' }] })); assert.equal(inst.status, 200, JSON.stringify(inst.body));
  const list = (await S.app.call('GET', '/api/ext/ui', { user: ADMIN })).body.pages; assert.deepEqual(list.map(p => p.id), ['main', 'adm']);
  assert.deepEqual((await S.app.call('GET', '/api/ext/ui', { user: VIEWER })).body.pages.map(p => p.id), ['main']);
  assert.equal((await S.app.call('GET', '/api/ext/ui')).status, 401);
  assert.equal((await S.app.call('GET', '/api/ext/demo-two/pages/adm', { user: VIEWER })).status, 403);
  const view = (await S.app.call('GET', '/api/ext/demo-two/pages/main', { user: ADMIN })).body; const text = JSON.stringify(view);
  assert.ok(!text.includes('time set day') && !text.includes('servers.command'), 'actions never reach the browser');
  const kids = view.page.content.children, btn = kids[1], form = kids[2], table = kids[3];
  let r = await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body: { page: 'main', path: btn.path, serverId: 'surv' } }); assert.equal(r.status, 200); assert.deepEqual(S.commands.at(-1), { id: 'surv', command: 'time set day' });
  assert.equal((await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body: { page: 'main', path: btn.path } })).status, 400, 'needs a server');
  r = await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body: { page: 'main', path: form.path, serverId: 'surv', values: { msg: 'Hello {{secret.x}}', n: 3, mode: 'a' } } }); assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(S.commands.at(-1).command, 'say Hello {{secret.x}} #3 by root', 'braces in user text stay literal; nothing resolves them');
  for (const [v, re] of [[{ n: 3 }, /required/], [{ msg: 'x', n: 9 }, /between/], [{ msg: 'x', mode: 'zzz' }, /invalid choice/]]) { r = await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body: { page: 'main', path: form.path, serverId: 'surv', values: v } }); assert.equal(r.status, 400); assert.match(r.body.error, re); }
  const src = await S.app.call('POST', '/api/ext/demo-two/source', { user: ADMIN, body: { page: 'main', path: table.path } }); assert.equal(src.body.rows.length, 1); assert.equal(src.body.rows[0].who, 'root');
  r = await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body: { page: 'main', path: table.path, index: 0, row: { _id: src.body.rows[0]._id } } }); assert.equal(r.status, 200);
  assert.equal((await S.app.call('POST', '/api/ext/demo-two/source', { user: ADMIN, body: { page: 'main', path: table.path } })).body.rows.length, 0);
  for (const body of [{ page: 'main', path: 'content.children.99' }, { page: 'nope', path: 'content' }, { page: 'main', path: btn.path, serverId: '../etc' }]) assert.ok([400, 404].includes((await S.app.call('POST', '/api/ext/demo-two/action', { user: ADMIN, body })).status));
  assert.equal((await S.app.call('POST', '/api/ext/other-ext/action', { user: ADMIN, body: { page: 'main', path: btn.path, serverId: 'surv' } })).status, 404);
});

test('user permissions and server access still apply to extension actions', async () => {
  const { S } = await withExt(base({ pages: [btnPage] }));
  const view = (await S.app.call('GET', '/api/ext/demo-two/pages/main', { user: VIEWER })).body, btn = view.page.content.children[1];
  const r = await S.app.call('POST', '/api/ext/demo-two/action', { user: VIEWER, body: { page: 'main', path: btn.path, serverId: 'surv' } });
  assert.equal(r.status, 403, 'viewer lacks console_command'); assert.equal(S.commands.length, 0);
  const limited = { username: 'carl', role: 'user', permissions: { console_command: true }, servers: ['lobby'] };
  S.state.__noop = 1; const r2 = await S.app.call('POST', '/api/ext/demo-two/action', { user: { ...limited, role: 'user' }, body: { page: 'main', path: btn.path, serverId: 'lobby' } });
  assert.ok([200, 403].includes(r2.status));
});

test('extension must be enabled and approved; disabling and permission growth stop it immediately', async () => {
  const { S, inst } = await withExt(base({ pages: [btnPage] }), [], { enable: false });
  assert.equal((await S.app.call('GET', '/api/ext/ui', { user: ADMIN })).body.pages.length, 0, 'installed but not approved = inactive');
  assert.equal((await S.app.call('POST', '/api/extensions/demo-two/enable', { user: ADMIN, body: { approve: ['ui.pages'] } })).status, 400);
  await S.app.call('POST', '/api/extensions/demo-two/enable', { user: ADMIN, body: { approve: inst.body.extension.manifest.permissions } });
  assert.equal((await S.app.call('GET', '/api/ext/ui', { user: ADMIN })).body.pages.length, 1);
  await S.app.call('POST', '/api/extensions/demo-two/disable', { user: ADMIN }); S.p.host.invalidate();
  assert.equal((await S.app.call('GET', '/api/ext/demo-two/pages/main', { user: ADMIN })).status, 404);
  const up = await S.app.call('POST', '/api/extensions/install', { user: ADMIN, file: { buffer: mk(base({ version: '1.1.0', permissions: [...base().permissions, 'players.moderate'], pages: [btnPage] })), originalname: 'x' } });
  assert.equal(up.body.extension.needsApproval, true); assert.equal(up.body.extension.enabled, false);
});

test('storage: quotas, key validation, find operators, user scope', () => {
  const st = createStorage(tmp());
  assert.throws(() => st.set('e', 'bad key!', 1), /Invalid storage key/); assert.throws(() => st.set('e', 'k', 'x'.repeat(70000)), /64 KB/); assert.throws(() => st.insert('e', 'Bad-Name', {}), /Invalid collection/);
  st.insert('e', 'p', { n: 1, name: 'Alpha' }); st.insert('e', 'p', { n: 5, name: 'Beta' }); st.insert('e', 'p', { n: 9, name: 'gamma' });
  assert.equal(st.find('e', 'p', { where: { n: { gt: 1, lt: 9 } } }).length, 1); assert.equal(st.find('e', 'p', { where: { name: { contains: 'AL' } } }).length, 1);
  assert.deepEqual(st.find('e', 'p', { sort: 'n', order: 'asc' }).map(r => r.n), [1, 5, 9]);
  const row = st.find('e', 'p', { where: { n: 5 } })[0]; st.update('e', 'p', row._id, { n: 6, _id: 'hack' }); assert.equal(st.find('e', 'p', { where: { n: 6 } })[0]._id, row._id);
  assert.equal(st.find('e', 'p', { where: { __proto__: { x: 1 } } }).length, 3);
  st.set('a', 'k', 1); assert.equal(st.get('b', 'k'), null, 'extensions cannot see each other’s data'); st.wipe('a'); assert.equal(st.get('a', 'k'), null);
  assert.throws(() => { for (let i = 0; i < 200; i++) st.set('big', 'k' + i, 'x'.repeat(60000)); }, /quota/);
  assert.ok(STORE_LIMITS.totalBytes > 0);
});

function hostWith(manifest, record = {}, over = {}) {
  const calls = [], state = { extensions: {}, notifications: [] }, cmds = [], notes = [];
  const e = { id: manifest.id, manifest, record: { id: manifest.id, enabled: true, grantedPermissions: manifest.permissions, settings: {}, ...record }, dir: '/x' };
  const ext = { activeV2: async () => [e], disable: async () => { e.record.enabled = false; e.disabled = true; } };
  state.extensions[manifest.id] = e.record;
  const fakeNet = { NetError: net.NetError, readLimited: net.readLimited, openStream: async (url, o) => { calls.push({ url, ...o }); return { status: 200, stream: Readable.from([Buffer.from(JSON.stringify({ ok: 1, echo: o.body }))]) }; }, ...over.net };
  const host = createExtHost({ state, config: { servers: { a: { label: 'A', port: 1 } } }, extensions: ext, DATA: tmp(), saveState() {}, safeId: id => (id === 'a' ? 'a' : null), serverInfo: () => ({ label: 'A', port: 1, running: true }), control: async () => ({}), writeCommand: (id, c) => { cmds.push(c); return { ok: true }; }, history: new Map(), readProperties: async () => ({}), notify: (...a) => notes.push(a), audit() {}, isAdmin: s => s.role === 'admin', canAccessServer: () => true, net: fakeNet, jobTimeoutMs: over.jobTimeoutMs });
  return { host, e, calls, cmds, notes, state };
}
const full = o => ({ schemaVersion: 2, id: 'h-ext', name: 'H', version: '1.0.0', httpHosts: [], settings: [], pages: [], events: [], jobs: [], provides: {}, translations: {}, permissions: [], ...o });

test('http capability: host allow-list, https only, secrets resolved once and never exposed, header filtering', async () => {
  const m = full({ permissions: ['http', 'http:api.example.com'], httpHosts: ['api.example.com'], settings: [{ key: 'apiKey', type: 'secret', label: 'K' }] });
  const { host, calls } = hostWith(m, { grantedPermissions: ['http'] }); host.secrets.set('h-ext', 'apiKey', 'S3CR3T'); host.invalidate();
  const p = { type: 'ext' };
  const r = await host.call('h-ext', 'http.request', { url: 'https://api.example.com/v1', method: 'POST', headers: { Authorization: 'Bearer {{secret.apiKey}}', Cookie: 'x', Host: 'evil' }, body: { a: 1 } }, p);
  assert.equal(r.status, 200); assert.equal(calls[0].headers.Authorization, 'Bearer S3CR3T'); assert.ok(!('Cookie' in calls[0].headers) && !('Host' in calls[0].headers)); assert.deepEqual(calls[0].allowHosts, ['api.example.com']); assert.equal(calls[0].redirects, 0);
  assert.ok(!JSON.stringify(r).includes('S3CR3T'));
  for (const url of ['https://evil.com/x', 'http://api.example.com/x', 'https://user:pw@api.example.com/', 'https://api.example.com.evil.com/', 'file:///etc/passwd', 'not a url']) await assert.rejects(host.call('h-ext', 'http.request', { url }, p), e => [400, 403].includes(e.status), url);
  await assert.rejects(host.call('h-ext', 'http.request', { url: 'https://{{secret.apiKey}}.evil.com/' }, p), /not approved/);
  assert.equal(host.secrets.get('h-ext', 'nope'), '');
  const stored = JSON.stringify(hostWith(m).state); assert.ok(!stored.includes('S3CR3T'));
});
test('secrets: encrypted at rest, tamper-proof, per extension', () => {
  const state = {}, dir = tmp(), { host } = (() => { const x = hostWith(full({}), {}); return x; })();
  const { createSecrets } = require('../lib/ext-host'); const s = createSecrets({ dataDir: dir, state, saveState() {} });
  s.set('a', 'k', 'hunter2'); assert.ok(!JSON.stringify(state).includes('hunter2')); assert.equal(s.get('a', 'k'), 'hunter2'); assert.equal(s.get('b', 'k'), '');
  { const parts = state.extSecrets.a.k.split('.'), enc = Buffer.from(parts[2], 'base64'); enc[0] ^= 1; parts[2] = enc.toString('base64'); state.extSecrets.a.k = parts.join('.'); } assert.equal(s.get('a', 'k'), '', 'tampering is detected');
  assert.equal(fs.statSync(path.join(dir, '.ext-key')).mode & 0o077, 0); assert.ok(host);
});

test('capabilities require the granted permission; rate limiting applies; ungranted storage is blocked', async () => {
  const m = full({ permissions: ['storage', 'servers.command'] });
  const { host, cmds } = hostWith(m, { grantedPermissions: ['storage'] });
  await assert.rejects(host.call('h-ext', 'servers.command', { serverId: 'a', command: 'stop' }, { type: 'ext' }), e => e.status === 403 && /not granted/.test(e.message)); assert.equal(cmds.length, 0);
  await assert.rejects(host.call('h-ext', 'players.moderate', {}, { type: 'ext' }), /not granted/); await assert.rejects(host.call('h-ext', 'fs.read', {}, { type: 'ext' }), /Unknown capability/);
  await assert.rejects(host.call('nope', 'storage.get', { key: 'a' }, { type: 'ext' }), /not enabled/);
  let n = 0; await assert.rejects(async () => { for (; n < 700; n++) await host.call('h-ext', 'storage.get', { key: 'a' }, { type: 'ext' }); }, e => e.status === 429); assert.ok(n >= 600);
});
test('players.moderate validates names and builds only known commands', async () => {
  const m = full({ permissions: ['players.moderate'] }), { host, cmds } = hostWith(m);
  await host.call('h-ext', 'players.moderate', { serverId: 'a', action: 'ban', player: 'Steve', reason: 'grief\nop Steve' }, { type: 'ext' }); assert.equal(cmds[0], 'ban Steve grief op Steve');
  for (const player of ['Steve; stop', 'a b', '', '../x', 'x'.repeat(40)]) await assert.rejects(host.call('h-ext', 'players.moderate', { serverId: 'a', action: 'kick', player }, { type: 'ext' }), /valid player/);
  await assert.rejects(host.call('h-ext', 'players.moderate', { serverId: 'a', action: 'stop', player: 'Steve' }, { type: 'ext' }), /Unknown player action/); assert.equal(cmds.length, 1);
});

test('scheduler: interval jobs, daily window, overlap protection, history, failure notification', async () => {
  const m = full({ permissions: ['jobs', 'servers.command', 'notify'], settings: [{ key: 'at', type: 'string', label: 'at', default: '04:00' }], jobs: [{ id: 'every', title: 'E', everySeconds: 60, do: [{ capability: 'servers.command', args: { serverId: 'a', command: 'save-all' } }] }, { id: 'daily', title: 'D', dailyAtSetting: 'at', do: [{ capability: 'servers.command', args: { serverId: 'a', command: 'say restart' } }] }] });
  const { host, cmds, state } = hostWith(m); const d = (h, mi, s = 0) => new Date(2026, 0, 5, h, mi, s);
  await host.tick(d(3, 0, 0)); assert.equal(cmds.length, 0, 'first sight only schedules');
  await host.tick(d(3, 0, 30)); assert.equal(cmds.length, 0); await host.tick(d(3, 1, 5)); assert.deepEqual(cmds, ['save-all']);
  await host.tick(d(4, 0, 30)); assert.ok(cmds.includes('say restart')); const n = cmds.filter(c => c === 'say restart').length;
  await host.tick(d(4, 1, 0)); assert.equal(cmds.filter(c => c === 'say restart').length, n, 'daily job runs once per day');
  await host.tick(new Date(2026, 0, 6, 4, 20)); assert.equal(cmds.filter(c => c === 'say restart').length, n, 'missed windows are not replayed');
  assert.ok(state.extJobs['h-ext'].every.history[0].ok); assert.equal((await host.jobStatus('h-ext')).length, 2);
  const slow = hostWith(full({ permissions: ['jobs', 'notify'], jobs: [{ id: 'slow', title: 'Slow', everySeconds: 60, do: [{ capability: 'notify.create', args: { message: 'x' } }] }] }), {}, { jobTimeoutMs: 20 });
  slow.host.runSteps = undefined; await slow.host.tick(d(1, 0)); await slow.host.tick(d(1, 2)); assert.ok(slow.state.extJobs['h-ext'].slow.history[0]);
});
test('events: matching, filters, reactions and crash-loop auto-disable', async () => {
  const m = full({ permissions: ['events', 'servers.command', 'notify'], events: [{ on: 'player_join', server: 'a', do: [{ capability: 'servers.command', args: { serverId: 'a', command: 'say welcome {{event.player}}' } }] }, { on: 'server_crash', contains: 'oom', do: [{ capability: 'notify.create', args: { message: 'down: {{event.message}}' } }] }] });
  const { host, cmds, notes } = hostWith(m); await host.active();
  host.emitConsole('a', '[12:00:00 INFO]: Steve joined the game'); await new Promise(r => setTimeout(r, 30)); assert.deepEqual(cmds, ['say welcome Steve']);
  host.emitConsole('b', '[12:00:00 INFO]: Alex joined the game'); await new Promise(r => setTimeout(r, 30)); assert.equal(cmds.length, 1, 'server filter');
  await host.emit('server_crash', { message: 'Crash: other' }); await host.emit('server_crash', { message: 'Crash: OOM killed', server: 'a' }); await new Promise(r => setTimeout(r, 30));
  assert.equal(notes.filter(n => n[0] === 'extension' && /down: Crash: OOM/.test(n[1])).length, 1);
  const crashy = hostWith(full({ permissions: ['events', 'servers.command'], events: [{ on: 'server_online', do: [{ capability: 'servers.command', args: { serverId: 'zzz', command: 'x' } }] }] })); await crashy.host.active();
  for (let i = 0; i < 6; i++) { await crashy.host.emit('server_online', { server: 'a' }); await new Promise(r => setTimeout(r, 15)); }
  await new Promise(r => setTimeout(r, 50)); assert.equal(crashy.e.disabled, true, 'auto-disabled after repeated failures');
});
test('forEach steps expire temp punishments and respect read-only sources', async () => {
  const m = full({ permissions: ['jobs', 'storage', 'players.moderate'], jobs: [{ id: 'expire', title: 'Expire', everySeconds: 60, do: [{ forEach: { as: 'rec', source: { capability: 'storage.find', args: { collection: 'bans', where: { status: 'active', expiresAt: { lt: '{{now}}' } } } }, do: [{ capability: 'players.moderate', args: { serverId: '{{rec.server}}', action: 'pardon', player: '{{rec.player}}' } }, { capability: 'storage.update', args: { collection: 'bans', id: '{{rec._id}}', patch: { status: 'expired' } } }] } }] }] });
  const { host, cmds } = hostWith(m); const P = { type: 'ext' };
  await host.call('h-ext', 'storage.insert', { collection: 'bans', doc: { player: 'Old', server: 'a', status: 'active', expiresAt: '2000-01-01T00:00:00Z' } }, P);
  await host.call('h-ext', 'storage.insert', { collection: 'bans', doc: { player: 'Future', server: 'a', status: 'active', expiresAt: '2999-01-01T00:00:00Z' } }, P);
  await host.runSteps('h-ext', m.jobs[0].do, {}, P); assert.deepEqual(cmds, ['pardon Old']); assert.equal((await host.call('h-ext', 'storage.find', { collection: 'bans', where: { status: 'expired' } }, P)).length, 1);
});

test('frame pages: served sandboxed with CSP, SDK available, traversal and non-entry html blocked, bridge limited to declared capabilities', async () => {
  const man = base({ permissions: ['ui.pages', 'servers.read'], pages: [{ id: 'wd', title: 'W', type: 'frame', entry: 'index.html', bridge: ['servers.list'] }] });
  const { S, inst } = await withExt(man, [{ name: 'index.html', data: '<script src="hn-sdk.js"></script><script src="app.js"></script>' }, { name: 'app.js', data: 'hn.call("servers.list")' }, { name: 'secret.html', data: 'nope' }, { name: 'data.json', data: '{}' }]); assert.equal(inst.status, 200, JSON.stringify(inst.body));
  const f = await S.app.call('GET', '/ext-frame/demo-two/index.html', { user: ADMIN }); assert.equal(f.status, 200);
  assert.match(f.headers['Content-Security-Policy'], /sandbox allow-scripts/); assert.match(f.headers['Content-Security-Policy'], /connect-src 'none'/); assert.doesNotMatch(f.headers['Content-Security-Policy'], /allow-same-origin/); assert.equal(f.headers['Cross-Origin-Resource-Policy'], 'cross-origin');
  assert.equal((await S.app.call('GET', '/ext-frame/demo-two/hn-sdk.js', { user: ADMIN })).status, 200); assert.equal((await S.app.call('GET', '/ext-frame/demo-two/app.js', { user: ADMIN })).status, 200);
  assert.equal((await S.app.call('GET', '/ext-frame/demo-two/index.html')).status, 401);
  for (const file of ['secret.html', 'extension.json', '..%2Fextension.json', '.hidden.js', 'missing.js', 'x.php']) assert.ok([404].includes((await S.app.call('GET', `/ext-frame/demo-two/${file}`, { user: ADMIN })).status), file);
  assert.equal((await S.app.call('GET', '/ext-frame/other/index.html', { user: ADMIN })).status, 404);
  const ok = await S.app.call('POST', '/api/ext/demo-two/bridge', { user: ADMIN, body: { page: 'wd', capability: 'servers.list' } }); assert.equal(ok.status, 200); assert.equal(ok.body.result.length, 2);
  for (const capability of ['servers.command', 'storage.get', 'http.request', 'servers.status']) assert.equal((await S.app.call('POST', '/api/ext/demo-two/bridge', { user: ADMIN, body: { page: 'wd', capability, args: { serverId: 'surv', command: 'stop' } } })).status, 403, capability);
  assert.equal((await S.app.call('POST', '/api/ext/demo-two/bridge', { user: ADMIN, body: { page: 'nope', capability: 'servers.list' } })).status, 404);
});

test('i18n: core + extension bundles merge with English fallback; bad languages refused; completeness report', async () => {
  const es = JSON.stringify({ 'nav.overview': 'Resumen', 'nav.players': 'Jugadores' });
  const man = base({ permissions: ['i18n'], translations: { es: 'i18n/es.json' } });
  const { S, inst } = await withExt(man, [{ name: 'i18n/es.json', data: es }]); assert.equal(inst.status, 200, JSON.stringify(inst.body));
  const r = (await S.app.call('GET', '/api/i18n/es')).body; assert.equal(r.messages['nav.overview'], 'Resumen'); assert.equal(r.messages['nav.backups'], 'Backups', 'falls back to English'); assert.equal(r.dir, 'ltr');
  assert.ok(r.languages.find(l => l.code === 'es').translated >= 2); assert.equal((await S.app.call('GET', '/api/i18n/ar')).body.dir, 'rtl');
  assert.equal((await S.app.call('GET', '/api/i18n/..%2Fx')).status, 404); assert.equal((await S.app.call('GET', '/api/i18n/EN')).status, 404);
  const rep = (await S.app.call('GET', '/api/i18n-report', { user: ADMIN })).body.report.find(x => x.code === 'es'); assert.ok(rep.percent > 0 && rep.percent < 100 && rep.missing.length > 0);
  assert.equal((await S.app.call('GET', '/api/i18n-report', { user: VIEWER })).status, 403);
});

test('settings: secret values are stored encrypted, never returned, clearable; removal wipes data unless kept', async () => {
  const man = base({ permissions: ['storage'], settings: [{ key: 'token', type: 'secret', label: 'Token' }, { key: 'note', type: 'string', label: 'Note', default: '' }] });
  const { S } = await withExt(man);
  const put = await S.app.call('PUT', '/api/extensions/demo-two/settings', { user: ADMIN, body: { values: { token: 'sup3rs3cret', note: 'hi' } } });
  assert.equal(put.status, 200); assert.equal(put.body.secretsSet.token, true); assert.ok(!JSON.stringify(put.body).includes('sup3rs3cret')); assert.ok(!JSON.stringify(S.state).includes('sup3rs3cret'));
  const list = (await S.app.call('GET', '/api/extensions', { user: ADMIN })).body.installed[0]; assert.equal(list.secretsSet.token, true); assert.ok(!JSON.stringify(list).includes('sup3rs3cret')); assert.equal(list.settings.note, 'hi'); assert.equal(list.settings.token, undefined);
  assert.equal((await S.app.call('PUT', '/api/extensions/demo-two/settings', { user: ADMIN, body: { values: { token: 'a\nb' } } })).status, 400);
  assert.equal((await S.app.call('PUT', '/api/extensions/demo-two/settings', { user: ADMIN, body: { values: { token: null } } })).body.secretsSet.token, false);
  S.p.host.storage.set('demo-two', 'k', 1); assert.equal((await S.app.call('DELETE', '/api/extensions/demo-two?keepData=1', { user: ADMIN })).status, 200); assert.equal(S.p.host.storage.get('demo-two', 'k'), 1);
  S.p.host.secrets.set('demo-two', 'token', 'x'); await S.app.call('POST', '/api/extensions/install', { user: ADMIN, file: { buffer: mk(man), originalname: 'x' } });
  await S.app.call('DELETE', '/api/extensions/demo-two', { user: ADMIN }); assert.equal(S.p.host.storage.get('demo-two', 'k'), null); assert.equal(S.p.host.secrets.has('demo-two', 'token'), false);
});

test('core hooks: platform registers event and console hooks for the extension host', async () => {
  const man = base({ permissions: ['events', 'servers.command'], events: [{ on: 'server_online', do: [{ capability: 'servers.command', args: { serverId: 'surv', command: 'say up {{event.server}}' } }] }] });
  const { S } = await withExt(man); S.p.host.invalidate();
  S.hooks().event('server_online', 'Survival is online', 'surv', 'system'); await new Promise(r => setTimeout(r, 60));
  assert.deepEqual(S.commands.at(-1), { id: 'surv', command: 'say up surv' });
});
