'use strict';
const assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), crypto = require('crypto'), Module = require('module');
const { tmp, serve, testNet } = require('./helpers');
const { buildZip } = require('../lib/zip');
const origLoad = Module._load;
Module._load = function (req, ...a) { if (req === 'multer') { const m = () => ({ single: () => (rq, rs, next) => next() }); m.memoryStorage = () => ({}); m.diskStorage = () => ({}); m.MulterError = class extends Error {}; return m; } return origLoad.call(this, req, ...a); };
const createPlatform = require('../platform-api');

function fakeApp() {
  const routes = [];
  const reg = method => (p, ...h) => routes.push({ method, paths: [].concat(p), h });
  const app = { routes, get: reg('GET'), post: reg('POST'), put: reg('PUT'), delete: reg('DELETE'), use: (p, ...h) => { if (typeof p === 'function') routes.push({ method: '*', paths: ['/'], h: [p, ...h], use: true }); else routes.push({ method: '*', paths: [p], h, use: true }); } };
  const match = (pattern, url, prefix) => { const re = new RegExp('^' + pattern.replace(/:[A-Za-z]+/g, '([^/]+)') + (prefix ? '(?=/|$)' : '$')); const m = re.exec(url); if (!m) return null; const names = [...pattern.matchAll(/:([A-Za-z]+)/g)].map(x => x[1]); return { params: Object.fromEntries(names.map((n, i) => [n, decodeURIComponent(m[i + 1])])), rest: url.slice(m[0].length) || '/' }; };
  app.call = async (method, url, { body, user, files, file } = {}) => {
    const [pathname, qs] = url.split('?'), query = Object.fromEntries(new URLSearchParams(qs || ''));
    const res = { code: 200, headers: {}, body: undefined, status(c) { this.code = c; return this; }, json(b) { this.body = b; this.done = true; return this; }, send(b) { this.body = b; this.done = true; return this; }, set(k, v) { if (typeof k === 'object') Object.assign(this.headers, k); else this.headers[k] = v; return this; }, end() { this.done = true; return this; }, sendFile(f) { this.body = { file: f }; this.done = true; } };
    const chain = [];
    for (const r of routes) {
      if (r.method !== '*' && r.method !== method) continue;
      for (const p of r.paths) { const m = match(p, pathname, !!r.use); if (m) { for (const fn of r.h) chain.push({ fn, params: m.params, path: r.use ? m.rest : pathname }); break; } }
    }
    let i = 0; const req = { method, query, body: body || {}, _user: user, params: {}, ip: '127.0.0.1', files, file };
    await new Promise((resolve, reject) => {
      const guard = setTimeout(() => reject(new Error(`HUNG ${method} ${url} at handler ${i}/${chain.length}`)), 3000); const _r = resolve; resolve = v => { clearTimeout(guard); _r(v); };
      const next = async err => {
        if (res.done || i >= chain.length) return resolve();
        const { fn, params, path: p } = chain[i++]; req.params = { ...req.params, ...params }; req.path = p;
        try { await fn(req, res, next); } catch (e) { res.status(500).json({ error: 'THROWN ' + e.message }); }
        if (res.done) resolve();
      };
      res.end = res.json = res.send = function (b) { this.body = b ?? this.body; this.done = true; resolve(); return this; };
      res.sendFile = function (f) { this.body = { file: f }; this.done = true; resolve(); };
      next();
    });
    if (!res.done) res.code = 404;
    return { status: res.code, body: res.body, headers: res.headers };
  };
  return app;
}
const ADMIN = { username: 'root', role: 'admin' }, VIEWER = { username: 'bob', role: 'viewer', permissions: { files_view: true } };

async function setup({ catalog, modrinth, servers = {}, net: netOverride } = {}) {
  const root = tmp(), network = path.join(root, 'net'), data = path.join(root, 'data');
  fs.mkdirSync(network); fs.mkdirSync(data); fs.mkdirSync(path.join(root, 'public')); fs.mkdirSync(path.join(root, 'templates'));
  fs.writeFileSync(path.join(root, 'public', 'index.html'), '<html><head><title>x</title><meta name="theme-color" content="#000"></head><body><div class="brand" data-brand-name>x</div></body></html>');
  fs.copyFileSync(path.join(__dirname, '..', 'templates', 'velocity.toml'), path.join(root, 'templates', 'velocity.toml'));
  fs.mkdirSync(path.join(root, 'bundled-extensions')); fs.cpSync(path.join(__dirname, '..', 'bundled-extensions'), path.join(root, 'bundled-extensions'), { recursive: true });
  fs.copyFileSync(path.join(__dirname, '..', 'public', 'hn-sdk.js'), path.join(root, 'public', 'hn-sdk.js'));
  fs.cpSync(path.join(__dirname, '..', 'i18n'), path.join(root, 'i18n'), { recursive: true });
  const fakeJava = path.join(root, 'fakejava'); fs.writeFileSync(fakeJava, '#!/bin/sh\necho \'openjdk version "21.0.1"\' >&2\n', { mode: 0o755 });
  const config = { panel: { port: 1 }, networkRoot: 'net', servers }, state = { audit: [], notifications: [] };
  const app = fakeApp(); let lock = false, saved = 0, written = 0;
  const admin = (req, res, next) => { if (!req._user) return res.status(401).json({ error: 'Unauthorized' }); if (req._user.role !== 'admin') return res.status(403).json({ error: 'Admin only.' }); req.panelSession = req._user; next(); };
  const perm = p => (req, res, next) => { if (!req._user) return res.status(401).json({ error: 'Unauthorized' }); if (req._user.role !== 'admin' && !req._user.permissions?.[p]) return res.status(403).json({ error: 'no' }); req.panelSession = req._user; next(); };
  const serverRoot = id => path.resolve(root, config.servers[id].cwd);
  const commands = [], controls = [], history = new Map(); let hooks = {};
  const requireAuth = (req, res, next) => { if (!req._user) return res.status(401).json({ error: 'Unauthorized' }); req.panelSession = req._user; next(); };
  const ctx = { requireAuth, history, setHooks: h => { hooks = { ...hooks, ...h }; }, writeCommand: (id, command) => { commands.push({ id, command }); return { ok: true }; }, control: async (id, action) => { controls.push({ id, action }); return {}; },
    serverInfo: id => ({ id, label: config.servers[id].label || id, port: config.servers[id].port, running: true, proxy: config.servers[id].type === 'velocity', pluginsSupported: null, status: { online: true, players: 2, max: 20 } }),
    app, state, config, saveState: () => { saved++; }, writeConfig: () => { written++; }, audit: (req, a, d) => state.audit.push({ a, d }), notify() {}, requireAdmin: admin, requirePermission: perm, isAdmin: s => s?.role === 'admin', getUsers: () => [VIEWER], safeId: id => Object.hasOwn(config.servers, id) ? id : null, serverIdExists: id => Object.keys(config.servers).some(k => k.toLowerCase() === String(id).toLowerCase()), serverRoot, safePath: async (id, rel = '', allowMissing) => { const r = serverRoot(id), t = path.resolve(r, rel); if (!t.startsWith(r)) throw Error('Invalid path.'); if (!allowMissing && !fs.existsSync(t)) throw Error('File or directory not found.'); return { root: r, target: t, rel }; }, inside: (a, b) => path.resolve(b).startsWith(path.resolve(a)), networkRoot: () => network, processes: new Map(), ROOT: root, DATA: data, configureVelocityToml: (t, port) => `bind = "0.0.0.0:${port}"\n${t}`, normalizeRel: r => { const n = path.posix.normalize('/' + r).replace(/^\/+/, ''); if (n.startsWith('..')) throw Error('Invalid path.'); return n; }, assertSafeClonePath() {}, getCreationLock: () => lock, setCreationLock: v => { lock = v; }, panelVersion: '3.7.0',
    deps: { noScheduler: true, net: netOverride || testNet, catalog, modrinth, runProcess: async () => { throw new Error('unexpected build'); } } };
  const p = createPlatform(ctx); p.installEarly(); p.installLate();
  return { app, config, state, root, network, data, fakeJava, p, commands, controls, history, hooks: () => hooks, saved: () => saved, written: () => written, lock: () => lock };
}

const jarBytes = (main = 'a.Main') => buildZip([{ name: 'META-INF/MANIFEST.MF', data: `Manifest-Version: 1.0\nMain-Class: ${main}\n` }, { name: 'a/Main.class', data: 'x' }]);
function fakeCatalog(url, expected, over = {}) {
  return { listVersions: async () => ({ versions: [] }), builds: async () => [], resolve: async (id, version) => ({ software: id, version, kind: id === 'velocity' ? 'proxy' : 'server', trust: 'official', hosts: null, warnings: [], jar: id === 'velocity' ? 'velocity.jar' : 'server.jar', build: '7', url, fileName: 'x.jar', expected, javaMajor: 21, method: 'download', ...over }) };
}
module.exports = { fakeApp, setup, ADMIN, VIEWER, jarBytes, fakeCatalog, createPlatform };
