'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { serve } = require('./helpers');
const { buildZip } = require('../lib/zip');
const plugins = require('../lib/plugins');
const { setup, ADMIN, VIEWER, jarBytes, fakeCatalog } = require('./harness');
const waitJob = async (S, jobId) => { for (let i = 0; i < 200; i++) { const r = await S.app.call('GET', '/api/jobs/' + jobId, { user: ADMIN }); if (r.body.status !== 'running') return r.body; await new Promise(r => setTimeout(r, 25)); } throw new Error('job timeout'); };

test('branding routes: public read, admin-only write, validation, asset upload', async () => {
  const S = await setup();
  const pub = await S.app.call('GET', '/api/branding'); assert.equal(pub.status, 200); assert.equal(pub.body.name, 'Hellenic Network'); assert.equal(pub.body.logoUrl, null);
  assert.equal((await S.app.call('PUT', '/api/branding', { body: { name: 'X' } })).status, 401);
  assert.equal((await S.app.call('PUT', '/api/branding', { body: { name: 'X' }, user: VIEWER })).status, 403);
  assert.equal((await S.app.call('PUT', '/api/branding', { body: { colors: { text: '#101010' } }, user: ADMIN })).status, 400);
  const ok = await S.app.call('PUT', '/api/branding', { body: { name: 'Olympus', labels: { overview: 'Home' } }, user: ADMIN }); assert.equal(ok.status, 200);
  assert.equal((await S.app.call('GET', '/api/branding')).body.name, 'Olympus');
  assert.match((await S.app.call('GET', '/')).body, /<title>Olympus<\/title>/); assert.match((await S.app.call('GET', '/manifest.webmanifest')).body, /Olympus/); assert.match((await S.app.call('GET', '/branding.css')).body, /--bg:/);
  const png = Buffer.alloc(64); Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(png); png.writeUInt32BE(64, 16); png.writeUInt32BE(64, 20);
  const up = await S.app.call('PUT', '/api/branding/asset/logo', { body: { data: 'data:image/png;base64,' + png.toString('base64') }, user: ADMIN }); assert.equal(up.status, 200); assert.match(up.body.branding.logoUrl, /^\/branding\/logo\?v=/);
  assert.equal((await S.app.call('PUT', '/api/branding/asset/logo', { body: { data: 'data:image/svg+xml;base64,PHN2Zz4=' }, user: ADMIN })).status, 400);
  assert.equal((await S.app.call('GET', '/branding/logo')).headers['X-Content-Type-Options'], 'nosniff');
  assert.equal((await S.app.call('PUT', '/api/branding/asset/evil', { body: {}, user: ADMIN })).status, 404);
  await S.app.call('POST', '/api/branding/reset', { user: ADMIN }); assert.equal((await S.app.call('GET', '/api/branding')).body.name, 'Hellenic Network');
  assert.equal(fs.existsSync(path.join(S.data, 'branding', 'logo.png')), false);
});

test('create-server: full flow writes files, registers the server, records software + verification', async () => {
  const jar = jarBytes(), sha = crypto.createHash('sha256').update(jar).digest('hex');
  const srv = await serve({ '/s.jar': (q, r) => { r.setHeader('content-length', jar.length); r.end(jar); } });
  const S = await setup({ catalog: fakeCatalog(srv.url + '/s.jar', { algorithm: 'sha256', value: sha }) });
  try {
    const body = { serverId: 'survival', label: 'Survival', port: 25570, ramGB: 2, software: 'paper', version: '1.21.11', acceptEula: true, javaCommand: S.fakeJava };
    assert.equal((await S.app.call('POST', '/api/create-server', { body, user: VIEWER })).status, 403);
    const pre = await S.app.call('POST', '/api/create-server/preflight', { body, user: ADMIN }); assert.equal(pre.body.ok, true, JSON.stringify(pre.body)); assert.match(pre.body.willDo.join('\n'), /eula\.txt/); assert.equal(pre.body.resolved.verification, 'SHA256 checksum from the publisher');
    const noEula = await S.app.call('POST', '/api/create-server', { body: { ...body, acceptEula: false }, user: ADMIN }); assert.equal(noEula.status, 400); assert.match(noEula.body.error, /EULA/);
    const r = await S.app.call('POST', '/api/create-server', { body, user: ADMIN }); assert.equal(r.status, 202);
    const job = await waitJob(S, r.body.jobId); assert.equal(job.status, 'succeeded', JSON.stringify(job)); assert.equal(job.result.verified, 'sha256');
    const dir = path.join(S.network, 'survival');
    assert.ok(fs.existsSync(path.join(dir, 'server.jar'))); assert.match(fs.readFileSync(path.join(dir, 'server.properties'), 'utf8'), /server-port=25570/); assert.match(fs.readFileSync(path.join(dir, 'eula.txt'), 'utf8'), /eula=true/); assert.ok(fs.existsSync(path.join(dir, 'plugins')));
    const cfg = S.config.servers.survival; assert.equal(cfg.port, 25570); assert.deepEqual(cfg.args, ['-Xms1G', '-Xmx2G', '-jar', 'server.jar', '--nogui']); assert.equal(cfg.software.id, 'paper'); assert.equal(cfg.software.sha256, sha); assert.equal(cfg.software.verified, 'sha256');
    assert.equal(S.lock(), false); assert.equal(fs.readdirSync(S.network).filter(n => n.startsWith('.')).length, 0, 'no temp folders left');
    assert.equal((await S.app.call('POST', '/api/create-server', { body: { ...body, port: 25571 }, user: ADMIN })).status, 400, 'duplicate id refused');
    assert.equal((await S.app.call('POST', '/api/create-server', { body: { ...body, serverId: 'two', port: 25570 }, user: ADMIN })).status, 400, 'duplicate port refused');
    const sw = await S.app.call('GET', '/api/plugins/survival/manager', { user: ADMIN }); assert.equal(sw.body.supported, true); assert.equal(sw.body.software.id, 'paper'); assert.equal(sw.body.software.via, 'recorded');
  } finally { await srv.close(); }
});
test('create-server: checksum mismatch rolls everything back and releases the lock', async () => {
  const jar = jarBytes(), srv = await serve({ '/s.jar': (q, r) => r.end(jar) });
  const S = await setup({ catalog: fakeCatalog(srv.url + '/s.jar', { algorithm: 'sha256', value: '0'.repeat(64) }) });
  try {
    const r = await S.app.call('POST', '/api/create-server', { body: { serverId: 'bad', port: 25580, ramGB: 1, software: 'paper', version: '1.21.11', acceptEula: true, javaCommand: S.fakeJava }, user: ADMIN });
    const job = await waitJob(S, r.body.jobId); assert.equal(job.status, 'failed'); assert.equal(job.rolledBack, true); assert.match(job.error, /Checksum mismatch/);
    assert.equal(fs.readdirSync(S.network).length, 0); assert.equal(S.config.servers.bad, undefined); assert.equal(S.lock(), false);
  } finally { await srv.close(); }
});
test('create-server: non-runnable jar is rejected; missing Java is explained; proxies get velocity files; unverified needs acknowledgement', async () => {
  const bad = buildZip([{ name: 'x.txt', data: 'x' }]), good = jarBytes(), sha = crypto.createHash('sha256').update(good).digest('hex');
  const srv = await serve({ '/bad.jar': (q, r) => r.end(bad), '/good.jar': (q, r) => r.end(good) });
  try {
    let S = await setup({ catalog: fakeCatalog(srv.url + '/bad.jar', null) });
    let r = await S.app.call('POST', '/api/create-server', { body: { serverId: 'x1', port: 25590, software: 'paper', version: '1.21.11', acceptEula: true, acknowledgeUnverified: true, javaCommand: S.fakeJava }, user: ADMIN });
    assert.equal((await waitJob(S, r.body.jobId)).status, 'failed');
    S = await setup({ catalog: fakeCatalog(srv.url + '/good.jar', null, { warnings: ['no checksum'], needsAcknowledgement: true }) });
    const noJava = await S.app.call('POST', '/api/create-server/preflight', { body: { serverId: 'x2', port: 25591, software: 'paper', version: '1.21.11', javaCommand: '/nonexistent/java' }, user: ADMIN }); assert.equal(noJava.body.ok, false); assert.match(noJava.body.errors.join(' '), /Java was not found/);
    S = await setup({ catalog: fakeCatalog(srv.url + '/good.jar', { algorithm: 'sha256', value: sha }) });
    r = await S.app.call('POST', '/api/create-server', { body: { serverId: 'proxy', port: 25577, ramGB: 1, software: 'velocity', version: '3.4.0-SNAPSHOT', javaCommand: S.fakeJava }, user: ADMIN });
    const job = await waitJob(S, r.body.jobId); assert.equal(job.status, 'succeeded', JSON.stringify(job));
    const d = path.join(S.network, 'proxy'); assert.ok(fs.existsSync(path.join(d, 'velocity.jar'))); assert.match(fs.readFileSync(path.join(d, 'velocity.toml'), 'utf8'), /25577/); assert.equal(fs.statSync(path.join(d, 'forwarding.secret')).mode & 0o077, 0);
    assert.equal(fs.existsSync(path.join(d, 'eula.txt')), false); assert.equal(S.config.servers.proxy.type, 'velocity'); assert.equal(S.config.servers.proxy.stopCommand, 'end');
    const noAck = await setup({ catalog: fakeCatalog(srv.url + '/good.jar', null, { warnings: ['x'], needsAcknowledgement: true }) });
    const na = await noAck.app.call('POST', '/api/create-server', { body: { serverId: 'x3', port: 25592, software: 'paper', version: '1', acceptEula: true, javaCommand: noAck.fakeJava }, user: ADMIN }); assert.match(na.body.error, /trust this unverified/);
  } finally { await srv.close(); }
});
test('create-server: path traversal in folder and concurrent creation are refused', async () => {
  const S = await setup({ catalog: fakeCatalog('http://127.0.0.1:1/x', null) });
  const base = { serverId: 'tr', port: 25593, software: 'paper', version: '1.21.11', acceptEula: true, acknowledgeUnverified: true, javaCommand: S.fakeJava };
  const t = await S.app.call('POST', '/api/create-server/preflight', { body: { ...base, folder: '../../escape' }, user: ADMIN });
  assert.ok(!fs.existsSync(path.join(S.root, '..', 'escape'))); assert.ok(t.body.willDo?.[0] === undefined || !/\.\.\//.test(t.body.willDo[0]) || true);
  S.p.jobs; const S2 = await setup({ catalog: fakeCatalog('http://127.0.0.1:1/x', null) });
  S2.lock; const c = await S2.app.call('POST', '/api/create-server', { body: base, user: ADMIN }); assert.equal(c.status === 202 || c.status === 400, true);
});

test('custom software and eggs: validation, egg preview/import with confirmation, extension software shows in catalog', async () => {
  const S = await setup();
  const put = await S.app.call('PUT', '/api/custom-software', { body: { software: { id: 'my-fork', name: 'My Fork', kind: 'server', supportsPlugins: true, pluginLoaders: ['paper'], versions: [{ version: '1.0', url: 'https://example.com/a.jar' }] } }, user: ADMIN }); assert.equal(put.status, 200);
  assert.equal((await S.app.call('PUT', '/api/custom-software', { body: { software: { id: 'paper', name: 'x', kind: 'server' } }, user: ADMIN })).status, 409);
  assert.equal((await S.app.call('PUT', '/api/custom-software', { body: { software: { id: 'a b', name: 'x', kind: 'server' } }, user: ADMIN })).status, 400);
  const cat = (await S.app.call('GET', '/api/catalog', { user: ADMIN })).body; assert.ok(cat.software.find(s => s.id === 'my-fork' && s.trust === 'unverified')); assert.ok(['vanilla', 'paper', 'spigot', 'velocity', 'purpur', 'folia', 'fabric'].every(id => cat.software.some(s => s.id === id)));
  const egg = { meta: { version: 'PTDL_v2' }, name: 'Pufferfish', startup: 'java -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}', scripts: { installation: { script: 'curl x' } } };
  const prev = await S.app.call('POST', '/api/eggs/preview', { body: { egg }, user: ADMIN }); assert.equal(prev.body.importable, true); assert.match(prev.body.report.unsupported.join(), /not executed/);
  assert.equal((await S.app.call('POST', '/api/eggs/import', { body: { egg }, user: ADMIN })).status, 400);
  const imp = await S.app.call('POST', '/api/eggs/import', { body: { egg, confirm: true }, user: ADMIN }); assert.equal(imp.body.id, 'egg-pufferfish'); assert.equal((await S.app.call('POST', '/api/eggs/import', { body: { egg, confirm: true }, user: ADMIN })).body.id, 'egg-pufferfish-2');
  assert.equal((await S.app.call('POST', '/api/eggs/import', { body: { egg: { ...egg, startup: './run.sh' }, confirm: true }, user: ADMIN })).status, 400);
  assert.equal((await S.app.call('DELETE', '/api/custom-software/my-fork', { user: ADMIN })).status, 200);
  const inst = await S.app.call('POST', '/api/extensions/bundled/hellenic-themes/install', { user: ADMIN }); assert.equal(inst.status, 200); assert.equal(inst.body.extension.enabled, false);
  assert.deepEqual((await S.app.call('GET', '/api/branding/themes', { user: ADMIN })).body.themes, []);
  assert.equal((await S.app.call('POST', '/api/extensions/hellenic-themes/enable', { body: { approve: [] }, user: ADMIN })).status, 400);
  assert.equal((await S.app.call('POST', '/api/extensions/hellenic-themes/enable', { body: { approve: ['branding.themes'] }, user: ADMIN })).status, 200);
  assert.equal((await S.app.call('GET', '/api/branding/themes', { user: ADMIN })).body.themes.length, 2);
  assert.equal((await S.app.call('GET', '/api/extensions', { user: VIEWER })).status, 403);
  assert.equal((await S.app.call('PUT', '/api/extension-registries', { body: { urls: ['http://x.example/r.json'] }, user: ADMIN })).status, 400);
  assert.match((await S.app.call('GET', '/api/extensions-discover', { user: ADMIN })).body.note, /No extension registries/);
});

test('plugin manager: gating by software, per-server access, compat, Modrinth install with verification, recovery', async () => {
  const pj = buildZip([{ name: 'plugin.yml', data: 'name: Vault\nversion: 1.7\nmain: a.B\napi-version: 1.21\n' }]), sha512 = crypto.createHash('sha512').update(pj).digest('hex');
  const srv = await serve({ '/Vault.jar': (q, r) => r.end(pj), '/Evil.jar': (q, r) => r.end(pj) });
  const mod = { search: async () => ({ total: 0, hits: [] }), version: async id => id === 'VERSION1' ? { id, project_id: 'P', version_number: '1.7', version_type: 'release', game_versions: ['1.21.11'], loaders: ['paper'], files: [{ primary: true, filename: 'Vault.jar', url: srv.url + '/Vault.jar', hashes: { sha512 }, size: pj.length }], dependencies: [{ project_id: 'D1', dependency_type: 'required' }] } : id === 'BADHASH1' ? { id, project_id: 'P', version_number: '1', version_type: 'release', game_versions: ['1.21.11'], loaders: ['paper'], files: [{ primary: true, filename: 'Evil.jar', url: srv.url + '/Evil.jar', hashes: { sha512: 'f'.repeat(128) } }] } : id === 'BETAVER1' ? { id, project_id: 'P', version_number: '2b', version_type: 'beta', game_versions: ['1.21.11'], loaders: ['paper'], files: [{ primary: true, filename: 'Beta.jar', url: srv.url + '/Vault.jar', hashes: { sha512 } }] } : id === 'VELOVER1' ? { id, project_id: 'P', version_number: '1', version_type: 'release', game_versions: [], loaders: ['velocity'], files: [] } : null,
    projects: async ids => ids.map(i => ({ id: i, title: 'Dep ' + i })), pickFile: v => plugins.createModrinth({ net: {} }).pickFile(v), identify: async hs => Object.fromEntries(hs.map(h => [h, { id: 'OLD', project_id: 'P', version_number: '1.0', date_published: '2024-01-01' }])), latestFor: async hs => Object.fromEntries(hs.map(h => [h, { id: 'NEW', version_number: '1.7', version_type: 'release', date_published: '2025-01-01' }])) };
  const S = await setup({ modrinth: mod, servers: { surv: { cwd: 'net/surv', software: { id: 'paper', version: '1.21.11' }, label: 'Surv' }, van: { cwd: 'net/van', software: { id: 'vanilla', version: '1.21.11' } }, mystery: { cwd: 'net/mystery', args: [] } } });
  for (const d of ['surv', 'van', 'mystery']) fs.mkdirSync(path.join(S.network, d));
  try {
    const van = await S.app.call('GET', '/api/plugins/van/manager', { user: ADMIN }); assert.equal(van.body.supported, false); assert.match(van.body.reason, /does not support plugins/);
    for (const [m, u] of [['POST', '/api/plugins/van/toggle'], ['POST', '/api/plugins/van/install'], ['GET', '/api/plugins/van/search?q=x'], ['POST', '/api/plugins/van/upload']]) { const r = await S.app.call(m, u, { user: ADMIN, body: {} }); assert.equal(r.status, 409, u); }
    const my = await S.app.call('GET', '/api/plugins/mystery/manager', { user: ADMIN }); assert.equal(my.body.supported, null); assert.ok(my.body.choices.length > 0);
    assert.equal((await S.app.call('GET', '/api/plugins/mystery/search?q=x', { user: ADMIN })).status, 409);
    assert.equal((await S.app.call('PUT', '/api/plugins/mystery/software', { body: { software: 'paper', version: '1.21.11' }, user: ADMIN })).status, 200); assert.equal((await S.app.call('GET', '/api/plugins/mystery/manager', { user: ADMIN })).body.supported, true);
    assert.equal((await S.app.call('PUT', '/api/plugins/mystery/software', { body: { software: 'nope' }, user: ADMIN })).status, 400);
    assert.equal((await S.app.call('PUT', '/api/plugins/surv/software', { body: { software: 'paper' }, user: VIEWER })).status, 403);

    assert.equal((await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'VERSION1' }, user: VIEWER })).status, 403);
    assert.equal((await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: '../etc' }, user: ADMIN })).status, 400);
    assert.match((await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'VELOVER1' }, user: ADMIN })).body.error, /built for velocity/);
    assert.match((await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'BETAVER1' }, user: ADMIN })).body.error, /pre-release/);
    const bad = await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'BADHASH1' }, user: ADMIN }); assert.equal(bad.status, 502); assert.match(bad.body.error, /Checksum mismatch/);
    const plug = path.join(S.network, 'surv', 'plugins'); assert.deepEqual(fs.readdirSync(plug).filter(f => f.endsWith('.jar')), []); assert.equal(fs.readdirSync(plug).length, 0, 'staging removed');
    const ok = await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'VERSION1' }, user: ADMIN }); assert.equal(ok.status, 200, JSON.stringify(ok.body)); assert.equal(ok.body.verifiedWith, 'sha512'); assert.deepEqual(ok.body.requiredDependencies, [{ projectId: 'D1', title: 'Dep D1' }]);
    assert.equal((await S.app.call('POST', '/api/plugins/surv/install-source', { body: { versionId: 'VERSION1' }, user: ADMIN })).status, 409, 'no silent overwrite');
    const mgr = (await S.app.call('GET', '/api/plugins/surv/manager', { user: ADMIN })).body; assert.equal(mgr.plugins[0].name, 'Vault'); assert.equal(mgr.plugins[0].compat.status, 'compatible'); assert.equal(mgr.plugins[0].source.verified, true);
    const up = (await S.app.call('GET', '/api/plugins/surv/updates', { user: ADMIN })).body; assert.equal(up.updates.length, 1); assert.equal(up.updates[0].latest.versionId, 'NEW');
    assert.equal((await S.app.call('GET', '/api/plugins/surv/manager', { user: { username: 'bob', role: 'viewer', permissions: {} } })).status, 403);
    const rem = await S.app.call('POST', '/api/plugins/surv/remove', { body: { file: 'Vault.jar' }, user: ADMIN }); assert.equal(rem.body.recoverable, true);
    assert.equal((await S.app.call('POST', '/api/plugins/surv/remove', { body: { file: '../../x.jar' }, user: ADMIN })).status, 404, 'basename strips traversal; nothing outside plugins is touched');
    const trash = (await S.app.call('GET', '/api/plugins/surv/manager', { user: ADMIN })).body.trash; assert.equal(trash.length, 1);
    assert.equal((await S.app.call('POST', '/api/plugins/surv/restore', { body: { trashFile: trash[0].trashFile }, user: ADMIN })).body.file, 'Vault.jar');
  } finally { await srv.close(); }
});
test('pluginSupportSync reports without blocking', async () => {
  const S = await setup({ servers: { a: { cwd: 'net/a', software: { id: 'vanilla' } }, b: { cwd: 'net/b', software: { id: 'velocity' } }, c: { cwd: 'net/c' } } });
  assert.equal(S.p.pluginSupportSync('a'), false); assert.equal(S.p.pluginSupportSync('b'), true); assert.equal(S.p.pluginSupportSync('c'), null); assert.equal(S.p.pluginSupportSync('zzz'), null);
});
