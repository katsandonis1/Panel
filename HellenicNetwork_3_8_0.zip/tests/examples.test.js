'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const { Readable } = require('stream');
const net = require('../lib/net');
const { setup, ADMIN, VIEWER } = require('./harness');
const DIR = path.join(__dirname, '..', 'extensions-examples');
const pkg = n => ({ buffer: fs.readFileSync(path.join(DIR, fs.readdirSync(DIR).find(f => f.startsWith(n + '-') && f.endsWith('.hnx')))), originalname: n + '.hnx' });
const SERVERS = { surv: { cwd: 'net/surv', label: 'Survival', port: 25565 }, lobby: { cwd: 'net/lobby', label: 'Lobby', port: 25566 } };

async function install(S, name) {
  const r = await S.app.call('POST', '/api/extensions/install', { user: ADMIN, file: pkg(name) }); assert.equal(r.status, 200, name + ': ' + JSON.stringify(r.body));
  const e = await S.app.call('POST', `/api/extensions/${name}/enable`, { user: ADMIN, body: { approve: r.body.extension.manifest.permissions } }); assert.equal(e.status, 200, JSON.stringify(e.body)); S.p.host.invalidate(); return r.body.extension;
}
const find = (n, pred) => { if (!n) return null; if (pred(n)) return n; for (const k of [...(n.children || []), ...(n.tabs || []).flatMap(t => t.children)]) { const f = find(k, pred); if (f) return f; } return null; };

test('every example package validates and installs; sensitive permissions and hosts are visible for approval', async () => {
  const S = await setup({ servers: SERVERS }); assert.ok(fs.readdirSync(DIR).filter(f => f.endsWith('.hnx')).length >= 6);
  for (const n of ['quick-actions', 'scheduled-restarts', 'punishments', 'dashboard-widget', 'translations-pack', 'ai-assistant']) await install(S, n);
  const list = (await S.app.call('GET', '/api/extensions', { user: ADMIN })).body; assert.equal(list.installed.length, 6);
  const ai = list.installed.find(x => x.id === 'ai-assistant'); assert.deepEqual(ai.manifest.permissions.filter(p => p.startsWith('http:')), ['http:api.anthropic.com', 'http:api.openai.com', 'http:discord.com']); assert.ok(list.sensitive.includes('http'));
  assert.ok(Object.hasOwn(list.permissions, 'players.moderate'));
});

test('quick actions: buttons and broadcast send the declared commands; viewers without console permission are refused', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'quick-actions');
  const v = (await S.app.call('GET', '/api/ext/quick-actions/pages/actions', { user: ADMIN })).body, kids = v.page.content.children;
  const day = find(v.page.content, n => n.type === 'button' && n.label === 'Set day'), form = find(v.page.content, n => n.type === 'form');
  await S.app.call('POST', '/api/ext/quick-actions/action', { user: ADMIN, body: { page: 'actions', path: day.path, serverId: 'surv' } }); assert.deepEqual(S.commands.at(-1), { id: 'surv', command: 'time set day' });
  await S.app.call('POST', '/api/ext/quick-actions/action', { user: ADMIN, body: { page: 'actions', path: form.path, serverId: 'lobby', values: { message: 'Hi all' } } }); assert.deepEqual(S.commands.at(-1), { id: 'lobby', command: 'say Hi all' });
  assert.equal((await S.app.call('GET', '/api/ext/ui', { user: VIEWER })).body.pages.length, 0, 'page requires console_command'); assert.ok(kids.length > 0);
});

test('punishments: warn/kick/ban/temp-ban/pardon, history, staff attribution, expiry job never lifts permanent bans', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'punishments');
  const v = (await S.app.call('GET', '/api/ext/punishments/pages/manage', { user: ADMIN })).body.page.content;
  const forms = []; (function walk(n) { if (!n) return; if (n.type === 'form') forms.push(n); (n.children || []).forEach(walk); (n.tabs || []).forEach(t => t.children.forEach(walk)); })(v);
  assert.equal(forms.length, 5); const [warn, kick, ban, temp, pardon] = forms;
  const run = (f, values) => S.app.call('POST', '/api/ext/punishments/action', { user: ADMIN, body: { page: 'manage', path: f.path, serverId: 'surv', values } });
  assert.equal((await run(warn, { player: 'Alex', reason: 'be nice' })).status, 200); assert.equal(S.commands.at(-1).command, 'tell Alex [Warning] be nice');
  assert.equal((await run(kick, { player: 'Alex', reason: 'afk' })).status, 200); assert.equal(S.commands.at(-1).command, 'kick Alex afk');
  assert.equal((await run(ban, { player: 'Griefer', reason: 'tnt' })).status, 200); assert.equal(S.commands.at(-1).command, 'ban Griefer tnt');
  assert.equal((await run(temp, { player: 'Spammer', reason: 'spam', minutes: 30 })).status, 200); assert.equal(S.commands.at(-1).command, 'ban Spammer spam');
  assert.equal((await run(temp, { player: 'Bad;stop', reason: 'x', minutes: 5 })).status, 400, 'invalid player names are refused');
  assert.equal((await run(temp, { player: 'Nobody', reason: 'x', minutes: 0 })).status, 400, 'duration limits are enforced');
  const table = find(v, n => n.type === 'table'), rows = async () => (await S.app.call('POST', '/api/ext/punishments/source', { user: ADMIN, body: { page: 'manage', path: table.path, serverId: 'surv' } })).body.rows;
  let r = await rows(); assert.equal(r.length, 4); const sp = r.find(x => x.player === 'Spammer'); assert.equal(sp.staff, 'root'); assert.equal(sp.status, 'active'); assert.ok(new Date(sp.expiresAt) > new Date(Date.now() + 25 * 60000));
  assert.equal((await S.app.call('POST', '/api/ext/punishments/source', { user: ADMIN, body: { page: 'manage', path: table.path } })).body.needsServer, true);
  // expire the temp-ban by rewriting its date into the past, leave the permanent ban alone
  S.p.host.storage.update('punishments', 'punishments', sp._id, { expiresAt: '2000-01-01T00:00:00.000Z' });
  const job = (await S.p.host.getActive('punishments')).manifest.jobs[0]; S.commands.length = 0; await S.p.host.runSteps('punishments', job.do, {}, { type: 'ext', ext: 'punishments' });
  assert.deepEqual(S.commands.map(c => c.command), ['pardon Spammer'], 'only the expired temp-ban is lifted'); r = await rows(); assert.equal(r.find(x => x.player === 'Spammer').status, 'expired'); assert.equal(r.find(x => x.player === 'Griefer').status, 'active');
  S.commands.length = 0; await S.p.host.runSteps('punishments', job.do, {}, { type: 'ext', ext: 'punishments' }); assert.equal(S.commands.length, 0, 'idempotent');
  // pardon from the table, then via the pardon form
  const g = r.find(x => x.player === 'Griefer'); assert.equal((await S.app.call('POST', '/api/ext/punishments/action', { user: ADMIN, body: { page: 'manage', path: table.path, index: 0, serverId: 'surv', row: g } })).status, 200); assert.equal(S.commands.at(-1).command, 'pardon Griefer');
  assert.equal((await rows()).find(x => x.player === 'Griefer' && x.type === 'ban').status, 'pardoned');
  assert.equal((await S.app.call('GET', '/api/ext/punishments/pages/manage', { user: VIEWER })).status, 403, 'needs players_actions');
});

test('scheduled restarts: warn then restart at the configured times using the configured server', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'scheduled-restarts');
  await S.app.call('PUT', '/api/extensions/scheduled-restarts/settings', { user: ADMIN, body: { values: { serverId: 'surv', warnTime: '05:10', restartTime: '05:11', warningText: 'Restart soon' } } });
  const at = (h, m, s) => new Date(2026, 3, 1, h, m, s);
  await S.p.host.tick(at(5, 9, 0)); await S.p.host.tick(at(5, 10, 10)); assert.deepEqual(S.commands.at(-1), { id: 'surv', command: 'say Restart soon' }); assert.deepEqual(S.controls, []);
  await S.p.host.tick(at(5, 11, 5)); assert.deepEqual(S.controls, [{ id: 'surv', action: 'restart' }]); assert.ok(S.commands.some(c => c.command === 'save-all'));
  const list = (await S.app.call('GET', '/api/extensions', { user: ADMIN })).body.installed[0]; assert.equal(list.jobs.length, 2); assert.equal(list.jobs[1].schedule, 'daily at 05:11');
  assert.equal((await S.app.call('PUT', '/api/extensions/scheduled-restarts/settings', { user: ADMIN, body: { values: { warnTime: 5 } } })).status, 400);
});

test('dashboard widget and AI pages are sandboxed frames; their bridge access is limited to what each page declares', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'dashboard-widget'); await install(S, 'ai-assistant');
  for (const [ext, file] of [['dashboard-widget', 'index.html'], ['ai-assistant', 'index.html'], ['ai-assistant', 'app.js']]) { const f = await S.app.call('GET', `/ext-frame/${ext}/${file}`, { user: ADMIN }); assert.equal(f.status, 200, ext + file); assert.match(f.headers['Content-Security-Policy'], /connect-src 'none'/); }
  assert.equal((await S.app.call('GET', '/ext-frame/ai-assistant/transcripts.html', { user: VIEWER })).status, 403, 'transcripts page is admin-only');
  const st = await S.app.call('POST', '/api/ext/dashboard-widget/bridge', { user: ADMIN, body: { page: 'dash', capability: 'servers.status', args: { serverId: 'surv' } } }); assert.equal(st.body.result.label, 'Survival'); assert.equal(st.body.result.playersOnline, 2);
  assert.equal((await S.app.call('POST', '/api/ext/dashboard-widget/bridge', { user: ADMIN, body: { page: 'dash', capability: 'servers.command', args: { serverId: 'surv', command: 'stop' } } })).status, 403);
  assert.equal((await S.app.call('POST', '/api/ext/ai-assistant/bridge', { user: VIEWER, body: { page: 'transcripts', capability: 'storage.list', args: { prefix: 'tx:' } } })).status, 403, 'non-admins cannot use the transcript bridge');
});

test('AI assistant: key stays server-side, only approved hosts reachable, webhook secret resolved server-side, history is per user', async () => {
  const sent = [];
  const fake = { ...net, openStream: async (url, o) => { sent.push({ url, ...o }); const body = url.includes('anthropic') ? { content: [{ type: 'text', text: 'Hello from the model' }] } : {}; return { status: 200, stream: Readable.from([Buffer.from(JSON.stringify(body))]) }; } };
  const S = await setup({ servers: SERVERS, net: fake }); await install(S, 'ai-assistant');
  await S.app.call('PUT', '/api/extensions/ai-assistant/settings', { user: ADMIN, body: { values: { provider: 'anthropic', model: 'test-model', apiKey: 'sk-test-12345', webhookEnabled: true, webhookUrl: 'https://discord.com/api/webhooks/1/abc' } } });
  const view = (await S.app.call('GET', '/api/ext/ai-assistant/pages/chat', { user: ADMIN })).body; assert.equal(view.page.settings.model, 'test-model'); assert.ok(!JSON.stringify(view).includes('sk-test') && !JSON.stringify(view).includes('discord.com/api'));
  const bridge = (capability, args, user = ADMIN) => S.app.call('POST', '/api/ext/ai-assistant/bridge', { user, body: { page: 'chat', capability, args } });
  const r = await bridge('http.request', { url: 'https://api.anthropic.com/v1/messages', method: 'POST', headers: { 'x-api-key': '{{secret.apiKey}}' }, body: { model: 'm', messages: [] } });
  assert.equal(r.status, 200); assert.equal(sent[0].headers['x-api-key'], 'sk-test-12345'); assert.ok(!JSON.stringify(r.body).includes('sk-test')); assert.deepEqual(sent[0].allowHosts, ['api.anthropic.com', 'api.openai.com', 'discord.com']);
  const w = await bridge('http.request', { url: '{{secret.webhookUrl}}', method: 'POST', body: { content: 'x' } }); assert.equal(w.status, 200); assert.equal(sent[1].url, 'https://discord.com/api/webhooks/1/abc');
  for (const url of ['https://evil.example/steal', 'https://api.anthropic.com.evil.com/x', 'http://api.anthropic.com/x']) assert.ok([400, 403].includes((await bridge('http.request', { url, method: 'POST', body: {} })).status), url);
  assert.equal(sent.length, 2, 'blocked requests never left the panel');
  await bridge('storage.set', { key: 'history', scope: 'user', value: [{ role: 'user', content: 'mine' }] }, ADMIN);
  assert.deepEqual((await bridge('storage.get', { key: 'history', scope: 'user' }, ADMIN)).body.result, [{ role: 'user', content: 'mine' }]);
  assert.equal((await bridge('storage.get', { key: 'history', scope: 'user' }, { username: 'bob', role: 'viewer', permissions: {} })).body.result, null, 'another user has their own history');
  assert.ok(!JSON.stringify(S.state).includes('sk-test-12345') && !JSON.stringify(S.state).includes('abc'), 'secrets are encrypted at rest');
});

test('translations pack: 11 languages on top of core English; RTL for Arabic; completeness is reported', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'translations-pack');
  const langs = (await S.app.call('GET', '/api/i18n/en')).body.languages.map(l => l.code); for (const c of ['en', 'es', 'ru', 'de', 'fr', 'pt', 'tr', 'zh', 'it', 'nl', 'ar', 'ja']) assert.ok(langs.includes(c), c);
  const de = (await S.app.call('GET', '/api/i18n/de')).body; assert.equal(de.messages['nav.players'], 'Spieler'); const ar = (await S.app.call('GET', '/api/i18n/ar')).body; assert.equal(ar.dir, 'rtl'); assert.match(ar.messages['nav.overview'], /نظرة/);
  const rep = (await S.app.call('GET', '/api/i18n-report', { user: ADMIN })).body.report; for (const row of rep.filter(x => x.code !== 'en')) assert.equal(row.percent, 100, row.code + ' ' + row.missing.join());
});

test('safe mode: one switch pauses every extension (pages, actions, jobs, events, translations) and is admin-only and reversible', async () => {
  const S = await setup({ servers: SERVERS }); await install(S, 'quick-actions'); await install(S, 'translations-pack'); await install(S, 'scheduled-restarts');
  const day = find((await S.app.call('GET', '/api/ext/quick-actions/pages/actions', { user: ADMIN })).body.page.content, n => n.label === 'Set day');
  assert.equal((await S.app.call('GET', '/api/i18n/de')).body.messages['nav.players'], 'Spieler');
  assert.equal((await S.app.call('PUT', '/api/extensions-safe-mode', { user: VIEWER, body: { enabled: true } })).status, 403);
  assert.equal((await S.app.call('PUT', '/api/extensions-safe-mode', { user: ADMIN, body: { enabled: true } })).body.safeMode, true);
  assert.equal((await S.app.call('GET', '/api/ext/ui', { user: ADMIN })).body.pages.length, 0);
  assert.equal((await S.app.call('POST', '/api/ext/quick-actions/action', { user: ADMIN, body: { page: 'actions', path: day.path, serverId: 'surv' } })).status, 404); assert.equal(S.commands.length, 0);
  assert.equal((await S.app.call('GET', '/api/i18n/de')).body.messages['nav.players'], 'Players', 'translations pause too');
  await S.p.host.tick(new Date(2026, 3, 1, 4, 0, 5)); await S.p.host.tick(new Date(2026, 3, 1, 4, 0, 10)); assert.deepEqual(S.controls, []);
  assert.equal((await S.app.call('GET', '/api/extensions', { user: ADMIN })).status, 200, 'the admin page still works so it can be switched off');
  await S.app.call('PUT', '/api/extensions-safe-mode', { user: ADMIN, body: { enabled: false } }); S.p.host.invalidate();
  assert.equal((await S.app.call('GET', '/api/ext/ui', { user: ADMIN })).body.pages.length, 1);
});
