'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const { tmp } = require('./helpers');
const { buildZip } = require('../lib/zip');
const { createCatalog } = require('../lib/catalog');
const branding = require('../lib/branding');
const { createExtensionManager, inspectPackage } = require('../lib/extensions');
const plugins = require('../lib/plugins');

// ---- catalog with vendor-shaped fixtures (shapes follow the vendors' documented APIs; live calls are not made in tests)
function fakeNet(map) {
  const calls = [];
  return { calls, NetError: class extends Error { constructor(m, code) { super(m); this.code = code; } }, getJson: async (url, o) => { calls.push(url); if (url in map) return typeof map[url] === 'function' ? map[url]() : map[url]; const e = new Error('nf'); e.code = 'NET_NOT_FOUND'; throw e; } };
}
const FILL = 'https://fill.papermc.io/v3/projects';
const fixtures = () => ({
  'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json': { latest: { release: '1.21.11' }, versions: [{ id: '1.21.11', type: 'release', url: 'https://piston-meta.mojang.com/v1/packages/x/1.21.11.json', releaseTime: 't' }, { id: '1.21.10', type: 'release', url: 'https://piston-meta.mojang.com/v1/packages/x/1.21.10.json' }, { id: '25w01a', type: 'snapshot', url: 'u' }, { id: '1.7.10', type: 'release', url: 'https://piston-meta.mojang.com/v1/packages/x/1.7.10.json' }] },
  'https://piston-meta.mojang.com/v1/packages/x/1.21.11.json': { javaVersion: { majorVersion: 21 }, downloads: { server: { url: 'https://piston-data.mojang.com/v1/objects/abc/server.jar', sha1: 'abc', size: 5 } } },
  'https://piston-meta.mojang.com/v1/packages/x/1.21.10.json': { javaVersion: { majorVersion: 21 }, downloads: {} },
  [`${FILL}/paper`]: { project: { id: 'paper' }, versions: { '1.21': ['1.21.11', '1.21.10'], '1.20': ['1.20.6'] } },
  [`${FILL}/paper/versions/1.21.11/builds`]: [{ id: 10, channel: 'ALPHA', downloads: { 'server:default': { name: 'paper-1.21.11-10.jar', url: 'https://fill-data.papermc.io/a', checksums: { sha256: 'aa' }, size: 1 } } }, { id: 9, channel: 'STABLE', downloads: { 'server:default': { name: 'paper-1.21.11-9.jar', url: 'https://fill-data.papermc.io/b', checksums: { sha256: 'bb' }, size: 1 } } }],
  [`${FILL}/paper/versions/1.21.10/builds`]: [],
  [`${FILL}/velocity`]: { versions: { '3.4.0': ['3.4.0-SNAPSHOT', '3.3.0-SNAPSHOT'] } },
  [`${FILL}/velocity/versions/3.4.0-SNAPSHOT/builds`]: [{ id: 5, channel: 'STABLE', downloads: { 'server:default': { name: 'velocity-3.4.0-SNAPSHOT-5.jar', url: 'https://fill-data.papermc.io/v', checksums: { sha256: 'cc' } } } }],
  'https://api.purpurmc.org/v2/purpur': { versions: ['1.21.10', '1.21.11'] },
  'https://api.purpurmc.org/v2/purpur/1.21.11': { builds: { latest: '2500', all: ['2499', '2500'] } },
  'https://api.purpurmc.org/v2/purpur/1.21.11/2500': { result: 'SUCCESS', md5: 'd41d8cd98f00b204e9800998ecf8427e' },
  'https://meta.fabricmc.net/v2/versions/game': [{ version: '1.21.11', stable: true }, { version: '25w01a', stable: false }],
  'https://meta.fabricmc.net/v2/versions/loader': [{ version: '0.17.0', stable: false }, { version: '0.16.9', stable: true }],
  'https://meta.fabricmc.net/v2/versions/installer': [{ version: '1.0.1', stable: true }],
  'https://hub.spigotmc.org/versions/1.21.11.json': { refs: {} }
});
test('catalog: lists stable versions newest-first and flags the target', async () => {
  const c = createCatalog({ net: fakeNet(fixtures()) });
  const v = await c.listVersions('vanilla'); assert.deepEqual(v.versions.map(x => x.version), ['1.21.11', '1.21.10', '1.7.10']); assert.equal(v.targetAvailable, true);
  assert.deepEqual((await c.listVersions('paper')).versions.map(x => x.version), ['1.21.11', '1.21.10', '1.20.6']);
  assert.deepEqual((await c.listVersions('fabric')).versions.map(x => x.version), ['1.21.11']);
  assert.equal((await c.listVersions('spigot')).versions.some(x => x.version === '1.7.10'), false);
  assert.equal((await c.listVersions('velocity')).versions[0].version, '3.4.0-SNAPSHOT');
  await assert.rejects(c.listVersions('nope'), /Unknown/);
});
test('catalog: resolves verified downloads and never invents builds', async () => {
  const c = createCatalog({ net: fakeNet(fixtures()) });
  const van = await c.resolve('vanilla', '1.21.11'); assert.deepEqual(van.expected, { algorithm: 'sha1', value: 'abc' }); assert.equal(van.javaMajor, 21);
  const paper = await c.resolve('paper', '1.21.11'); assert.equal(paper.build, '9', 'prefers newest STABLE over newer ALPHA'); assert.equal(paper.expected.algorithm, 'sha256');
  const alpha = await c.resolve('paper', '1.21.11', '10'); assert.equal(alpha.build, '10');
  await assert.rejects(c.resolve('paper', '1.21.11', '999'), /does not publish build 999/);
  await assert.rejects(c.resolve('paper', '1.21.10'), /any builds/);
  await assert.rejects(c.resolve('paper', '9.9.9'), /does not publish paper for 9.9.9/);
  await assert.rejects(c.resolve('vanilla', '1.21.10'), /server download/);
  await assert.rejects(c.resolve('vanilla', '0.0'), /does not publish version/);
  const pur = await c.resolve('purpur', '1.21.11'); assert.equal(pur.expected.algorithm, 'md5'); assert.match(pur.warnings[0], /MD5/);
  await assert.rejects(c.resolve('purpur', '1.19'), /does not publish/);
  const fab = await c.resolve('fabric', '1.21.11'); assert.match(fab.url, /0\.16\.9\/1\.0\.1\/server\/jar$/); assert.equal(fab.expected, null); assert.match(fab.warnings[0], /does not publish a checksum/);
  await assert.rejects(c.resolve('fabric', '25w01a'), /stable/);
  const vel = await c.resolve('velocity', '3.4.0-SNAPSHOT'); assert.equal(vel.jar, 'velocity.jar'); assert.equal(vel.javaMajor, 17);
  const sp = await c.resolve('spigot', '1.21.11'); assert.equal(sp.method, 'buildtools'); assert.equal(sp.buildRevision, '1.21.11');
  await assert.rejects(c.resolve('spigot', '1.21.99'), /does not publish a build revision/);
  await assert.rejects(c.resolve('paper', '1.21.11; rm -rf'), /valid version/);
});
test('catalog: unexpected vendor responses fail loudly instead of guessing', async () => {
  const f = fixtures(); f[`${FILL}/paper`] = { oops: true };
  await assert.rejects(createCatalog({ net: fakeNet(f) }).listVersions('paper'), /unexpected response/);
});
test('catalog: caches vendor responses', async () => {
  const n = fakeNet(fixtures()), c = createCatalog({ net: n }); await c.listVersions('paper'); await c.listVersions('paper');
  assert.equal(n.calls.filter(u => u === `${FILL}/paper`).length, 1);
});

// ---- branding
test('branding: validation, contrast guard, labels and links', () => {
  assert.equal(branding.DEFAULT_NAME, 'Hellenic Network');
  const ok = branding.validate({ name: ' My  Net ', colors: { accent: '#FF0000' }, labels: { overview: 'Home', settings: 'Settings' }, links: [{ label: 'Discord', url: 'https://discord.gg/x' }], footer: 'hi' });
  assert.deepEqual(ok.errors, []); assert.equal(ok.value.name, 'My Net'); assert.equal(ok.value.colors.accent, '#ff0000'); assert.deepEqual(ok.value.labels, { overview: 'Home' });
  for (const [bad, re] of [[{ name: '' }, /Panel name/], [{ name: 'x'.repeat(41) }, /Panel name/], [{ colors: { accent: 'red' } }, /hex/], [{ colors: { nope: '#000000' } }, /Unknown color/], [{ labels: { hax: 'x' } }, /Unknown label/], [{ links: [{ label: 'x', url: 'javascript:alert(1)' }] }, /http/], [{ links: [{ label: 'x', url: 'https://a:b@c.d' }] }, /credentials/], [{ footer: 'x'.repeat(201) }, /Footer/], [{ colors: { text: '#111111' } }, /contrast/], [{ colors: { accent: '#07101f' } }, /accent/]])
    assert.match(branding.validate(bad).errors[0], re, JSON.stringify(bad));
  const reset = branding.validate({ labels: { overview: '' } }, ok.value); assert.deepEqual(reset.value.labels, {});
});
test('branding: html is escaped and defaults render', () => {
  const html = '<html><head><title>X</title><meta name="theme-color" content="#000"></head><body><div class="brand" data-brand-name>old</div></body></html>';
  const out = branding.renderIndex(html, { name: '<script>x</script> & Co', colors: {} });
  assert.ok(!out.includes('<script>x')); assert.match(out, /&lt;script&gt;x&lt;\/script&gt; &amp; Co/); assert.match(out, /branding\.css/);
  assert.match(branding.renderIndex(html, undefined), /Hellenic Network/);
  assert.match(branding.cssFor({ colors: { accent: '#123456' } }), /--cyan:#123456/);
  assert.equal(branding.manifestFor({ name: 'N', shortName: 'S' }).short_name, 'S');
});
test('branding: images are validated by content, SVG refused, assets stored under fixed names', async () => {
  const png = Buffer.alloc(64); Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(png); png.writeUInt32BE(64, 16); png.writeUInt32BE(64, 20);
  const up = k => branding.parseImageUpload(k, 'data:image/png;base64,' + png.toString('base64'));
  assert.equal(up('logo').ext, 'png');
  assert.match(branding.parseImageUpload('logo', 'data:image/svg+xml;base64,' + Buffer.from('<svg onload=alert(1)>').toString('base64')).error, /not a supported image/);
  assert.match(branding.parseImageUpload('logo', 'data:image/png;base64,' + Buffer.from('<html>').toString('base64')).error, /not a supported/);
  assert.ok(branding.parseImageUpload('icon', 'data:image/png;base64,' + Buffer.alloc(600 * 1024).toString('base64')).error);
  const big = Buffer.from(png); big.writeUInt32BE(5000, 16); assert.match(branding.parseImageUpload('logo', 'data:image/png;base64,' + big.toString('base64')).error, /dimensions/);
  const d = tmp(); await branding.saveAsset(d, 'logo', up('logo')); assert.ok((await branding.findAsset(d, 'logo')).endsWith('logo.png'));
});

// ---- extensions
const manifest = (o = {}) => ({ schemaVersion: 1, id: 'demo-ext', name: 'Demo', version: '1.0.0', permissions: ['navigation.links', 'branding.themes'], provides: { links: [{ label: 'Docs', url: 'https://example.com/docs' }], themes: [{ id: 'tt', name: 'T', colors: { accent: '#5aa9ff' } }] }, settings: [{ key: 'greeting', label: 'Greeting', type: 'string', default: 'hi' }], ...o });
const pkg = (m, extra = []) => buildZip([{ name: 'extension.json', data: JSON.stringify(m) }, ...extra]);
function mgr() { const state = {}, d = tmp(); return { state, d, m: createExtensionManager({ dataDir: d, bundledDir: path.join(__dirname, '..', 'bundled-extensions'), state, saveState() {}, panelVersion: '3.7.0' }) }; }
test('extensions: install requires explicit permission approval before anything is contributed', async () => {
  const { m } = mgr(); const r = await m.installPackage(pkg(manifest()));
  assert.equal(r.record.enabled, false); assert.deepEqual((await m.contributions()).links, []);
  await assert.rejects(m.enable('demo-ext', ['navigation.links']), /Approve every permission/);
  await m.enable('demo-ext', ['navigation.links', 'branding.themes']);
  const c = await m.contributions(); assert.equal(c.links[0].label, 'Docs'); assert.equal(c.themes[0].id, 'demo-ext:tt');
  await m.disable('demo-ext'); assert.deepEqual((await m.contributions()).links, []);
});
test('extensions: code, traversal, undeclared permissions and bad manifests are rejected', async () => {
  const { m } = mgr();
  await assert.rejects(m.installPackage(pkg(manifest(), [{ name: 'run.js', data: 'x' }])), e => /rejected/.test(e.message) && /cannot contain code/.test(e.details.join()));
  await assert.rejects(m.installPackage(pkg(manifest(), [{ name: '../evil.json', data: '{}' }])), e => /Unsafe/.test(e.details.join()));
  await assert.rejects(m.installPackage(pkg(manifest({ permissions: [] }))), e => /requires the/.test(e.details.join()));
  await assert.rejects(m.installPackage(pkg(manifest({ id: 'Bad Id' }))), e => /id must be/.test(e.details.join()));
  await assert.rejects(m.installPackage(pkg(manifest({ panel: { min: '9.0.0' } }))), /Requires panel 9\.0\.0/);
  await assert.rejects(m.installPackage(pkg(manifest({ provides: { themes: [{ id: 'tt', name: 'T', colors: { text: '#111111' } }] } }))), e => /contrast/.test(e.details.join()));
  await assert.rejects(m.installPackage(Buffer.from('garbage')), /not a valid package/);
  await assert.rejects(m.installPackage(buildZip([{ name: 'readme.md', data: 'x' }])), /no extension.json/);
});
test('extensions: update keeps settings, raises approval for new permissions, and can be rolled back', async () => {
  const { m, d } = mgr(); await m.installPackage(pkg(manifest())); await m.enable('demo-ext', ['navigation.links', 'branding.themes']); await m.setSettings('demo-ext', { greeting: 'yo' });
  await assert.rejects(m.installPackage(pkg(manifest())), /already installed/);
  await assert.rejects(m.installPackage(pkg(manifest({ version: '0.9.0' }))), /older than/);
  const up = await m.installPackage(pkg(manifest({ version: '1.1.0', permissions: ['navigation.links', 'branding.themes', 'software.provide'] })));
  assert.deepEqual(up.addedPermissions, ['software.provide']); assert.equal(up.record.enabled, false); assert.equal(up.record.needsApproval, true);
  assert.equal((await m.view('demo-ext')).settings.greeting, 'yo');
  const rb = await m.rollback('demo-ext'); assert.equal(rb.version, '1.0.0'); assert.equal(rb.enabled, false); assert.equal(rb.canRollback, true);
  await assert.rejects(m.setSettings('demo-ext', { greeting: 5 }), e => /text/.test(e.details.join()));
  fs.rmSync(path.join(d, 'extensions', 'demo-ext', 'versions', '1.0.0'), { recursive: true }); assert.equal((await m.view('demo-ext')).broken, true);
  await assert.rejects(m.enable('demo-ext', []), /missing or invalid/);
  await m.remove('demo-ext'); assert.equal((await m.list()).length, 0);
});
test('extensions: a failed update leaves the installed version untouched', async () => {
  const { m, state } = mgr(); await m.installPackage(pkg(manifest()));
  await assert.rejects(m.installPackage(pkg(manifest({ version: '2.0.0', id: 'demo-ext', provides: { software: [{ id: 'X' }] }, permissions: ['software.provide'] }))));
  assert.equal(state.extensions['demo-ext'].version, '1.0.0'); assert.equal((await m.view('demo-ext')).broken, false);
});
test('extensions: Blueprint packages are reported as unsupported, with embedded eggs listed', async () => {
  const egg = { meta: { version: 'PTDL_v2' }, name: 'E', startup: 'java -jar x' };
  const r = await inspectPackage(buildZip([{ name: 'conf.yml', data: 'info:\n  name: "Cool"\n  identifier: "cool"\n  version: "1.0"\n  target: "beta-2024-12"\n' }, { name: 'data/egg.json', data: JSON.stringify(egg) }, { name: 'admin/view.blade.php', data: '<?php' }]), '3.7.0');
  assert.equal(r.format, 'blueprint'); assert.equal(r.support, 'none'); assert.equal(r.blueprint.identifier, 'cool'); assert.deepEqual(r.embeddedEggs, ['data/egg.json']); assert.match(r.details.join(' '), /PHP\/Laravel/);
  assert.equal((await inspectPackage(Buffer.from(JSON.stringify(egg)), '3.7.0')).format, 'egg');
  await assert.rejects(inspectPackage(Buffer.from('{"a":1}'), '3.7.0'), /not a Pterodactyl egg/);
});
test('extensions: the bundled themes extension is valid and installs', async () => {
  const { m } = mgr(); const list = await m.listBundled(); assert.equal(list[0].id, 'hellenic-themes'); assert.equal(list[0].compat.ok, true);
  await m.installBundled('hellenic-themes'); await m.enable('hellenic-themes', ['branding.themes']);
  assert.deepEqual((await m.contributions()).themes.map(t => t.id), ['hellenic-themes:aegean', 'hellenic-themes:olive-grove']);
  for (const t of (await m.contributions()).themes) assert.deepEqual(branding.validate({ colors: t.colors }).errors, []);
});

// ---- plugins
test('plugins: install placement, replace with recovery, trash and restore', async () => {
  const dir = tmp(), lp = plugins.createLocal(), stage = path.join(tmp(), 'a.jar'); fs.writeFileSync(stage, 'new');
  const p = await lp.place(dir, stage, 'A.jar'); assert.equal(p.file, 'A.jar');
  await assert.rejects(lp.place(dir, stage, 'A.jar'), /already installed/);
  await assert.rejects(lp.place(dir, stage, '../x.jar'), /not allowed/);
  fs.writeFileSync(stage, 'newer'); const r = await lp.place(dir, stage, 'A.jar', { replace: 'A.jar' }); assert.ok(r.trashed); assert.equal(fs.readFileSync(path.join(dir, 'A.jar'), 'utf8'), 'newer');
  assert.equal((await lp.listTrash(dir)).length, 1);
  const t = await lp.trash(dir, 'A.jar'); assert.equal(fs.existsSync(path.join(dir, 'A.jar')), false);
  assert.equal(await lp.restore(dir, t), 'A.jar'); await assert.rejects(lp.restore(dir, t), /no longer exists/);
  await assert.rejects(lp.restore(dir, '../../etc__passwd.jar'), /Invalid/); await assert.rejects(lp.trash(dir, 'nope.jar'), /not found/);
  await assert.rejects(lp.trash(dir, '../A.jar'), /Invalid/);
});
test('plugins: replacement failure restores the previous jar', async () => {
  const dir = tmp(), lp = plugins.createLocal(), stage = path.join(tmp(), 's.jar'); fs.writeFileSync(stage, 'x');
  fs.writeFileSync(path.join(dir, 'Old.jar'), 'old'); fs.writeFileSync(path.join(dir, 'Other.jar'), 'other');
  await assert.rejects(lp.place(dir, stage, 'Other.jar', { replace: 'Old.jar' })); assert.equal(fs.readFileSync(path.join(dir, 'Old.jar'), 'utf8'), 'old');
});
test('plugins: listing reads descriptors, compat, records and config files', async () => {
  const dir = tmp(), lp = plugins.createLocal();
  fs.writeFileSync(path.join(dir, 'Ess.jar'), buildZip([{ name: 'plugin.yml', data: 'name: Ess\nversion: 1.0\nmain: a.B\napi-version: 1.21\n' }]));
  fs.writeFileSync(path.join(dir, 'Off.jar.disabled'), buildZip([{ name: 'plugin.yml', data: 'name: Off\nversion: 2\nmain: a.B\napi-version: 1.30\n' }]));
  fs.writeFileSync(path.join(dir, 'Ess.yml'), ''); fs.mkdirSync(path.join(dir, 'Ess')); fs.writeFileSync(path.join(dir, 'notes.txt'), '');
  const l = await lp.list(dir, { id: 'paper', name: 'Paper', pluginLoaders: ['paper'] }, '1.21.11', { 'Ess.jar': { type: 'modrinth', projectId: 'p', size: fs.statSync(path.join(dir, 'Ess.jar')).size, verifiedWith: 'sha512', installedAt: 't' } });
  assert.equal(l.length, 2); const ess = l.find(x => x.name === 'Ess'), off = l.find(x => x.name === 'Off');
  assert.equal(ess.compat.status, 'compatible'); assert.deepEqual(ess.configs, ['Ess.yml']); assert.equal(ess.dataDir, 'Ess'); assert.equal(ess.source.verified, true);
  assert.equal(off.enabled, false); assert.equal(off.compat.status, 'incompatible'); assert.equal(off.source, null);
});
test('modrinth: search facets, version filtering, file selection with verified hashes', async () => {
  const seen = []; const net = { getJson: async (url, o) => { seen.push({ url, o }); return url.includes('/search') ? { total_hits: 1, hits: [{ project_id: 'P1', slug: 'x y', title: 'X', description: 'd', author: 'a', downloads: 5, icon_url: 'https://evil.example/i.png', categories: ['paper'] }] } : [{ id: 'V1', project_id: 'P1', version_number: '1', version_type: 'release', game_versions: ['1.21.11'], loaders: ['paper'], files: [{ primary: false, filename: 'x.zip', url: 'u' }, { primary: true, filename: 'x.jar', url: 'https://cdn.modrinth.com/x.jar', hashes: { sha512: 'h', sha1: 's' }, size: 3 }] }]; } };
  const m = plugins.createModrinth({ net });
  const s = await m.search({ query: 'x', softwareId: 'paper', mcVersion: '1.21.11' }); assert.equal(s.hits[0].icon, null); assert.match(s.hits[0].url, /x%20y$/);
  const facets = JSON.parse(new URL(seen[0].url).searchParams.get('facets')); assert.deepEqual(facets, [['project_type:plugin'], ['categories:paper', 'categories:spigot', 'categories:bukkit'], ['versions:1.21.11']]);
  assert.deepEqual(seen[0].o.allowHosts, plugins.MODRINTH_HOSTS);
  await m.search({ softwareId: 'velocity', mcVersion: '1.21.11' }); assert.equal(JSON.parse(new URL(seen[1].url).searchParams.get('facets')).length, 2, 'proxies are not filtered by game version');
  await assert.rejects(m.search({ softwareId: 'vanilla' }), /no plugin source/);
  const v = await m.versions({ projectId: 'P1', softwareId: 'folia', mcVersion: '1.21.11' }); assert.equal(v[0].file.filename, 'x.jar'); assert.equal(v[0].file.verified, true); assert.equal(v[0].file.algorithm, 'sha512');
  assert.deepEqual(JSON.parse(new URL(seen[2].url).searchParams.get('loaders')), ['folia']);
  assert.deepEqual(m.pickFile({ files: [{ filename: 'a.exe', url: 'u' }] }), null);
});
