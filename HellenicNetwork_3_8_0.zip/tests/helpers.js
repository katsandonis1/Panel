'use strict';
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'hn-test-'));
// Local HTTP server for download tests. routes: {'/path': (req,res)=>void}
function serve(routes) {
  return new Promise(resolve => {
    const s = http.createServer((req, res) => (routes[req.url.split('?')[0]] || ((q, r) => { r.statusCode = 404; r.end('no'); }))(req, res));
    s.listen(0, '127.0.0.1', () => resolve({ url: `http://127.0.0.1:${s.address().port}`, close: () => new Promise(r => s.close(r)) }));
  });
}
const localNet = require('../lib/net');
// net facade that allows plain http + loopback for tests only
const testNet = { ...localNet, getJson: (u, o = {}) => localNet.getJson(u, { ...o, guard: false, allowHttp: true }), downloadToFile: (u, d, o = {}) => localNet.downloadToFile(u, d, { ...o, allowHosts: null, guard: false, allowHttp: true }) };
module.exports = { tmp, serve, testNet };
