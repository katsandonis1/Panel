'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path');
const { tmp } = require('./helpers');
process.env.PANEL_ROOT = tmp();
const setup = require('../scripts/setup');

test('setup: backups are created, pruned to 5, and rollback restores the newest while keeping what it replaces', async () => {
  const d = tmp(), f = path.join(d, 'config.json');
  assert.equal(await setup.backupConfig(f), null, 'nothing to back up yet');
  for (let i = 1; i <= 7; i++) { fs.writeFileSync(f, JSON.stringify({ v: i })); await setup.backupConfig(f); await new Promise(r => setTimeout(r, 5)); }
  const baks = fs.readdirSync(d).filter(n => n.includes('.bak-')); assert.equal(baks.length, 5);
  fs.writeFileSync(f, JSON.stringify({ v: 'bad' }));
  const r = await setup.rollbackConfig(f); assert.equal(JSON.parse(fs.readFileSync(f, 'utf8')).v, 7); assert.ok(r.safety, 'the replaced file is itself backed up');
  assert.ok(Object.values(fs.readdirSync(d)).some(n => n.includes('.bak-') && JSON.parse(fs.readFileSync(path.join(d, n), 'utf8')).v === 'bad'));
});
test('setup: rollback refuses damaged or missing backups', async () => {
  const d = tmp(), f = path.join(d, 'config.json'); fs.writeFileSync(f, '{}');
  await assert.rejects(setup.rollbackConfig(f), /no config.json backup/);
  fs.writeFileSync(f + '.bak-2020', '{not json'); await assert.rejects(setup.rollbackConfig(f));
  assert.equal(fs.readFileSync(f, 'utf8'), '{}', 'config untouched on failure');
});
test('setup: atomic write leaves no temp files and restricts permissions', async () => {
  const d = tmp(), f = path.join(d, 'config.json'); await setup.writeConfigAtomic({ a: 1 }, f);
  assert.deepEqual(fs.readdirSync(d), ['config.json']); assert.equal(fs.statSync(f).mode & 0o077, 0);
});
test('setup: change preview lists only real changes and never prints password hashes', () => {
  const before = { networkRoot: 'a', panel: { host: '0.0.0.0', port: 1 }, backupMount: '', backupDirectory: 'b', servers: { x: { label: 'X', cwd: 'old' } }, auth: { users: [{ username: 'root', passwordHash: 'HASH1' }] } };
  const after = JSON.parse(JSON.stringify(before)); after.networkRoot = 'c'; after.servers.x.cwd = 'new'; after.auth.users[0].passwordHash = 'HASH2';
  const rows = setup.planChanges(before, after); const text = JSON.stringify(rows);
  assert.deepEqual(rows.map(r => r.what), ['Minecraft network folder', 'Server folder for “X”', 'Administrator password']);
  assert.ok(!text.includes('HASH')); assert.equal(setup.planChanges(before, JSON.parse(JSON.stringify(before))).length, 0);
  assert.match(JSON.stringify(setup.planChanges(null, after)), /will be created/);
});
test('setup: directory validation explains problems in plain language', async () => {
  const d = tmp();
  await assert.rejects(setup.checkDirectoryPath('Network folder', path.join(d, 'missing'), { mustExist: true }), /does not exist.*mkdir -p/);
  await assert.rejects(setup.checkDirectoryPath('Mount', 'relative/path', { absolute: true }), /absolute path/);
  assert.equal(await setup.checkDirectoryPath('Mount', '', { optional: true }), '');
  assert.equal(await setup.checkDirectoryPath('Network folder', d, { mustExist: true }), d);
  assert.equal(setup.isInside(d, path.join(d, 'a', 'b')), true); assert.equal(setup.isInside(d, path.join(d, '..')), false);
});
