'use strict';
// Optional browser test for the extension host (needs Playwright + Chromium).
// NODE_PATH=$(npm root -g) node tests/ui-ext-smoke.js [outDir]
const http = require('http'), fs = require('fs'), path = require('path');
const { Readable } = require('stream');
const net = require('../lib/net');
const { setup, ADMIN } = require('./harness');
const out = process.argv[2] || path.join(require('os').tmpdir(), 'ui-ext-shots'); fs.mkdirSync(out, { recursive: true });
const pub = path.join(__dirname, '..', 'public'), EX = path.join(__dirname, '..', 'extensions-examples'), MIME = { '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.html': 'text/html' };
const check = (ok, msg) => { console.log((ok ? 'PASS ' : 'FAIL ') + msg); if (!ok) process.exitCode = 1; };
(async () => {
  const fake = { ...net, openStream: async () => ({ status: 200, stream: Readable.from([Buffer.from(JSON.stringify({ content: [{ type: 'text', text: 'Hello from the model' }] }))]) }) };
  const S = await setup({ net: fake, servers: { surv: { cwd: 'net/surv', label: 'Survival', port: 25565 }, lobby: { cwd: 'net/lobby', label: 'Lobby', port: 25566 } } });
  for (const n of ['quick-actions', 'punishments', 'dashboard-widget', 'translations-pack', 'ai-assistant']) {
    const f = fs.readdirSync(EX).find(x => x.startsWith(n + '-') && x.endsWith('.hnx'));
    const r = await S.app.call('POST', '/api/extensions/install', { user: ADMIN, file: { buffer: fs.readFileSync(path.join(EX, f)), originalname: f } });
    await S.app.call('POST', `/api/extensions/${n}/enable`, { user: ADMIN, body: { approve: r.body.extension.manifest.permissions } });
  }
  await S.app.call('PUT', '/api/extensions/ai-assistant/settings', { user: ADMIN, body: { values: { provider: 'anthropic', model: 'test-model', apiKey: 'sk-test', assistantName: 'Helper' } } });
  S.p.host.invalidate(); fs.copyFileSync(path.join(pub, 'index.html'), path.join(S.root, 'public', 'index.html'));
  const legacy = { '/api/auth': { authenticated: true, username: 'root', role: 'admin', permissions: {}, profile: {} }, '/api/servers': Object.fromEntries(Object.entries(S.config.servers).map(([id, s]) => [id, { id, label: s.label, port: s.port, status: 'online', online: true, players: [], type: 'backend', pluginsSupported: null }])) };
  const routed = p => p.startsWith('/api/') || p === '/' || p === '/manifest.webmanifest' || p === '/branding.css' || p.startsWith('/branding/') || p.startsWith('/ext-frame/');
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x'), p = u.pathname;
    if (legacy[p]) return res.setHeader('content-type', 'application/json'), res.end(JSON.stringify(legacy[p]));
    if (routed(p)) {
      const chunks = []; for await (const c of req) chunks.push(c); let body; try { body = chunks.length ? JSON.parse(Buffer.concat(chunks)) : undefined; } catch { body = undefined; }
      const r = await S.app.call(req.method, p + u.search, { body, user: ADMIN });
      if (r.status !== 404 || p.startsWith('/ext-frame/') || p.startsWith('/api/ext')) { for (const [k, v] of Object.entries(r.headers)) res.setHeader(k, v); res.statusCode = r.status; if (r.body?.file) return fs.createReadStream(r.body.file).pipe(res); if (typeof r.body === 'string') return res.end(r.body); res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify(r.body ?? {})); }
    }
    if (p.startsWith('/api/')) { res.setHeader('content-type', 'application/json'); return res.end('{}'); }
    const f = path.join(pub, p === '/' ? 'index.html' : p); if (!f.startsWith(pub) || !fs.existsSync(f)) { res.statusCode = 404; return res.end(); }
    res.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream'); fs.createReadStream(f).pipe(res);
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const base = `http://127.0.0.1:${server.address().port}`;
  const { chromium } = require('playwright'); const browser = await chromium.launch(); const errors = [];
  for (const [name, vp] of [['desktop', { width: 1280, height: 900 }], ['mobile', { width: 390, height: 800 }]]) {
    const page = await (await browser.newContext({ viewport: vp })).newPage();
    page.on('pageerror', e => errors.push(`[${name}] ${e.message}`)); page.on('console', m => { if (m.type() === 'error' && !/WebSocket|favicon|Failed to load resource|Content Security Policy|sandbox/i.test(m.text())) errors.push(`[${name}] console: ${m.text()}`); });
    await page.goto(base + '/'); await page.waitForSelector('#app:not(.hidden)'); await page.waitForSelector('.side-group[data-group="extensions"] .nav', { timeout: 8000, state: 'attached' });
    const navs = await page.$$eval('.side-group[data-group="extensions"] .nav', n => n.map(x => x.textContent.trim()));
    check(navs.some(t => /Quick actions/.test(t)) && navs.some(t => /Punishments/.test(t)) && navs.some(t => /AI Assistant/.test(t)), `${name}: extension pages appear in the sidebar → ${navs.join(' | ')}`);
    // declarative: quick actions
    await page.evaluate(() => window.navigate('ext:quick-actions:actions')); await page.waitForSelector('.ext-page select'); await page.selectOption('.ext-page select', 'surv');
    await page.$eval('.ext-page .ext-stack.row button', b => b.click()); await page.waitForTimeout(600);
    check(S.commands.at(-1)?.command === 'save-all' && S.commands.at(-1)?.id === 'surv', `${name}: button runs the declared command on the chosen server (${JSON.stringify(S.commands.at(-1))})`);
    await page.fill('.ext-form input', `Hello <b>${name}</b>`); await page.$eval('.ext-form button[type=submit]', b => b.click()); await page.waitForTimeout(600);
    check(S.commands.at(-1)?.command === `say Hello <b>${name}</b>`, `${name}: form text is passed as data (${S.commands.at(-1)?.command})`);
    check(await page.$('.ext-page b') === null, `${name}: extension text is never interpreted as HTML`);
    await page.screenshot({ path: path.join(out, `${name}-quick-actions.png`) });
    // declarative: punishments
    await page.evaluate(() => window.navigate('ext:punishments:manage')); await page.waitForSelector('[role=tab]'); await page.selectOption('.ext-page select', 'surv');
    await page.click('[role=tab]:has-text("Temp-ban")'); const form = page.locator('[role=tabpanel]:not([hidden]) form'); await form.locator('input[type=text]').first().fill('Spammer'); await form.locator('input[type=text]').nth(1).fill('spam'); await form.locator('input[type=number]').fill('15'); await form.locator('button[type=submit]').evaluate(b => b.click()); await page.waitForTimeout(700);
    check(S.commands.at(-1)?.command === 'ban Spammer spam', `${name}: temp-ban issued (${S.commands.at(-1)?.command})`);
    await page.click('[role=tab]:has-text("History")'); await page.waitForSelector('table tbody tr', { timeout: 5000 }); check((await page.textContent('table tbody tr')).includes('Spammer'), `${name}: history table lists the punishment`);
    await page.screenshot({ path: path.join(out, `${name}-punishments.png`), fullPage: true });
    // sandboxed frame + bridge
    await page.evaluate(() => window.navigate('ext:dashboard-widget:dash')); await page.waitForSelector('iframe.ext-frame');
    const sbox = await page.getAttribute('iframe.ext-frame', 'sandbox'); check(sbox === 'allow-scripts allow-forms', `${name}: iframe sandbox attribute is "${sbox}" (no allow-same-origin)`);
    const fr = page.frameLocator('iframe.ext-frame'); await fr.locator('.card b').first().waitFor({ timeout: 8000 });
    check((await fr.locator('#grid').textContent()).includes('Survival'), `${name}: frame received server data through the bridge`);
    const frame = page.frames().find(f => f !== page.mainFrame() && /dashboard-widget/.test(f.url()));
    const esc = await frame.evaluate(async () => { const r = {}; try { r.parent = typeof parent.document.title; } catch (e) { r.parent = 'blocked'; } try { r.storage = typeof localStorage.getItem('x'); } catch (e) { r.storage = 'blocked'; } try { r.cookie = document.cookie === '' ? 'empty' : 'readable'; } catch (e) { r.cookie = 'blocked'; } try { await fetch('/api/auth'); r.fetch = 'allowed'; } catch (e) { r.fetch = 'blocked'; } try { const x = await hn.call('servers.command', { serverId: 'surv', command: 'stop' }); r.cmd = 'allowed'; } catch (e) { r.cmd = 'denied:' + e.status; } return r; });
    check(esc.parent === 'blocked' && esc.storage === 'blocked' && esc.fetch === 'blocked' && esc.cmd === 'denied:403', `${name}: sandbox escape attempts fail ${JSON.stringify(esc)}`);
    await page.screenshot({ path: path.join(out, `${name}-dashboard.png`) });
    // AI chat (stubbed provider)
    await page.evaluate(() => window.navigate('ext:ai-assistant:chat')); const ai = page.frameLocator('iframe.ext-frame'); await ai.locator('#q').waitFor({ timeout: 8000 });
    await ai.locator('#notice:not(:empty)').waitFor({ timeout: 8000 }); check((await ai.locator('#notice').textContent()).includes('Anthropic'), `${name}: AI page tells users where their messages go`);
    await ai.locator('#q').fill('hi there'); await ai.locator('#send').click(); await ai.locator('.msg.bot').first().waitFor({ timeout: 8000 });
    check((await ai.locator('.msg.bot').first().textContent()).includes('Hello from the model'), `${name}: chat reply rendered`);
    await page.screenshot({ path: path.join(out, `${name}-ai.png`) });
    // language switch
    await page.waitForSelector('#langPick'); const opts = await page.$$eval('#langPick option', o => o.length); check(opts === 12, `${name}: language picker lists ${opts} languages`);
    await page.selectOption('#langPick', 'de'); await page.waitForTimeout(700);
    const lbl = await page.$$eval('.sidebar .nav', n => n.map(x => x.textContent.trim()).join('|')); check(/Spieler/.test(lbl) && /Sicherungs|Backups/.test(lbl), `${name}: navigation translated to German → ${lbl.slice(0, 80)}`);
    await page.selectOption('#langPick', 'ar'); await page.waitForTimeout(500); check(await page.evaluate(() => document.documentElement.dir) === 'rtl', `${name}: Arabic switches the page to RTL`);
    await page.screenshot({ path: path.join(out, `${name}-arabic.png`) }); await page.selectOption('#langPick', 'en');
  }
  await browser.close(); server.close();
  console.log(errors.length ? 'PAGE ERRORS:\n' + errors.join('\n') : 'No page errors.'); process.exit(errors.length || process.exitCode ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
