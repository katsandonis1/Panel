'use strict';
// Optional browser smoke test (needs Playwright + Chromium; not part of `npm test`).
// Serves public/ with the real branding renderer and routes /api/* to the real platform-api.js through a fake router,
// so every new page runs in a real browser. Usage: NODE_PATH=$(npm root -g) node tests/ui-smoke.js [outDir]
const http = require('http'), fs = require('fs'), path = require('path');
const { setup, ADMIN, fakeCatalog, jarBytes } = require('./harness');
const { buildZip } = require('../lib/zip');
const out = process.argv[2] || path.join(require('os').tmpdir(), 'ui-shots'); fs.mkdirSync(out, { recursive: true });
const pub = path.join(__dirname, '..', 'public'), MIME = { '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.html': 'text/html' };
(async () => {
  const fixtures = {
    'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json': null };
  const catalog = { listVersions: async id => ({ software: id, versions: id === 'velocity' ? [{ version: '3.4.0-SNAPSHOT' }] : [{ version: '1.21.11' }, { version: '1.21.10' }], target: '1.21.11', targetAvailable: id !== 'fabric', source: 'fixture' }), builds: async () => [{ build: '9', channel: 'STABLE' }, { build: '10', channel: 'ALPHA' }], javaRequirement: async () => ({ major: 21 }), resolve: async (id, version) => ({ software: id, version, kind: 'server', trust: 'official', hosts: null, warnings: [], jar: 'server.jar', build: '9', channel: 'STABLE', url: 'http://127.0.0.1:1/x', fileName: 'x.jar', expected: { algorithm: 'sha256', value: 'a'.repeat(64) }, javaMajor: 21, method: 'download' }) };
  const modrinth = { search: async () => ({ total: 1, hits: [{ projectId: 'P1', slug: 'vault', title: 'Vault', description: 'Economy API', author: 'Someone', downloads: 12345, icon: null, categories: [], url: 'https://modrinth.com/plugin/vault' }] }), versions: async () => [{ id: 'V1', number: '1.7.3', channel: 'release', published: '2025-01-01', gameVersions: ['1.21.10', '1.21.11'], file: { filename: 'Vault.jar', verified: true, algorithm: 'sha512' }, dependencies: [] }, { id: 'V2', number: '1.8.0-beta', channel: 'beta', published: '2025-02-01', gameVersions: ['1.21.11'], file: { filename: 'Vault.jar', verified: false }, dependencies: [] }], identify: async () => ({}), latestFor: async () => ({}), projects: async () => [] };
  const S = await setup({ catalog, modrinth, servers: { surv: { cwd: 'net/surv', label: 'Survival', port: 25565, software: { id: 'paper', version: '1.21.11' } }, lobby: { cwd: 'net/lobby', label: 'Lobby', port: 25566, software: { id: 'vanilla', version: '1.21.11' } } } });
  S.state.branding = { ...S.state.branding };
  for (const d of ['surv/plugins', 'lobby']) fs.mkdirSync(path.join(S.network, d), { recursive: true });
  fs.writeFileSync(path.join(S.network, 'surv/plugins/Essentials.jar'), buildZip([{ name: 'plugin.yml', data: 'name: Essentials\nversion: 2.21\nmain: a.B\napi-version: 1.21\ndescription: Core commands\n' }]));
  fs.writeFileSync(path.join(S.network, 'surv/plugins/OldThing.jar'), buildZip([{ name: 'plugin.yml', data: 'name: OldThing\nversion: 0.9\nmain: a.B\napi-version: 1.30\n' }]));
  fs.writeFileSync(path.join(S.network, 'surv/plugins/Fab.jar.disabled'), buildZip([{ name: 'fabric.mod.json', data: '{"id":"fab","version":"1"}' }]));
  fs.writeFileSync(path.join(S.network, 'surv/server.properties'), '#Minecraft server properties\nmotd=Welcome\nmax-players=20\npvp=true\nview-distance=10\nrcon.password=hunter22\nmy-plugin-opt=yes\n');
  const legacy = { '/api/auth': { authenticated: true, username: 'root', role: 'admin', permissions: {}, profile: {} }, '/api/servers': Object.fromEntries(Object.entries(S.config.servers).map(([id, s]) => [id, { id, label: s.label, port: s.port, status: 'offline', online: false, players: [], type: 'backend', pluginsSupported: S.p.pluginSupportSync(id) }])) };
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x'), p = u.pathname;
    if (legacy[p]) return res.setHeader('content-type', 'application/json'), res.end(JSON.stringify(legacy[p]));
    const r = (p.startsWith('/api/') || p === '/' || p === '/manifest.webmanifest' || p === '/branding.css' || p.startsWith('/branding/')) ? await (async () => {
      const chunks = []; for await (const c of req) chunks.push(c); let body; try { body = chunks.length ? JSON.parse(Buffer.concat(chunks)) : undefined; } catch { body = undefined; }
      return S.app.call(req.method, p + u.search, { body, user: ADMIN }); })() : null;
    if (r && r.status !== 404) { for (const [k, v] of Object.entries(r.headers)) res.setHeader(k, v); res.statusCode = r.status; if (r.body?.file) return fs.createReadStream(r.body.file).pipe(res); if (typeof r.body === 'string') return res.end(r.body); res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify(r.body ?? {})); }
    if (p.startsWith('/api/')) { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify(p === '/api/notifications' ? { notifications: [] } : {})); }
    const f = path.join(pub, p === '/' ? 'index.html' : p); if (!f.startsWith(pub) || !fs.existsSync(f)) { res.statusCode = 404; return res.end(); }
    res.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream'); fs.createReadStream(f).pipe(res);
  });
  // The static index.html lives in the real public dir, but setup() points ROOT at a temp dir; copy it there
  fs.copyFileSync(path.join(pub, 'index.html'), path.join(S.root, 'public', 'index.html'));
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const base = `http://127.0.0.1:${server.address().port}`;
  const { chromium } = require('playwright'); const browser = await chromium.launch(); const errors = [];
  for (const [name, vp] of [['desktop', { width: 1280, height: 900 }], ['mobile', { width: 390, height: 800 }]]) {
    const page = await (await browser.newContext({ viewport: vp })).newPage();
    page.on('pageerror', e => errors.push(`[${name}] pageerror: ${e.message} ${String(e.stack).split("\n").slice(1,4).join(" | ")}`)); page.on('console', m => { if (m.type() === 'error' && !/WebSocket|favicon|Failed to load resource/.test(m.text())) errors.push(`[${name}] console: ${m.text()}`); });
    await page.goto(base + '/'); await page.waitForSelector('#app:not(.hidden)', { timeout: 8000 });
    console.log(name, 'title:', await page.title(), '| brand:', await page.textContent('.sidebar .brand'));
    for (const p of ['create', 'software', 'extensions', 'branding', 'health']) {
      await page.evaluate(x => window.navigate(x), p); await page.waitForTimeout(700);
      const h = await page.textContent('#title'); const bad = await page.$('.error-box'); console.log(name, p, '→', h, bad ? 'ERROR BOX: ' + (await bad.textContent()).slice(0, 120) : 'ok');
      await page.screenshot({ path: path.join(out, `${name}-${p}.png`), fullPage: false });
    }
    // create flow: check & preview
    await page.evaluate(() => window.navigate('create')); await page.waitForSelector('#cs-version option[value="1.21.11"]', { state: 'attached' }); await page.fill('#cs-id', 'newsrv'); await page.click('#cs-check'); await page.waitForSelector('#cs-plan .plan', { timeout: 5000 });
    console.log(name, 'create preflight errors shown:', (await page.textContent('#cs-plan')).slice(0, 160).replace(/\s+/g, ' '));
    await page.screenshot({ path: path.join(out, `${name}-create-preflight.png`) });
    // plugin manager
    await page.evaluate(() => { state.current = 'surv'; state.page = 'surv'; window.renderPlugins(); }); await page.waitForSelector('table', { timeout: 5000 }); await page.screenshot({ path: path.join(out, `${name}-plugins.png`), fullPage: true });
    console.log(name, 'plugins rows:', await page.$$eval('tbody tr', r => r.length));
    await page.click('[data-tab="find"]'); await page.fill('#pgQ', 'vault'); await page.click('#pgSearch button'); await page.waitForSelector('.hit'); await page.click('[data-vers]'); await page.waitForSelector('.ver'); await page.screenshot({ path: path.join(out, `${name}-plugins-find.png`), fullPage: true });
    await page.evaluate(() => { window.openProperties('surv'); }); await page.waitForSelector('.pp-field'); await page.fill('[data-k="max-players"]', '40'); await page.$eval('[data-k="pvp"]', el => { el.scrollIntoView({ block: 'center' }); el.click(); });
    console.log(name, 'properties bar:', await page.textContent('#ppCount')); await page.screenshot({ path: path.join(out, `${name}-properties.png`), fullPage: false });
    await page.click('#ppSave'); await page.waitForTimeout(600); console.log(name, 'saved ->', fs.readFileSync(path.join(S.network, 'surv/server.properties'), 'utf8').replace(/\n/g, ' | '));
    await page.evaluate(() => { state.current = 'lobby'; state.page = 'lobby'; window.renderPlugins(); }); await page.waitForSelector('.card h3'); console.log(name, 'vanilla plugins page:', (await page.textContent('#content')).replace(/\s+/g, ' ').slice(0, 140));
  }
  await browser.close(); server.close();
  console.log(errors.length ? 'ERRORS:\n' + errors.join('\n') : 'No page errors.'); process.exit(errors.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
