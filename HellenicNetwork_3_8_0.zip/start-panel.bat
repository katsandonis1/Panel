@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
)
if not exist config.json (
  echo First-run setup...
  call npm run setup
)
call npm start
pause
