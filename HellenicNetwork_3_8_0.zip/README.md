# Hellenic Network panel 3.8.0 (formerly BlockPanel)

Lightweight self-hosted Minecraft network panel for Ubuntu/Node.js 20+.

Major features: per-user and per-server permissions, recursive file manager, autosaving text editor, TPS/MSPT/CPU/RAM/disk telemetry, multi-server console tools, player activity, scheduled commands and restarts, named Discord webhooks, filterable and exportable audit log, retained downloadable backups and admin restore, server templates, maintenance mode, startup checks, crash report helper, customizable dashboard, and admin-controlled plugin management.

Keep `config.json`, `data/`, and your MinecraftNetwork folder private. Discord webhook URLs and SMTP passwords are encrypted in `data/state.json` and never returned to the browser.

> **New in 3.8.0:** an extension platform (pages, buttons, forms, tables, jobs, events, storage, secrets, translations, sandboxed frames); see [docs/EXTENSIONS.md](docs/EXTENSIONS.md) and `extensions-examples/`.
>
> **New in 3.7.0:** branding, extensions, built-in Minecraft software catalog, server creation without templates, plugin manager, smarter setup. See [docs/HELLENIC-NETWORK.md](docs/HELLENIC-NETWORK.md). Older release notes are kept below.

## Install

```bash
npm install
npm start
```

On an interactive `npm install`, BlockPanel asks for the Minecraft network folder, the Proxy and Hub server folders, the backup disk mount, and the backup destination. First-time setup also asks for the admin login. Press Enter to keep a displayed path. If install runs without a terminal, it skips the prompts; run `npm run setup` later in a terminal to choose or review the folders. Setup preserves existing accounts and server definitions. To change the admin password through setup, run `npm run setup -- --reset-admin`.

The panel keeps the Proxy and Hub as its configured network entries. It scans direct child folders of `networkRoot` every 15 seconds and discovers backend servers that contain both `server.properties` and a server `.jar`. Their ports come from each folder's `server-port` setting, which the panel refreshes during each scan. New backend folders appear automatically without adding them to the example configuration.


## 3.1 reliability fixes

- Fixed panel session cookie parsing and logout handling.
- Start/Quick Launch now detects immediate process failures instead of falsely reporting success.
- Stop escalates from the configured stop command to signals when a process does not exit.
- Restart waits for the old process to exit before starting the new one.
- Scheduled restarts are de-duplicated per minute and report failures to the console.
- File uploads now support progress feedback and return readable JSON errors for size/count failures.
- Plugin manager now lists matching config files, supports enable/disable, server restart, PlugMan reload, and HTTPS JAR installation.
- New server folders can be detected automatically when they contain `server.properties` and a runnable server JAR.

## 3.2 management and safety

- Backups can be downloaded. Admin restore requires every panel-managed server process to be stopped, validates archive paths, and keeps the replaced network folder as a dated safety copy.
- Webhook routes have names and can be edited or deleted. Existing webhook URLs remain encrypted and are not returned to the browser. Leave the URL blank while editing to retain its encrypted value.
- A persistent admin-only security log records successful state-changing API requests and failed logins without storing request bodies or passwords.
- Plugin install, toggle, and reload are admin-only. HTTPS redirects are limited and rechecked for public hosts, downloads are size-limited, and existing plugin files are never overwritten.
- File rename refuses to overwrite an existing destination. Stop escalation checks process exit state so a previously sent signal does not prevent the final kill.

## 3.3 operations improvements

- Health alerts cover server offline/online transitions, configurable TPS and memory limits, and disk usage.
- Daily and weekly backup schedules have separate retention limits; scheduled one-line console commands can be configured per server.
- Per-user server access is configurable alongside existing action permissions. Multi-server commands only run on servers the account can access.
- Player joins and leaves are retained in the panel activity view. Resource history stores up to a day of minute samples.
- Admins can save setup templates and clone a stopped server's base files, plugins and configuration into a new folder, choosing a unique port and memory limit. World data and player lists are excluded from the clone.
- Maintenance mode enables the Minecraft whitelist and announces a message. Turning it off disables the whitelist; if you used a whitelist before maintenance, re-enable it as needed.
- Plugin update checks compare the installed `plugin.yml` name and version with an exact Modrinth plugin match. Updates require an explicit install action and preserve the previous JAR.
- The file editor supports find, JSON validation before save, automatic saving and unsaved-change warnings. The sidebar collapses on small screens.
- Server creation uses a form with prefilled port and memory settings, validates the template source and destination, and safely cleans up failed copies. A running template source can be stopped after confirmation.
- Sidebar navigation is grouped into collapsible Servers, Operations and Management categories. Its center scrolls when needed while Profile and Log out remain pinned at the bottom.
- Plugin installation can target one or several selected servers from the plugin page. Existing plugin files are preserved; each server reports its own success or conflict.
- Admins can remove a server from the panel and either keep its folder or confirm permanent folder deletion. Running servers must be stopped first; kept folders are excluded from automatic discovery.
- Admin accounts always receive all panel permissions, including file uploads; saved permission overrides apply to non-admin roles.
- Server discovery now matches configured IDs and folders case-insensitively, removes duplicate Windows folder entries, and ignores hidden temporary template copies. Main-tab navigation state is updated before views render so background refreshes do not replace the selected page.
- Server removal now requires the current admin password; permanent folder deletion also requires a separate confirmation.
- Admin Settings can send email alerts for selected panel events. Configure SMTP host/port, account, sender and recipient, then enter the local panel URL and the Tailscale panel URL. Event emails include links that open the affected server console. Use your provider's SMTP app password; Gmail accounts generally require an app password. Port 587 uses STARTTLS automatically; port 465 uses the implicit-TLS option.
- To send email, install dependencies with `npm install`, enter the SMTP details under Settings, select events, save, and use “Save & send test email”. Outbound email requires the host machine to be able to reach your SMTP provider. Tailscale links use the address of the machine running BlockPanel and the panel's port.
- The overview shows a network player total and avoids counting recognized Velocity, BungeeCord, or Waterfall proxy counts twice.
- The Players page refreshes online names and recent activity automatically, and offers per-player kick, ban, and whitelist actions when the account has moderation permission.
- Server deletion requires the admin password; permanent file deletion additionally requires typing the server ID, enforced by the API.
- Profile includes a session manager showing active devices/browsers and last activity, with controls to revoke individual sessions or sign out other sessions.

## 3.3.7 live account visibility

- The admin Users page lists signed-in sessions with username, role, IP address, device/browser, sign-in time, last activity, and live WebSocket connection status. Admins can sign out another session; the current session cannot be revoked from this list.
- Permission and per-server access saves refresh all active sessions for that account and notify its connected panel immediately. The affected browser refreshes its visible navigation and view, while server routes enforce the updated permissions on the next request.
- IP addresses are visible only to administrators through the protected session endpoint. Sessions that remain valid but have no active panel WebSocket are labeled “Session active,” rather than “Online now.”

## 3.3.8 process input safety

- Closed Minecraft stdin pipes are handled without crashing the panel. Console commands report that input is unavailable while the Minecraft process remains monitored; restart that server to restore command input. The panel will use its normal stop signals if the pipe is already closed.

## 3.3.9 administrator upload permissions

- Account roles are normalized consistently when logging in and authorizing actions, including administrator checks. This prevents an administrator role saved with different capitalization or whitespace from being denied file uploads and other permission-gated actions.

## 3.4.0 reliability fixes

- Uploads refuse to overwrite an existing file and report a conflict so the user can rename or remove the old file first. Duplicate filenames in one upload are rejected too.
- Server template creation is serialized so rapid repeated submissions cannot race and roll back a successfully created server's configuration. Rollback now removes only the attempted server entry instead of restoring an old full-config snapshot.
- Start and automatic-restart operations check whether the configured Minecraft address is already responding and prevent launching a duplicate process. Servers still online after a panel restart appear as running, and stop requests explain when a server is online but no longer managed by this panel.
- An occupied panel port now prints a clear startup error and exits cleanly rather than throwing an unhandled `EADDRINUSE` event.

## 3.4.1 permissions and navigation

- Every API request refreshes the signed-in account's role and permissions from the current user record. Permission changes apply immediately, and deleted accounts lose access.
- Admins bypass per-server restrictions and receive all panel permissions, including uploads.
- Navigation records the selected page so background overview refreshes do not replace another tab.
- Upload errors distinguish operating-system folder access from panel account permissions and explain that the user running BlockPanel needs write access to the server folder.
## 3.4.2 simpler file uploads

- Removed the separate Upload files permission. Signed-in accounts can upload to servers they are allowed to access; per-server access and file locks still apply.
- The Users page no longer offers a redundant upload permission checkbox. The file picker explains the upload size limit and access rule.
## 3.4.3 unrestricted-size uploads

- Removed the 250 MB per-file limit. Uploads stream through temporary disk files instead of being buffered in memory, and the API no longer checks a separate upload permission.
- Sign-in, per-server access, file locks, no-overwrite checks, and the 100-file request limit remain. The server host needs sufficient free disk space for staging and the destination copy.
## 3.5.0 operations improvements

- Dashboard widgets and server cards can be hidden and reordered per account in the current browser.
- Administrators can filter the audit log by text, user, action, server, and date, then export filtered events as CSV.
- Startup preflight checks Java, server-folder access, the configured JAR, EULA status, memory, disk space, and an already responding Minecraft server.
- The crash helper analyzes recent panel console history and logs/latest.log when available, then offers a downloadable report.
- Maintenance announcements are editable per server.
- BlockPanel Admin does not grant filesystem permissions to the operating-system account running Node.js.
- On Linux, Stop can signal an unmanaged Java Minecraft process only after matching its listening port and configured server folder. Other hosts must stop it through the host service or terminal.

## 3.6.0 operations and phone improvements

- Backup restore previews list archive contents; admins can test-extract a backup into a temporary folder before restoring.
- Backups request a save flush before archiving. Existing schedules and retention remain available.
- Scheduled restarts and maintenance mode announce configurable countdowns.
- Log search and player activity history can be filtered across accessible servers.
- Network-wide player bans sync to managed backend servers as they run.
- Storage view breaks server folder use down into worlds, plugins, logs, and other files.
- CPU alert thresholds complement TPS, memory, and disk alerts. Startup checks test port availability.
- Users management includes permission presets; active session controls remain available in Users and Profile.
- Mobile navigation adds quick actions and an installable app shell on HTTPS. API responses are not cached.

## 3.6.4 BIG disk mount detection

- Backup checks now confirm the mount using both Linux mount information and filesystem device metadata.
- If the disk is mounted on the host but hidden from BlockPanel by a private mount namespace, the panel explains that condition.

## 3.6.5 uploads, custom plugin updates, and setup

- File uploads stage temporary files on the selected server drive, so uploads to mounted server storage do not consume space on the panel's system drive. Uploads still reject duplicates, respect file locks and server access, and have no per-file size cap.
- Admins can upload a custom JAR over an installed plugin. The previous JAR is retained as a recovery copy; plugin configuration folders and Minecraft world/player data are left in place.
- Interactive `npm install` asks for the network, Proxy, Hub, mount, and backup folders. Non-interactive installs skip the prompts and leave `npm run setup` available for later.
- The sample configuration contains only Proxy and Hub; backend servers are discovered from the Minecraft network folder and their ports are read from `server.properties`.

## 3.6.1 BIG disk backups

- New manual, daily, and weekly backups are stored at /media/george/BIG/MinecraftBackups by default. The mount point and backup folder are configurable in config.json as backupMount and backupDirectory.
- On Linux, backup creation and restore stop with a clear error if /media/george/BIG is not mounted, preventing the panel from silently filling the system disk at an empty mount point. The account running BlockPanel must be able to write to the mounted disk.
- Existing backups in the former sibling MinecraftBackups folder remain downloadable and restorable. New restores place a safety copy on BIG and handle the copy across separate disks.

## 3.6.2 Velocity server creation

- Server creation supports Auto detect, Backend server, and Velocity proxy modes. Velocity templates do not need server.properties.
- Velocity creation writes velocity.toml from the supplied configuration, updates its bind/query port, and builds the backend list and try order from configured non-proxy servers. Existing TOML settings are preserved.
- A missing forwarding.secret is generated with private file permissions. When a new secret is generated, configure the same value on each Paper backend for modern forwarding.


## 3.6.3 Velocity route and server properties fixes

- Removing a backend server removes its entry from managed Velocity proxies’ `[servers]` and `try` settings. The panel reports proxy config files it changed and any files it could not update; restart the proxy to load the change.
- Backend server templates continue to require, copy, and update `server.properties` for the selected port. Velocity proxies use `velocity.toml` and do not require `server.properties`.
